//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vctest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_VCTESTTYPE                  129
#define IDD_DLG_GRDPROPS                131
#define IDC_EDT_NUMROWS                 1001
#define IDC_EDT_NUMCOLS                 1002
#define IDC_EDT_NUMFIXEDROWS            1003
#define IDC_EDT_NUMFIXEDCOLS            1004
#define IDC_SPN_NUMFIXEDCOLS            1005
#define IDC_SPN_NUMROWS                 1006
#define IDC_SPN_NUMCOLS                 1007
#define IDC_SPN_NUMFIXEDROWS            1008
#define IDC_BTN_SET                     1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
