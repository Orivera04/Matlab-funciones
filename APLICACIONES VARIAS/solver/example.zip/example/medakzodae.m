function  medakzodae
%MEDAKZODAE a stiff system of 6 non-linear DAEs of index 1 and has been
%   taken from
%     W.J.H. de Stortelder. Parameter Estimation in Nonlinear Dynamical Systems.
%     PhD thesis, University of Amsterdam, March 12, 1998.
%
%   The problem originates from Akzo Nobel Central Research in Arnhem,
%   The Netherlands. It describes a chemical process, in which 2 species,
%   FLB and ZHU, are mixed, while carbon dioxide is continuously
%   added. The resulting species of importance is ZLA. In the interest
%   of commercial competition, the names of the chemical species are
%   fictitious. The reaction equations, as given by Akzo Nobel from
%     CBS-reaction-meeting Koln. Handouts, May 1993. Br/ARLO-CRC.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameter, shared with the nested function.
k1   = 18.7;
k2   = 0.58;
k3   = 0.09;
k4   = 0.42;
kbig = 34.4;
kla  = 3.3;
ks   = 115.83;
po2  = 0.9;
hen  = 737;

M = eye(6);
M(6,6) = 0;

y0 =  zeros(6,1);
y0(1) = 0.444;
y0(2) = 0.00123;
y0(3) = 0;
y0(4) = 0.007;
y0(5) = 0;
y0(6) = ks*y0(1)*y0(4);

options = odeset('Jacobian',@jac,'Mass',M,'RelTol',1e-6,'AbsTol',1e-6,'InitialStep',1e-6,'Stats','on','refine',3);

[t,y] = odebim(@medakzo,[0 180],y0,options);

figure(1);
subplot(2,3,1); plot(t,y(:,1));title('y_1');axis([0 200 0.1 0.5]);
subplot(2,3,2); plot(t,y(:,2));title('y_2');axis([0 200 0 1.5e-3]);
subplot(2,3,3); plot(t,y(:,3));title('y_3');axis([0 200 0 0.2]);
subplot(2,3,4); plot(t,y(:,4));title('y_4');axis([0 200 0 8e-3]);
subplot(2,3,5); plot(t,y(:,5));title('y_5');axis([0 200 0 0.02]);
subplot(2,3,6); plot(t,y(:,6));title('y_6');axis([0 200 0 0.4]);

figure(2);
plot(t,y(:,2));title('y_2 on [0,3]');axis([0 3 0 1.5e-3]);



% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function f = medakzo(t,y)
        f = zeros(6,1);

        if (y(2) < 0d0)
            error('MATLAB:medakzodae:medakzo','y(2) < zero');
        end

        r1  = k1*(y(1)^4)*sqrt(y(2));
        r2  = k2*y(3)*y(4);
        r3  = k2/kbig*y(1)*y(5);
        r4  = k3*y(1)*(y(4)^2);
        r5  = k4*(y(6)^2)*sqrt(y(2));
        fin = kla*(po2/hen-y(2));

        f(1) =   -2d0*r1 +r2 -r3     -r4;
        f(2) = -0.5d0*r1             -r4     -0.5d0*r5 + fin;
        f(3) =        r1 -r2 +r3;
        f(4) =           -r2 +r3 -2d0*r4;
        f(5) =            r2 -r3         +r5;
        f(6) = ks*y(1)*y(4)-y(6);
    end
% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy = sparse(6,6);

        if (y(2) < 0d0)
            error('MATLAB:medakzodae:jac','y(2) < zero');
        end


        r11  = 4d0*k1*(y(1)^3)*sqrt(y(2));
        r12  = 0.5d0*k1*(y(1)^4)/sqrt(y(2));
        r23  = k2*y(4);
        r24  = k2*y(3);
        r31  = (k2/kbig)*y(5);
        r35  = (k2/kbig)*y(1);
        r41  = k3*y(4)^2;
        r44  = 2d0*k3*y(1)*y(4);
        r52  = 0.5d0*k4*(y(6)^2)/sqrt(y(2));
        r56  = 2d0*k4*y(6)*sqrt(y(2));
        fin2 = -kla;

        dfdy(1,1) = -2d0*r11-r31-r41;
        dfdy(1,2) = -2d0*r12;
        dfdy(1,3) = r23;
        dfdy(1,4) = r24-r44;
        dfdy(1,5) = -r35;
        dfdy(2,1) = -0.5d0*r11-r41;
        dfdy(2,2) = -0.5d0*r12-0.5d0*r52+fin2;
        dfdy(2,4) = -r44;
        dfdy(2,6) = -0.5d0*r56;
        dfdy(3,1) = r11+r31;
        dfdy(3,2) = r12;
        dfdy(3,3) = -r23;
        dfdy(3,4) = -r24;
        dfdy(3,5) = r35;
        dfdy(4,1) = r31-2d0*r41;
        dfdy(4,3) = -r23;
        dfdy(4,4) = -r24-2d0*r44;
        dfdy(4,5) = r35;
        dfdy(5,1) = -r31;
        dfdy(5,2) = r52;
        dfdy(5,3) = r23;
        dfdy(5,4) = r24;
        dfdy(5,5) = -r35;
        dfdy(5,6) = r56;
        dfdy(6,1) = ks*y(4);
        dfdy(6,4) = ks*y(1);
        dfdy(6,6) = -1d0;

    end

end


