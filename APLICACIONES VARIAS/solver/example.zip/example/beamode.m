function beamode
%BEAMODE is originally described by a partial diferential equation 
%  subject to boundary conditions. The semi-discretization in space  
%  of this equation leads to a stiff system of n non-linear second  
%  order differential equations which is rewritten to first order 
%  form, thus providing a stiff system of ordinary differential 
%  equations of dimension 2n. The formulation and data have been
%  taken from
% 
%    E. Hairer and G. Wanner. solving ordinary differential equations ii:
%    stiff and differential algebraic problems. Springer-verlag,
%    Second revised edition, 1996.
%  The BEAM problem originates from mechanics and describes the 
%  motion of an elastic beam which is supposed inextensible, of 
%  length 1 and thin.
%
%   see also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

options = odeset('reltol',1e-4,'abstol',1e-4,'initialstep',1e-4,'stats','on');
y0 =  zeros(80,1);
tic
[t,y] = odebim(@beam,[0 5],y0,options);
toc

figure;
subplot(2,2,1); plot(t,y(:,10));title('z(10)');axis([0 5 -0.5 1.5]);
subplot(2,2,2); plot(t,y(:,20));title('z(20)');axis([0 5 -0.5 1.5]);
subplot(2,2,3); plot(t,y(:,30));title('z(30)');axis([0 5 -0.5 1.5]);
subplot(2,2,4); plot(t,y(:,40));title('z(40)');axis([0 5 -0.5 1.5]);
% -----------------------------------------------------------------------
% nested function
%
    function df = beam(t,th)
        df = zeros(80,1);
        n =40;
        nn=2*n;

        nsq=n*n;
        nquatr=nsq*nsq;

        for i=2:n
            thdiff=th(i)-th(i-1);
            sth(i)=sin(thdiff);
            cth(i)=cos(thdiff);
        end
% -------- calcul du cote droit du systeme lineaire -----
        if(t > pi)
% --------- case t greater pi ------------
% ---------- i=1 ------------
            term1=(-3.d0*th(1)+th(2))*nquatr;
            v(1)=term1;
% -------- i=2,..,n-1 -----------
            for i=2:n-1
                term1=(th(i-1)-2.d0*th(i)+th(i+1))*nquatr;
                v(i)=term1;
            end
% ----------- i=n -------------
            term1=(th(n-1)-th(n))*nquatr;
            v(n)=term1;
        else
% --------- case t less equal pi ------------
            fabs=1.5d0*sin(t)*sin(t);
            fx=-fabs;
            fy= fabs;
% ---------- i=1 ------------
            term1=(-3.d0*th(1)+th(2))*nquatr;
            term2=nsq*(fy*cos(th(1))-fx*sin(th(1)));
            v(1)=term1+term2;
% -------- i=2,..,n-1 -----------
            for i=2:n-1
                term1=(th(i-1)-2.d0*th(i)+th(i+1))*nquatr;
                term2=nsq*(fy*cos(th(i))-fx*sin(th(i)));
                v(i)=term1+term2;
            end
% ----------- i=n -------------
            term1=(th(n-1)-th(n))*nquatr;
            term2=nsq*(fy*cos(th(n))-fx*sin(th(n)));
            v(n)=term1+term2;
        end
% -------- compute product dv=w ------------
        w(1)=sth(2)*v(2);
        for i=2:n-1
            w(i)=-sth(i)*v(i-1)+sth(i+1)*v(i+1);
        end
        w(n)=-sth(n)*v(n-1);
% -------- terme 3 -----------------
        for i=1:n
            w(i)=w(i)+th(n+i)*th(n+i);
        end
% ------- solve system cw=w ---------
        alpha(1)=1.d0;
        for i=2:n
            alpha(i)=2.d0;
            beta(i-1)=-cth(i);
        end
        alpha(n)=3.d0;
        for i=n-1:-1:1
            q=beta(i)/alpha(i+1);
            w(i)=w(i)-w(i+1)*q;
            alpha(i)=alpha(i)-beta(i)*q;
        end
        w(1)=w(1)/alpha(1);
        for i=2:n
            w(i)=(w(i)-beta(i-1)*w(i-1))/alpha(i);
        end
% -------- compute u=cv+dw ---------
        u(1)=v(1)-cth(2)*v(2)+sth(2)*w(2);
        for i=2:n-1
            u(i)=2.d0*v(i)-cth(i)*v(i-1)-cth(i+1)*v(i+1)-sth(i)*w(i-1)+sth(i+1)*w(i+1);
        end
        u(n)=3.d0*v(n)-cth(n)*v(n-1)-sth(n)*w(n-1);
% -------- put  derivatives in right place -------------
        for i=1:n
            df(i)=th(n+i);
            df(n+i)=u(i);
        end
    end
end


