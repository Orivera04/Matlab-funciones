function  adrewsdae
%ADREWSDAE is  a non-stiff second order DAE of index 3, consisting of 14 
% differential and 13 algebraic equations. It has been promoted as a test
% problem by Giles and Manning. The formulation here
% corresponds to the one presented in Hairer & Wanner. The problem 
% describes the motion of 7 rigid bodies connected by joints without friction.
%
%   D.R.A. Giles. An algebraic approach to A-stable linear multistep-multiderivative
%   integration formulas. BIT, 14:382-406, 1978.
%   E. Hairer and G. Wanner. Solving Ordinary Differential Equations II: 
%   Stiff and Differential algebraic Problems. Springer-Verlag, 
%   second revised edition, 1996.
%   D.W. Manning. A computer technique for simulating dynamic multibody 
%   systems based on dynamic formalism. PhD thesis, Univ. Waterloo, Ontario, 1981.
%
%   See also ODEBIM, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameters,shared with the nested function.
m1=.04325;   m2=0.00365;   m3=0.02373;    m4=0.00706;
m5=.07050;   m6=0.00706;   m7=0.05498;
xa=-0.06934; ya=-0.00227;
xb=-0.03635; yb=.03273;
xc=0.014;    yc=0.072;     c0=4530;
i1=2.194e-6; i2=4.410e-7;  i3=5.255e-6;   i4=5.667e-7;
i5=1.169e-5; i6=5.667e-7;  i7=1.912e-5;
d=28e-3;     da=115e-4;    e=2e-2;        ea=1421e-5;
rr=7e-3;     ra=92e-5;     l0=7785e-5;
ss=35e-3;    sa=1874e-5;   sb=1043e-5;    sc=18e-3;     sd=2e-2;
ta=2308e-5;  tb=916e-5;    u=4e-2;        ua=1228e-5;   ub=449e-5;
zf=2e-2;     zt=4e-2;      fa=1421e-5;    mom=33e-3;

M = sparse(27,27);
M(1:14,1:14) = speye(14);

% use a consistent initial condition.
y0 =  zeros(27,1);
y0(1 ) = -0.0617138900142764496358948458001d0;
y0(2 ) =  0d0;
y0(3 ) =  0.455279819163070380255912382449d0;
y0(4 ) =  0.222668390165885884674473185609d0;
y0(5 ) =  0.487364979543842550225598953530d0;
y0(6 ) = -0.222668390165885884674473185609d0;
y0(7 ) =  1.23054744454982119249735015568d0;
y0(8 ) =  0d0;
y0(9 ) =  0d0;
y0(10) =  0d0;
y0(11) =  0d0;
y0(12) =  0d0;
y0(13) =  0d0;
y0(14) =  0d0;
y0(15) =  14222.4439199541138705911625887d0;
y0(16) = -10666.8329399655854029433719415d0;
y0(17) =  0d0;
y0(18) =  0d0;
y0(19) =  0d0;
y0(20) =  0d0;
y0(21) =  0d0;
y0(22) =  98.5668703962410896057654982170d0;
y0(23) = -6.12268834425566265503114393122d0;
y0(24) =  0d0;
y0(25) =  0d0;
y0(26) =  0d0;
y0(27) =  0d0;

options = odeset('Jacobian',@jac,'Mass',M,'InitialStep',1e-4,'DaeIndex',[7,7,13]);
tic
[t,y] = odebim(@adrews,[0 0.03],y0,options);
toc
figure;
subplot(4,2,1); plot(t,y(:,1));title('y_1');
subplot(4,2,2); plot(t,y(:,2));title('y_2');
subplot(4,2,3); plot(t,y(:,3));title('y_3');
subplot(4,2,4); plot(t,y(:,4));title('y_4');
subplot(4,2,5); plot(t,y(:,5));title('y_5');
subplot(4,2,6); plot(t,y(:,6));title('y_6');
subplot(4,2,7); plot(t,y(:,7));title('y_7');

% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function ff = adrews(t,y)
        ff = zeros(27,1);
        
        sibe = sin(y(1));
        sith = sin(y(2));
        siga = sin(y(3));
        siph = sin(y(4));
        side = sin(y(5));
        siom = sin(y(6));
        siep = sin(y(7));

        cobe = cos(y(1));
        coth = cos(y(2));
        coga = cos(y(3));
        coph = cos(y(4));
        code = cos(y(5));
        coom = cos(y(6));
        coep = cos(y(7));

        sibeth = sin(y(1)+y(2));
        siphde = sin(y(4)+y(5));
        siomep = sin(y(6)+y(7));

        cobeth = cos(y(1)+y(2));
        cophde = cos(y(4)+y(5));
        coomep = cos(y(6)+y(7));

        bep = y(8);
        thp = y(9);
        php = y(11);
        dep = y(12);
        omp = y(13);
        epp = y(14);

        m= zeros(7);
        m(1,1) = m1*ra^2 + m2*(rr^2-2*da*rr*coth+da^2) + i1 + i2;
        m(2,1) = m2*(da^2-da*rr*coth) + i2;
        m(2,2) = m2*da^2 + i2;
        m(3,3) = m3*(sa^2+sb^2) + i3;
        m(4,4) = m4*(e-ea)^2 + i4;
        m(5,4) = m4*((e-ea)^2+zt*(e-ea)*siph) + i4;
        m(5,5) = m4*(zt^2+2*zt*(e-ea)*siph+(e-ea)^2) + m5*(ta^2+tb^2)+ i4 + i5;
        m(6,6) = m6*(zf-fa)^2 + i6;
        m(7,6) = m6*((zf-fa)^2-u*(zf-fa)*siom) + i6;
        m(7,7) = m6*((zf-fa)^2-2*u*(zf-fa)*siom+u^2) + m7*(ua^2+ub^2)+ i6 + i7;
        for j=2:7
            for i=1:j-1
                m(i,j) = m(j,i);
            end
        end

        xd = sd*coga + sc*siga + xb;
        yd = sd*siga - sc*coga + yb;
        lang  = sqrt ((xd-xc)^2 + (yd-yc)^2);
        force = - c0 * (lang - l0)/lang;
        fx = force * (xd-xc);
        fy = force * (yd-yc);
        f(1) = mom - m2*da*rr*thp*(thp+2*bep)*sith;
        f(2) = m2*da*rr*bep^2*sith;
        f(3) = fx*(sc*coga - sd*siga) + fy*(sd*coga + sc*siga);
        f(4) = m4*zt*(e-ea)*dep^2*coph;
        f(5) = - m4*zt*(e-ea)*php*(php+2*dep)*coph;
        f(6) = - m6*u*(zf-fa)*epp^2*coom;
        f(7) = m6*u*(zf-fa)*omp*(omp+2*epp)*coom;

        gp = zeros(6,7);
        gp(1,1) = - rr*sibe + d*sibeth;
        gp(1,2) = d*sibeth;
        gp(1,3) = - ss*coga;
        gp(2,1) = rr*cobe - d*cobeth;
        gp(2,2) = - d*cobeth;
        gp(2,3) = - ss*siga;
        gp(3,1) = - rr*sibe + d*sibeth;
        gp(3,2) = d*sibeth;
        gp(3,4) = - e*cophde;
        gp(3,5) = - e*cophde + zt*side;
        gp(4,1) = rr*cobe - d*cobeth;
        gp(4,2) = - d*cobeth;
        gp(4,4) = - e*siphde;
        gp(4,5) = - e*siphde - zt*code;
        gp(5,1) = - rr*sibe + d*sibeth;
        gp(5,2) = d*sibeth;
        gp(5,6) = zf*siomep;
        gp(5,7) = zf*siomep - u*coep;
        gp(6,1) = rr*cobe - d*cobeth;
        gp(6,2) = - d*cobeth;
        gp(6,6) = - zf*coomep;
        gp(6,7) = - zf*coomep - u*siep;

        g(1) = rr*cobe - d*cobeth - ss*siga - xb;
        g(2) = rr*sibe - d*sibeth + ss*coga - yb;
        g(3) = rr*cobe - d*cobeth - e*siphde - zt*code - xa;
        g(4) = rr*sibe - d*sibeth + e*cophde - zt*side - ya;
        g(5) = rr*cobe - d*cobeth - zf*coomep - u*siep - xa;
        g(6) = rr*sibe - d*sibeth - zf*siomep + u*coep - ya;


        ff(1:14) = y(1+7:14+7);

        for i=15:21
            ff(i) = -f(i-14);
            for  j=1:7
                ff(i) = ff(i)+m(i-14,j)*y(j+14);
            end
            for j=1:6
                ff(i) = ff(i)+gp(j,i-14)*y(j+21);
            end
        end
        for i=22:27
            ff(i) = g(i-21);
        end
    end
% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy = sparse(27,27);
        
        sibe = sin(y(1));
        siga = sin(y(3));
        siph = sin(y(4));
        side = sin(y(5));
        siom = sin(y(6));
        siep = sin(y(7));

        cobe = cos(y(1));
        coth = cos(y(2));
        coga = cos(y(3));
        code = cos(y(5));
        coep = cos(y(7));

        sibeth = sin(y(1)+y(2));
        siphde = sin(y(4)+y(5));
        siomep = sin(y(6)+y(7));

        cobeth = cos(y(1)+y(2));
        cophde = cos(y(4)+y(5));
        coomep = cos(y(6)+y(7));


        m = zeros(7);
        m(1,1) = m1*ra^2 + m2*(rr^2-2*da*rr*coth+da^2) + i1 +i2;
        m(2,1) = m2*(da^2-da*rr*coth) + i2;
        m(2,2) = m2*da^2 + i2;
        m(3,3) = m3*(sa^2+sb^2) + i3;
        m(4,4) = m4*(e-ea)^2 + i4;
        m(5,4) = m4*((e-ea)^2+zt*(e-ea)*siph) + i4;
        m(5,5) = m4*(zt^2+2*zt*(e-ea)*siph+(e-ea)^2) + m5*(ta^2+tb^2)+ i4 + i5;
        m(6,6) = m6*(zf-fa)^2 + i6;
        m(7,6) = m6*((zf-fa)^2-u*(zf-fa)*siom) + i6;
        m(7,7) = m6*((zf-fa)^2-2*u*(zf-fa)*siom+u^2) + m7*(ua^2+ub^2)+ i6 + i7;
        for j=2:7
            for i=1:j-1
                m(i,j) = m(j,i);
            end
        end
        
        gp = zeros(6,7) ;
        gp(1,1) = - rr*sibe + d*sibeth;
        gp(1,2) = d*sibeth;
        gp(1,3) = - ss*coga;
        gp(2,1) = rr*cobe - d*cobeth;
        gp(2,2) = - d*cobeth;
        gp(2,3) = - ss*siga;
        gp(3,1) = - rr*sibe + d*sibeth;
        gp(3,2) = d*sibeth;
        gp(3,4) = - e*cophde;
        gp(3,5) = - e*cophde + zt*side;
        gp(4,1) = rr*cobe - d*cobeth;
        gp(4,2) = - d*cobeth;
        gp(4,4) = - e*siphde;
        gp(4,5) = - e*siphde - zt*code;
        gp(5,1) = - rr*sibe + d*sibeth;
        gp(5,2) = d*sibeth;
        gp(5,6) = zf*siomep;
        gp(5,7) = zf*siomep - u*coep;
        gp(6,1) = rr*cobe - d*cobeth;
        gp(6,2) = - d*cobeth;
        gp(6,6) = - zf*coomep;
        gp(6,7) = - zf*coomep - u*siep;

        for i=1:14
            dfdy(i,i+7) = 1d0;
        end
        for i=1:7
            for j=1:7
                dfdy(14+j,14+i) = m(j,i);
            end
        end
        for i=1:6
            for j=1:7
                dfdy(14+j,21+i) = gp(i,j);
            end
        end
        for i=1:7
            for j=1:6
                dfdy(21+j,i) = gp(j,i);
            end
        end
    end

end


