function  oregoode
%OREGOODE is a stiff system of 3 non-linear Ordinary Differential Equations.
%   The name Orego was given by Hairer & Wanner in
%
%     E. Hairer and G. Wanner. Solving Ordinary Differential Equations II:
%     Stiff and Differential algebraic Problems. Springer-Verlag,
%     second revised edition, 1996.
%
%   and refers to the Oregonator model which is described by this ODE.
%   The Oregonator model takes its name from the University of Oregon
%   where in the 1972 Field, Koros & Noyes proposed this model for
%   the Belousov-Zhabotinskii reaction.
%
%      R. J. Field, E. Koros, and R.M Noyes. Oscillation in chemical systems,
%      part. 2. thorough analysis of temporal oscillations in the
%      bromate-cerium-alonic acid system. Journal of the American Society,
%      94:8649-8664, 1972.
%
%   The OREGO problem originates from the celebrated Belousov-Zhabotinskii
%   (BZ) reaction. When certain reactans, like bromous acid, bromide ion
%   and cerium ion, are combined, they exhibit a chemical reaction which,
%   after an induction period of inactivity, oscillates with change in
%   structure and in color, from red to blue and viceversa.
%   The color changes are caused by alternating oxidation-reductions in
%   which the cerium switches its oxidation state from Ce(III) to Ce(IV).
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

tspan = [0; 360];              % several periods
y0 = [1; 2; 3];
options = odeset('Jacobian',@J);

[t,y]=odebim(@f,tspan,y0,options);

figure(1);
plot(t,y(:,1)); title('Behavior of the solution component y_1 over the integration interval');
set(gca,'YScale','log')
figure(2);
plot(t,y(:,2)); title('Behavior of the solution component y_2 over the integration interval'); 
set(gca,'YScale','log')
figure(3);
plot(t,y(:,3)); title('Behavior of the solution component y_3 over the integration interval'); 
set(gca,'YScale','log')
% -----------------------------------------------------------------------
% Nested functions
%
    function dydt = f(t,y)
        dydt = [77.27*(y(2)+y(1)*(1-8.375e-6*y(1)-y(2)));
            (y(3)-(1+y(1))*y(2))/77.27;
            0.161*(y(1)-y(3))];
    end
% -----------------------------------------------------------------------
% Nested functions
%
    function dfdy = J(t,y)
        dfdy = [77.27*(1-2*8.375e-6*y(1)-y(2)),  77.27*(1-y(1)),    0;
            -y(2)/77.27,                -(1+y(1))/77.27,  1/77.27;
            0.161,                          0,           -0.161];
    end

end