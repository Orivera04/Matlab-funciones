// LiteGrid.cpp : Implementation of CLiteGrid
#include "stdafx.h"
#include "lgrid.h"
#include "LiteGrid.h"
#pragma warning(disable:4800)

#ifndef UNICODE

// maximal text string length which can be displayed within grid
const MAX_CELL_TEXT_LEN = 1024;

// converts CComBSTR to LPSTR
// NOT REENTERABLE!!!!
// Arguments:
//		pbs = in, pointer to CComBSTR to convert
// Returns:
//		pointer to converted single-byte string
LPSTR BSTRtoLPSTR(CComBSTR* pbs)
{
	static char str[MAX_CELL_TEXT_LEN];
	str[0] = 0;
	if(pbs != NULL)
	{
		UINT uiBufSize = pbs->Length() + 1;
		if(uiBufSize >= MAX_CELL_TEXT_LEN)
			uiBufSize = MAX_CELL_TEXT_LEN - 1;
		::WideCharToMultiByte(CP_ACP, 0, (BSTR)*pbs, MAX_CELL_TEXT_LEN - 1, str, uiBufSize, NULL, NULL);
	}
	return str;
}

#endif

// converts OLE_COLOR to RRGGBB (COLORREF)
COLORREF OLE2RGB(OLE_COLOR ole)
{
	return (ole & 0x80000000) ? ::GetSysColor(ole ^ 0x80000000) : (COLORREF)ole;
}

// converts shift, ctrl alt key state into VB format
short GetVbShift()
{
	short shResult = 0;

	if(::GetKeyState(VK_SHIFT))
		shResult |= 1;
	if(::GetKeyState(VK_CONTROL))
		shResult |= 2;
	if(::GetKeyState(VK_MENU))
		shResult |= 4;
	
	return shResult;
}

// convrerts mouse buttons' state into VB format
short GetVbButtons(WPARAM wWinMouseButtons)
{
	short shResult = 0;
	
	if(wWinMouseButtons & MK_LBUTTON)
		shResult |= 1;
	if(wWinMouseButtons & MK_RBUTTON)
		shResult |= 2;
	if(wWinMouseButtons & MK_MBUTTON)
		shResult |= 4;
	
	return shResult;
}

/////////////////////////////////////////////////////////////////////////////
// CLiteGrid

CLiteGrid::CLiteGrid()
: m_wndInplaceEdit(this)
{
	const INITIAL_COL_WIDTH = 50;
	const INITIAL_ROW_HEIGHT = 20;
	const INITIAL_NUM_ROWS = 50;
	const INITIAL_NUM_COLS = 50;
	const INITIAL_NUM_FIXEDROWS = 1;
	const INITIAL_NUM_FIXEDCOLS = 1;

	m_bWindowOnly = TRUE;
	// initialize all scalars...
	m_lTopCol = m_lTopRow = m_lCol = m_lRow = 1;
	m_lNumRows = INITIAL_NUM_ROWS;
	m_lNumCols = INITIAL_NUM_COLS;
	m_lNumFixedRows = INITIAL_NUM_FIXEDROWS;
	m_lNumFixedCols = INITIAL_NUM_FIXEDCOLS;
	m_lDefColWidth = INITIAL_COL_WIDTH;
	m_lDefRowHeight = INITIAL_ROW_HEIGHT;
	m_lDefColAlign = 0;	// left align
	m_bFastDraw = m_bResizeCols = m_bResizeRows = m_bEditable = true;
	// ...and vectors
	m_vecColWidths.resize(INITIAL_NUM_COLS);
	m_vecRowHeights.resize(INITIAL_NUM_ROWS);
	m_vecColAligns.resize(INITIAL_NUM_COLS);
	for(int i = 0; i < INITIAL_NUM_COLS; i++)
	{
		m_vecColWidths[i] = INITIAL_COL_WIDTH;
		m_vecColAligns[i] = m_lDefColAlign;
	}
	for(i = 0; i < INITIAL_NUM_ROWS; i++)
		m_vecRowHeights[i] = INITIAL_ROW_HEIGHT;
	m_vecCellText.resize(INITIAL_NUM_ROWS * INITIAL_NUM_COLS);
	
	// initialize with default system colors
	m_ColorFixedBk = m_ColorNormalShadow = COLOR_3DFACE | 0x80000000;
	m_ColorFixedFont = m_ColorNormalFont = m_ColorFixedShadow = COLOR_WINDOWTEXT | 0x80000000;
	m_ColorNormalBk = m_ColorNormalLight = m_ColorFixedLight = COLOR_WINDOW | 0x80000000;
	m_ColorBk = COLOR_3DSHADOW | 0x80000000;
	// stock props
	m_bBorder = FALSE;
	m_bVisible = m_bEnabled = TRUE;
	// create default font
	FONTDESC fd;
	fd.cbSizeofstruct = sizeof(FONTDESC);
	fd.lpstrName = L"MS Sans Serif";
	fd.cySize.Hi = 0;
	fd.cySize.Lo = 10;
	fd.sWeight = FW_NORMAL;
	fd.sCharset = 0;
	fd.fItalic = TRUE;
	fd.fUnderline = FALSE;
	fd.fStrikethrough = FALSE;
	::OleCreateFontIndirect(&fd, IID_IFont, (void**)&m_pFontFixed);
	fd.fItalic = FALSE;
	::OleCreateFontIndirect(&fd, IID_IFont, (void**)&m_pFontNormal);
	m_nScrollType = lgBothScrollBars;
	m_nState = STATE_NORMAL;
}

CLiteGrid::~CLiteGrid()
{
	// destroy all allocated BSTRs
	CComBSTR* pbsTmp;
	for(int i = 0; i < m_lNumRows * m_lNumCols; i++)
	{
		pbsTmp = m_vecCellText[i];
		if(pbsTmp != NULL)
			delete pbsTmp;
	}
	// release fonts
	m_pFontFixed->Release();
	m_pFontNormal->Release();
}

LRESULT CLiteGrid::OnPaint(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
{
	int i;
	RECT rcCells;
	POINT ptTopVisibleNonFixedCell;
	PAINTSTRUCT ps;
	HDC hDC = BeginPaint(&ps);
	HFONT hOldFont, hNewFont;

	// prevent from full redraw when changed size
	long lStyle = ::GetClassLong(m_hWnd, GCL_STYLE);
	lStyle &= ~(CS_HREDRAW | CS_VREDRAW);
	lStyle |= CS_DBLCLKS;
	::SetClassLong(m_hWnd, GCL_STYLE, lStyle);
	// select font for fixed cells
	m_pFontFixed->get_hFont(&hNewFont);
	hOldFont = (HFONT)::SelectObject(hDC, hNewFont);
	// determine starting point of the 4 regions
	POINT ptFixFix, ptFixNorm, ptNormFix, ptNormNorm;

	ptFixFix.x = ptFixFix.y = ptFixNorm.y = ptNormFix.x = 0;
	ptTopVisibleNonFixedCell.x = ptTopVisibleNonFixedCell.y = 0;
	for(i = 0; i < m_lNumFixedRows; i++)
		ptTopVisibleNonFixedCell.y += m_vecRowHeights[i];
	for(i = 0; i < m_lNumFixedCols; i++)
		ptTopVisibleNonFixedCell.x += m_vecColWidths[i];
	ptFixNorm.x = ptNormNorm.x = ptTopVisibleNonFixedCell.x;
	ptNormFix.y = ptNormNorm.y = ptTopVisibleNonFixedCell.y;
	// draw fixed-fixed cells
	if(m_lNumFixedRows > 0 && m_lNumFixedCols > 0)
	{
		rcCells.top = rcCells.left = 0;
		rcCells.bottom = m_lNumFixedRows;
		rcCells.right = m_lNumFixedCols;
		DrawCellRange(hDC, ps.rcPaint, ptFixFix, rcCells, 
			OLE2RGB(m_ColorFixedBk),
			OLE2RGB(m_ColorFixedFont),
			OLE2RGB(m_ColorFixedLight),
			OLE2RGB(m_ColorFixedShadow));
	}
	// fixed rows
	if(m_lNumFixedRows > 0)
	{
		rcCells.top = 0;
		rcCells.bottom = m_lNumFixedRows;
		rcCells.left = m_lTopCol;
		rcCells.right = m_lNumCols;
		DrawCellRange(hDC, ps.rcPaint, ptFixNorm, rcCells,
			OLE2RGB(m_ColorFixedBk),
			OLE2RGB(m_ColorFixedFont),
			OLE2RGB(m_ColorFixedLight),
			OLE2RGB(m_ColorFixedShadow));
	}
	// fixed columns
	if(m_lNumFixedCols > 0)
	{
		rcCells.top = m_lTopRow;
		rcCells.bottom = m_lNumRows;
		rcCells.left = 0;
		rcCells.right = m_lNumFixedCols;
		DrawCellRange(hDC, ps.rcPaint, ptNormFix, rcCells,
			OLE2RGB(m_ColorFixedBk),
			OLE2RGB(m_ColorFixedFont),
			OLE2RGB(m_ColorFixedLight),
			OLE2RGB(m_ColorFixedShadow));
	}
	// normal cells
	// select font for normal cells
	::SelectObject(hDC, hOldFont);
	m_pFontNormal->get_hFont(&hNewFont);
	hOldFont = (HFONT)::SelectObject(hDC, hNewFont);
	rcCells.top = m_lTopRow;
	rcCells.left = m_lTopCol;
	rcCells.bottom = m_lNumRows;
	rcCells.right = m_lNumCols;
	DrawCellRange(hDC, ps.rcPaint, ptNormNorm, rcCells,
			OLE2RGB(m_ColorNormalBk),
			OLE2RGB(m_ColorNormalFont),
			OLE2RGB(m_ColorNormalLight),
			OLE2RGB(m_ColorNormalShadow));
	// select old font
	::SelectObject(hDC, hOldFont);
	// draw selected rectangle
	FocusCell(hDC, m_lRow, m_lCol);
	ReleaseDC(hDC);
	EndPaint(&ps);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Rows(long * pVal)
{
	*pVal = m_lNumRows;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Rows(long newVal)
{
	int i;

	if(newVal <= m_lNumFixedRows)
		return E_INVALIDARG;
	if(newVal > m_lNumRows)
	{
		// here I have to just increase capacity of vectors
		m_vecRowHeights.resize(newVal);
		m_vecCellText.resize(newVal * m_lNumCols);
		for(i = m_lNumRows; i < newVal; i++)
			m_vecRowHeights[i] = m_lDefRowHeight;
		m_lNumRows = newVal;
		FireViewChange();
	}
	else if(newVal < m_lNumRows)
	{
		if(newVal <= m_lRow)
			ChangeActiveCell(newVal - 1, m_lCol);
		for(i = newVal * m_lNumCols; i < m_lNumRows * m_lNumCols; i++)
		{
			CComBSTR* psTemp = m_vecCellText[i];
			if(psTemp != NULL)
			{
				delete psTemp;
				m_vecCellText[i] = NULL;
			}
		}
		m_vecCellText.resize(newVal * m_lNumCols);
		m_vecRowHeights.resize(newVal);
		m_lNumRows = newVal;
		FireViewChange();
	}
	if(::IsWindow(m_hWnd))
		// affect the scrool bar
		SetScrollRange(SB_VERT, m_lNumFixedRows, m_lNumRows - 1);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Cols(long * pVal)
{
	*pVal = m_lNumCols;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Cols(long newVal)
{
	int i;
	CComBSTR* pbsTmp;

	if(newVal <= m_lNumFixedCols)
		return E_INVALIDARG;
	if(newVal > m_lNumCols)
	{
		m_vecColWidths.resize(newVal);
		m_vecColAligns.resize(newVal);
		for(i = m_lNumCols; i < newVal; i++)
		{
			m_vecColWidths[i] = m_lDefColWidth;
			m_vecColAligns[i] = m_lDefColAlign;
		}
		m_vecCellText.resize(m_lNumRows * newVal);
		// Here I have a problem:
		// I can not just increase size of cell text strings,
		// I also need to move items inside the array because
		// I am amulating 2D vector inside an 1D one...
		for(int j = m_lNumRows - 2; j >= 0; j--)
		{
			// move old values
			for(i = 0; i < m_lNumCols; i++)
				m_vecCellText[j * newVal + i] = m_vecCellText[j * m_lNumCols + i];
			// fill with NULLs
			for(i = m_lNumCols; i < newVal; i++)
				m_vecCellText[j * newVal + i] = NULL;
		}
		m_lNumCols = newVal;
		FireViewChange();
	}
	else if(newVal < m_lNumCols)
	{
		if(newVal <= m_lCol)
			ChangeActiveCell(m_lRow, newVal - 1);
		// I have there the same situation as above. Here
		// I also must completely move all elements in the vector...
		for(int j = 0; j < m_lNumRows; j++)
		{
			// delete deleted BSTRs
			for(i = newVal; i < m_lNumCols; i++)
			{
				pbsTmp = m_vecCellText[j * m_lNumCols + i];
				if(pbsTmp != NULL)
					delete pbsTmp;
			}
			// move
			for(i = 0; i < newVal; i++)
				m_vecCellText[j * newVal + i] = m_vecCellText[j * m_lNumCols + i];
		}
		m_vecColWidths.resize(newVal);
		m_vecColAligns.resize(newVal);
		m_lNumCols = newVal;
		m_vecCellText.resize(newVal * m_lNumRows);
		FireViewChange();
	}
	if(::IsWindow(m_hWnd))
		// affect the scrool bar
		SetScrollRange(SB_HORZ, m_lNumFixedCols, m_lNumCols - 1);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FixedRows(long * pVal)
{
	*pVal = m_lNumFixedRows;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedRows(long newVal)
{
	if(newVal >= m_lNumRows || newVal < 0)
		return E_INVALIDARG;
	if(m_lRow < newVal)
		m_lRow = newVal;
	if(m_lTopRow < newVal)
		m_lTopRow = newVal;
	m_lNumFixedRows = newVal;
	FireViewChange();
	if(::IsWindow(m_hWnd))
		SetScrollRange(SB_VERT, m_lNumFixedRows, m_lNumRows - 1);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FixedCols(long * pVal)
{
	*pVal = m_lNumFixedCols;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedCols(long newVal)
{
	if(newVal >= m_lNumCols || newVal < 0)
		return E_INVALIDARG;
	if(m_lCol < newVal)
		m_lCol = newVal;
	if(m_lTopCol < newVal)
		m_lTopCol = newVal;
	m_lNumFixedCols = newVal;
	FireViewChange();
	if(::IsWindow(m_hWnd))
		SetScrollRange(SB_HORZ, m_lNumFixedCols, m_lNumCols - 1);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_CellText(long lRow, long lCol, BSTR * pVal)
{
	if(lRow < 0 || lRow >= m_lNumRows || lCol < 0 || lCol >= m_lNumCols)
		return E_INVALIDARG;
	CComBSTR* pbsTmp = m_vecCellText[lRow * m_lNumCols + lCol];
	*pVal = pbsTmp != NULL ? pbsTmp->Copy() : NULL;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_CellText(long lRow, long lCol, BSTR newVal)
{
	if(lRow < 0 || lRow >= m_lNumRows || lCol < 0 || lCol >= m_lNumCols)
		return E_INVALIDARG;
	CComBSTR* pbsTmp = m_vecCellText[lRow * m_lNumCols + lCol];
	if(pbsTmp == NULL)
		m_vecCellText[lRow * m_lNumCols + lCol] = new CComBSTR(newVal);
	else
		*pbsTmp = newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_ColWidth(long lCol, long * pVal)
{
	if(lCol < 0 || lCol >= m_lNumCols)
		return E_INVALIDARG;
	*pVal = m_vecColWidths[lCol];
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_ColWidth(long lCol, long newVal)
{
	if(lCol < 0 || lCol >= m_lNumCols || newVal < 1)
		return E_INVALIDARG;
	m_vecColWidths[lCol] = newVal;
	RedrawWindow();
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_RowHeight(long lRow, long * pVal)
{
	if(lRow < 0 || lRow >= m_lNumRows)
		return E_INVALIDARG;
	*pVal = m_vecRowHeights[lRow];
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_RowHeight(long lRow, long newVal)
{
	if(lRow < 0 || lRow >= m_lNumRows || newVal < 1)
		return E_INVALIDARG;
	m_vecRowHeights[lRow] = newVal;
	RedrawWindow();
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_DefaultColWidth(long * pVal)
{
	*pVal = m_lDefColWidth;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_DefaultColWidth(long newVal)
{
	if(newVal < 1)
		return E_INVALIDARG;
	m_lDefColWidth = newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_DefaultRowHeight(long * pVal)
{
	*pVal = m_lDefRowHeight;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_DefaultRowHeight(long newVal)
{
	if(newVal < 1)
		return E_INVALIDARG;
	m_lDefRowHeight = newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Row(long * pVal)
{
	*pVal = m_lRow;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Row(long newVal)
{
	if(newVal < m_lNumFixedRows || newVal > m_lNumRows)
		return E_INVALIDARG;
	ChangeActiveCell(newVal, m_lCol);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Col(long * pVal)
{
	*pVal = m_lCol;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Col(long newVal)
{
	if(newVal < m_lNumFixedCols || newVal >= m_lNumCols)
		return E_INVALIDARG;
	ChangeActiveCell(m_lRow, newVal);
	return S_OK;
}


// calculates coordinates of a cell in lRow, lCol coordinates
// ATTENTION: lRow and lCol must be greater or equal to
// the currently top visible cell or must be within fixed
// Returned rectangle assumes that coordinates of client area
// start at (0,0),  so the calculated rectangle must be adjusted
// if we use ATL_DRAWINFO's hdcDraw.
// Arguments:
//		lRow, lCol = in, row and column of the cell
//		rc = out, calculated coordinates of the cell

void CLiteGrid::GetCellRect(long lRow, long lCol, RECT& rc)
{
	int i;

	rc.top = rc.left = 0;
	if(lRow < m_lNumFixedRows) // the row is within fixed
		for(i = 0; i < lRow; i++)
			rc.top += m_vecRowHeights[i];
	else // the row is within normal
	{
		// calculate offset of the top visible row
		for(i = 0; i < m_lNumFixedRows; i++)
			rc.top += m_vecRowHeights[i];
		// calculate offset of the cell
		if(lRow >= m_lTopRow)
			for(i = m_lTopRow; i < lRow; i++)
				rc.top += m_vecRowHeights[i];
		else
			for(i = m_lTopRow - 1; i >= lRow; i--)
				rc.top -= m_vecRowHeights[i];
	}
	rc.bottom = rc.top + m_vecRowHeights[i];
	// and cols...
	if(lCol < m_lNumFixedCols) // the row is within fixed
		for(i = 0; i < lCol; i++)
			rc.left += m_vecColWidths[i];
	else // the row is within normal
	{
		// calculate offset of the top visible row
		for(i = 0; i < m_lNumFixedCols; i++)
			rc.left += m_vecColWidths[i];
		// calculate offset of the cell
		if(lCol >= m_lTopCol)
			for(i = m_lTopCol; i < lCol; i++)
				rc.left += m_vecColWidths[i];
		else
			for(i = m_lTopCol - 1; i >= lCol; i--)
				rc.left -= m_vecColWidths[i];
	}
	rc.right = rc.left + m_vecColWidths[i];
}


// returns cell from given point on the screen.
// Arguments:
//		pt = in, coordinates of point
//		pptCellCoords = out, points to POINT structure to fill
//		prcCellRect = out, if not NULL, points to RECT structure to fill
//				in coordinates of the cell rect

void CLiteGrid::CellFromPoint(POINT pt, POINT * pptCellCoords, RECT * prcCell)
{
	int i, iOffset = 0;

	// the grid does not contain any cell
	if(m_lNumCols == 0 || m_lNumRows == 0)
	{
		pptCellCoords->x = -1;
		pptCellCoords->y = -1;
		return;
	}
	// determine row
	i = 0;
	if(m_lNumFixedRows != 0)
		do
			iOffset += m_vecRowHeights[i++];
		while(iOffset < pt.y && i < m_lNumFixedRows);
	if(iOffset < pt.y) // not within fixed rows
	{
		i = m_lTopRow;
		do
			iOffset += m_vecRowHeights[i++];
		while(iOffset < pt.y && i < m_lNumRows);
		if(i == m_lNumRows && iOffset < pt.y) // none cell
		{
			pptCellCoords->x = -1;
			pptCellCoords->y = -1;
			return;
		}
	}
	pptCellCoords->y = --i;
	if(prcCell != NULL)
	{
		prcCell->bottom = iOffset;
		prcCell->top = iOffset - m_vecRowHeights[i];
	}
	// determine column
	iOffset = i = 0;
	if(m_lNumFixedCols != 0)
		do
			iOffset += m_vecColWidths[i++];
		while(iOffset < pt.x && i < m_lNumFixedCols);
	if(iOffset < pt.x) // not within fixed rows
	{
		i = m_lTopCol;
		do
			iOffset += m_vecColWidths[i++];
		while(iOffset < pt.x && i < m_lNumCols);
		if(i == m_lNumCols && iOffset < pt.x) // none cell
		{
			pptCellCoords->x = -1;
			pptCellCoords->y = -1;
			return;
		}
	}
	pptCellCoords->x = --i;
	if(prcCell != NULL)
	{
		prcCell->right = iOffset;
		prcCell->left = iOffset - m_vecColWidths[i];
	}
}

// draws range of cells.
// Arguments:
//		hDC = in, device context to draw on
//		rcPaint = in, rectangle in which paint required
//		ptStartCoords = in, coordinates of the first cell in the range (top-left)
//		rcCells = in, starting and stopping cells
//		clr... = in, colors

void CLiteGrid::DrawCellRange(HDC hDC, RECT& rcPaint, POINT ptStartCoords, RECT & rcCells, COLORREF clrBk, COLORREF clrFg, COLORREF clrLightLine, COLORREF clrShadowLine)
{
	// save old DC's colors
	COLORREF clrOldBk = ::SetBkColor(hDC, clrBk);
	COLORREF clrOldText = ::SetTextColor(hDC, clrFg);
	HBRUSH hBackBrush = ::CreateSolidBrush(clrBk);
	RECT rcCell;
	int i, j, iRowOffset;
	HPEN hOldPen, hLightPen, hShadowPen;

	hLightPen = ::CreatePen(PS_SOLID, 1, clrLightLine);
	hShadowPen = ::CreatePen(PS_SOLID, 1, clrShadowLine);

	rcCell.top = rcCell.bottom = ptStartCoords.y;
	rcCell.left = rcCell.right = ptStartCoords.x;
	for(i = rcCells.top; i < rcCells.bottom; i++)
	{
		iRowOffset = i * m_lNumCols;
		rcCell.left = ptStartCoords.x;
		rcCell.bottom = rcCell.top + m_vecRowHeights[i];
		for(j = rcCells.left; j < rcCells.right; j++)
		{
			rcCell.right = rcCell.left + m_vecColWidths[j];
			if(rcCell.top < rcPaint.bottom && rcCell.left < rcPaint.right &&
				rcCell.bottom > rcPaint.top && rcCell.right > rcPaint.left)
			{
				::FillRect(hDC, &rcCell, hBackBrush);
				RECT rcTmp = rcCell;
				::InflateRect(&rcTmp, -2, -2);
#ifndef UNICODE	// translate double-char characters in BSTRs to single-char
				::DrawText(hDC, BSTRtoLPSTR(m_vecCellText[iRowOffset + j]), -1, &rcTmp, m_vecColAligns[j] | DT_VCENTER | DT_NOPREFIX | DT_SINGLELINE);
#else
				::DrawText(hDC, (BSTR)*m_vecCellText[iRowOffset + j], -1, &rcTmp, m_vecColAligns[j] | DT_VCENTER | DT_NOPREFIX | DT_SINGLELINE);
#endif
				// draw lines
				hOldPen = (HPEN)::SelectObject(hDC, hLightPen);
				::MoveToEx(hDC, rcCell.left, rcCell.bottom - 1, NULL);
				::LineTo(hDC, rcCell.left, rcCell.top);
				::LineTo(hDC, rcCell.right - 1, rcCell.top);
				::SelectObject(hDC, hOldPen);
				hOldPen = (HPEN)::SelectObject(hDC, hShadowPen);
				::LineTo(hDC, rcCell.right - 1, rcCell.bottom - 1);
				::LineTo(hDC, rcCell.left, rcCell.bottom - 1);
				::SelectObject(hDC, hOldPen);
			}
			rcCell.left = rcCell.right;
		}
		rcCell.top = rcCell.bottom;
	}
	// if we draw the last row or coll - erase rectangle which is out of cell area...
	RECT rcInvalidate, rc;
	GetClientRect(&rc);
	if(rcCells.right == m_lNumCols && rcCell.right < rc.right)
	{
		rcInvalidate = rc;
		rcInvalidate.left = rcCell.right;
		::FillRect(hDC, &rcInvalidate, (HBRUSH)(COLOR_3DSHADOW + 1));
	}
	if(rcCells.bottom == m_lNumRows && rcCell.bottom < rc.bottom)
	{
		rcInvalidate = rc;
		rcInvalidate.top = rcCell.bottom;
		::FillRect(hDC, &rcInvalidate, (HBRUSH)(COLOR_3DSHADOW + 1));
	}
	// restore previously set colors
	::SetTextColor(hDC, clrOldText);
	::SetBkColor(hDC, clrOldBk);
	::DeleteObject(hBackBrush);
	::DeleteObject(hLightPen);
	::DeleteObject(hShadowPen);
}

// changes currently selected cell. Scrolls the grid if needed
// Arguments:
//		lRow = in, new row
//		lCol = in, new column
//	Returns:
//		true - active cell was changed successfully
//		false - could not change active cell

bool CLiteGrid::ChangeActiveCell(long lRow, long lCol)
{
	if(lRow < m_lNumFixedRows || lRow >= m_lNumRows ||
		lCol < m_lNumFixedCols || lCol >= m_lNumCols)
		return false;

	// if loaded from stream - we can't determine top cell,
	// so just put it equal to the active cell !
	Fire_CellChanging(lRow, lCol);
	if(!::IsWindow(m_hWnd))
	{
		m_lRow = m_lTopRow = lRow;
		m_lCol = m_lTopCol = lCol;
		Fire_CellChanged();
		return true;
	}

	int i, iShift = 0;
	RECT rcClient, rcCell, rcTopVisibleCell, rcScroll;
	HDC hDC = GetDC();

	// erase old focused cell rectangle
	FocusCell(hDC, m_lRow, m_lCol, true);
	GetClientRect(&rcClient);
	GetCellRect(lRow, lCol, rcCell);
	GetCellRect(m_lTopRow, m_lTopCol, rcTopVisibleCell);
	if(lRow != m_lRow)
	{
		// determine vertical shift (it can be even negative)
		if(lRow < m_lRow)
		{
			if(lRow < m_lTopRow)	// scrolling needed!
			{
				iShift = rcTopVisibleCell.top - rcCell.top;
				m_lTopRow = lRow;
			}
		}
		else
		{
			if(rcCell.bottom > rcClient.bottom)
			{
				for(i = m_lTopRow; i < m_lNumRows; i++)
					if(rcCell.bottom + iShift <= rcClient.bottom || i == lRow)
						break;
					else
						iShift -= m_vecRowHeights[i];
				if(i == m_lNumRows)
					i--;
				m_lTopRow = i;
			}
		}
		if(iShift != 0)
		{
			rcScroll.top = rcTopVisibleCell.top;
			rcScroll.bottom = rcClient.bottom;
			rcScroll.left = rcClient.left;
			rcScroll.right = rcClient.right;
			if(!m_bFastDraw)
			{
				BOOL b = TRUE;
				ScrollWindowEx(0, iShift, &rcScroll, &rcScroll, NULL, NULL, SW_INVALIDATE);
				OnPaint(WM_PAINT, 0, 0, b);
				ValidateRect(&rcClient);
			}
			else
				ScrollWindowEx(0, iShift, &rcScroll, &rcScroll, NULL, NULL, SW_INVALIDATE);
		}
	}
	if(lCol != m_lCol)
	{
		iShift = 0;
		// determine horizontal shift
		if(lCol < m_lCol)
		{
			if(lCol < m_lTopCol)	// scrolling needed!
			{
				iShift = rcTopVisibleCell.left - rcCell.left;
				m_lTopCol = lCol;
			}
		}
		else
		{
			if(rcCell.right > rcClient.right)
			{
				for(i = m_lTopCol; i < m_lNumCols; i++)
					if(rcCell.right + iShift <= rcClient.right || i == lCol)
						break;
					else
						iShift -= m_vecColWidths[i];
				if(i == m_lNumCols)
					i--;
				m_lTopCol = i;
			}
		}
		if(iShift != 0)
		{
			rcScroll.left = rcTopVisibleCell.left;
			rcScroll.right = rcClient.right;
			rcScroll.bottom = rcClient.bottom;
			rcScroll.top = rcClient.top;
			if(!m_bFastDraw)
			{
				BOOL b = TRUE;
				ScrollWindowEx(iShift, 0, &rcScroll, &rcScroll, NULL, NULL, SW_INVALIDATE);
				OnPaint(WM_PAINT, 0, 0, b);
				ValidateRect(&rcClient);
			}
			else
				ScrollWindowEx(iShift, 0, &rcScroll, &rcScroll, NULL, NULL, SW_INVALIDATE);
		}
	}
	// draw focused rectangle around new focused cell
	FocusCell(hDC, m_lRow = lRow, m_lCol = lCol);
	ReleaseDC(hDC);
	SetScrollPos(SB_VERT, lRow);
	SetScrollPos(SB_HORZ, lCol);
	Fire_CellChanged();
	return true;
}

LRESULT CLiteGrid::OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	bResult = false;
	TCHAR tchCode = (TCHAR)wParam;

	Fire_KeyDown((short)wParam, GetVbShift());
	switch(tchCode)
	{
	case VK_UP:
		LineUp(LOWORD(lParam));
		break;
	case VK_DOWN:
		LineDn(LOWORD(lParam));
		break;
	case VK_LEFT:
		LineLeft(LOWORD(lParam));
		break;
	case VK_RIGHT:
		LineRight(LOWORD(lParam));
		break;
	case VK_PRIOR:
		PgUp();
		break;
	case VK_NEXT:
		PgDn();
		break;
	case VK_RETURN:
		TryStartEditing();
		break;
	default:
		bResult = false;
	}
	return 0;
}

// hilits selected cell
// Arguments:
//		hDC = in, handle of device context to draw on
//		lRow, lCol = in, row and column of the cell to hilite
//		bRemove = in, true indicates that the function was called to erase old selection

void CLiteGrid::FocusCell(HDC hDC, long lRow, long lCol, bool bRemove)
{
	RECT rcCell;
	GetCellRect(lRow, lCol, rcCell);
	// draw inverted text/background
	RECT rcCells;
	POINT ptStartCoords;
	HFONT hOldFont, hNewFont;

	rcCells.left = lCol; rcCells.right = lCol + 1;
	rcCells.top = lRow; rcCells.bottom = lRow + 1;
	ptStartCoords.x = rcCell.left;
	ptStartCoords.y = rcCell.top;
	m_pFontNormal->get_hFont(&hNewFont);
	hOldFont = (HFONT)::SelectObject(hDC, hNewFont);
	if(bRemove)
	{
		rcCell.bottom--; rcCell.right--;
		::DrawFocusRect(hDC, &rcCell);
		rcCell.bottom++; rcCell.right++;
		DrawCellRange(hDC, rcCell, ptStartCoords, rcCells, 
			OLE2RGB(m_ColorNormalBk), 
			OLE2RGB(m_ColorNormalFont),
			OLE2RGB(m_ColorNormalLight),
			OLE2RGB(m_ColorNormalShadow));
	}
	else
	{
		DrawCellRange(hDC, rcCell, ptStartCoords, rcCells, 
			~OLE2RGB(m_ColorNormalBk), 
			~OLE2RGB(m_ColorNormalFont),
			OLE2RGB(m_ColorNormalLight),
			OLE2RGB(m_ColorNormalShadow));
		rcCell.bottom--; rcCell.right--;
		::DrawFocusRect(hDC, &rcCell);
	}
	::SelectObject(hDC, hOldFont);
}

LRESULT CLiteGrid::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	// I want scroll bars
	LONG lStyle = GetWindowLong(GWL_STYLE);
	lStyle |= m_nScrollType;
	SetWindowLong(GWL_STYLE, lStyle);
	// proportional
	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.fMask = SIF_PAGE;
	si.nPage = 1;
	::SetScrollInfo(m_hWnd, SB_VERT, &si, TRUE);
	::SetScrollInfo(m_hWnd, SB_HORZ, &si, TRUE);
	// .. and don't want cursor flicker
	::SetClassLong(m_hWnd, GCL_HCURSOR, NULL);
	::SetClassLong(m_hWnd, GCL_HBRBACKGROUND, COLOR_3DSHADOW + 1);
	SetScrollRange(SB_HORZ, m_lNumFixedCols, m_lNumCols - 1);
	SetScrollRange(SB_VERT, m_lNumFixedRows, m_lNumRows - 1);
	// boolean props:
	if(m_bBorder)
		ModifyStyleEx(0, WS_EX_CLIENTEDGE);
	EnableWindow(m_bEnabled);
	if(!m_bVisible)
		ShowWindow(SW_HIDE);
	return 0;
}

LRESULT CLiteGrid::OnScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	int iScrollCode = LOWORD(wParam);
	if(uMsg == WM_VSCROLL) // vertical scrolling
	{
		switch(iScrollCode)
		{
		case SB_BOTTOM:
			ChangeActiveCell(m_lNumRows - 1, m_lCol);
			break;
		case SB_LINEDOWN:
			LineDn();
			break;
		case SB_LINEUP:
			LineUp();
			break;
		case SB_PAGEDOWN:
			PgDn();
			break;
		case SB_PAGEUP:
			PgUp();
			break;
		case SB_TOP:
			ChangeActiveCell(m_lNumFixedRows, m_lCol);
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			ChangeActiveCell(HIWORD(wParam), m_lCol);
		}
	}
	else	// horizontal scrolling
	{
		switch(iScrollCode)
		{
		case SB_BOTTOM:
			ChangeActiveCell(m_lRow, m_lNumCols - 1);
			break;
		case SB_TOP:
			ChangeActiveCell(m_lRow, m_lNumFixedCols);
			break;
		case SB_LINELEFT:
			LineLeft();
			break;
		case SB_LINERIGHT:
			LineRight();
			break;
		case SB_PAGELEFT:
			PgLeft();
			break;
		case SB_PAGERIGHT:
			PgRight();
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			ChangeActiveCell(m_lRow, HIWORD(wParam));
		}
	}
	return 0;
}

// moves selection several lines (rows) up
// Arguments:
//		iLines = in, number of rows to move selection

void CLiteGrid::LineUp(int iLines)
{
	if(m_lRow - iLines >= m_lNumFixedRows)
		ChangeActiveCell(m_lRow - iLines, m_lCol);
}

// moves selection several lines (rows) down
// Arguments:
//		iLines = in, number of rows to move selection

void CLiteGrid::LineDn(int iLines)
{
	if(m_lRow < m_lNumRows - iLines)
		ChangeActiveCell(m_lRow + iLines, m_lCol);
}

// moves selection several lines (cols) left
// Arguments:
//		iLines = in, number of cols to move selection

void CLiteGrid::LineLeft(int iLines)
{
	if(m_lCol - iLines >= m_lNumFixedCols)
		ChangeActiveCell(m_lRow, m_lCol - iLines);
}

// moves selection several lines (cols) right
// Arguments:
//		iLines = in, number of cols to move selection

void CLiteGrid::LineRight(int iLines)
{
	if(m_lCol < m_lNumCols - iLines)
		ChangeActiveCell(m_lRow, m_lCol + iLines);
}

void CLiteGrid::PgUp()
{
	RECT rc;
	GetCellRect(m_lRow, m_lCol, rc);
	for(int i = m_lRow - 1; i > m_lNumFixedRows; i--)
	{
		rc.top -= m_vecRowHeights[i];
		if(rc.top < 0)
			break;
	}
	if(i > 0)
		ChangeActiveCell(i, m_lCol);
}

void CLiteGrid::PgDn()
{
	RECT rc, rcClient;

	GetClientRect(&rcClient);
	GetCellRect(m_lRow, m_lCol, rc);
	for(int i = m_lRow; i < m_lNumRows; i++)
	{
		rc.top += m_vecRowHeights[i];
		if(rc.top >= rcClient.bottom)
			break;
	}
	ChangeActiveCell(i, m_lCol);
}

void CLiteGrid::PgLeft()
{
	RECT rc;
	GetCellRect(m_lRow, m_lCol, rc);
	for(int i = m_lCol - 1; i > m_lNumFixedCols; i--)
	{
		rc.left -= m_vecColWidths[i];
		if(rc.left < 0)
			break;
	}
	if(i > 0)
		ChangeActiveCell(m_lRow, i);
}

void CLiteGrid::PgRight()
{
	RECT rc, rcClient;

	GetClientRect(&rcClient);
	GetCellRect(m_lRow, m_lCol, rc);
	for(int i = m_lCol; i < m_lNumCols; i++)
	{
		rc.left += m_vecColWidths[i];
		if(rc.left >= rcClient.right)
			break;
	}
	ChangeActiveCell(m_lRow, i);
}

// called in response to these mouse events: WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP

LRESULT CLiteGrid::OnMouseEvents(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	RECT rcCell;
	POINT ptCell;
	POINT ptMouse;
	HCURSOR hc = NULL;

	ptMouse.x = LOWORD(lParam);
	ptMouse.y = HIWORD(lParam);
	CellFromPoint(ptMouse, &ptCell, &rcCell);
	if(uMsg == WM_MOUSEMOVE)
	{
		Fire_MouseMove(GetVbButtons(wParam), GetVbShift(), LOWORD(lParam), HIWORD(lParam));
		if(m_nState == STATE_WESIZING)
		{
			GetCellRect(0, m_lSizingCoord, rcCell);
			if(ptMouse.x >= rcCell.left + 2)	// do not allow zero size of the cell
			{
				DrawSizingLine(true);	// erase old sizing line
				m_lCurSizingSize = ptMouse.x;
				DrawSizingLine(true);
				hc = LoadCursor(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_LG_SIZEWE));
			}
		}
		else if(m_nState == STATE_NSSIZING)
		{
			GetCellRect(m_lSizingCoord, 0, rcCell);
			if(ptMouse.y >= rcCell.top + 2)
			{
				DrawSizingLine(false);
				m_lCurSizingSize = ptMouse.y;
				DrawSizingLine(false);
				hc = LoadCursor(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_LG_SIZENS));
			}
		}
		else if(ptMouse.x < rcCell.right + 3 && ptMouse.x > rcCell.right - 3 && m_bResizeCols)
		{
			if(ptCell.x == -1)
				return 0;
			hc = LoadCursor(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_LG_SIZEWE));
			m_nState = STATE_WESIZE_READY;
		}
		else if(ptMouse.y < rcCell.bottom + 3 && ptMouse.y > rcCell.bottom - 3 && m_bResizeRows)
		{
			if(ptCell.y == -1)
				return 0;
			hc = LoadCursor(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_LG_SIZENS));
			m_nState = STATE_NSSIZE_READY;
		}
		else
		{
			hc = LoadCursor(NULL, IDC_ARROW);
			m_nState = STATE_NORMAL;
		}
	}
	else if(uMsg == WM_LBUTTONDOWN)
	{
		Fire_MouseDown(GetVbButtons(wParam), GetVbShift(), LOWORD(lParam), HIWORD(lParam));
		Fire_Click();
		SetFocus();
		if(m_nState == STATE_NSSIZE_READY)
		{
			m_nState = STATE_NSSIZING;
			m_lCurSizingSize = ptMouse.y;
			m_lSizingCoord = ptCell.y;
			DrawSizingLine(false);
		}
		else if(m_nState == STATE_WESIZE_READY)
		{
			m_nState = STATE_WESIZING;
			m_lCurSizingSize = ptMouse.x;
			m_lSizingCoord = ptCell.x;
			DrawSizingLine(true);
		}
		else if(ptCell.x >= 0 && ptCell.y >= 0)
			ChangeActiveCell(ptCell.y, ptCell.x);
	}
	else if(uMsg == WM_LBUTTONUP)
	{
		Fire_MouseUp(GetVbButtons(wParam), GetVbShift(), LOWORD(lParam), HIWORD(lParam));
		if(m_nState == STATE_NSSIZING)
		{
			DrawSizingLine(false);
			GetCellRect(m_lSizingCoord, 0, rcCell);
			m_vecRowHeights[m_lSizingCoord] = m_lCurSizingSize - rcCell.top;
			Invalidate();
			m_nState = STATE_NSSIZE_READY;
		}
		else if(m_nState == STATE_WESIZING)
		{
			DrawSizingLine(true);
			GetCellRect(0, m_lSizingCoord, rcCell);
			m_vecColWidths[m_lSizingCoord] = m_lCurSizingSize - rcCell.left;
			Invalidate();
			m_nState = STATE_WESIZE_READY;
		}
	}
	if(hc != NULL)
		SetCursor(hc);
	bResult = false;
	return 0;
}

LRESULT CLiteGrid::OnKeyUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	Fire_KeyUp((short)wParam, GetVbShift());
	bResult = FALSE;
	return 0;
}

LRESULT CLiteGrid::OnChar(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	Fire_KeyPress((short)wParam);
	bResult = FALSE;
	return 0;
}

LRESULT CLiteGrid::OnEndInplaceEdit(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	VARIANT_BOOL bAllowChanges = TRUE;
	if(wParam == IDOK)
	{
#ifndef UNICODE
		CComBSTR bsTmp((LPSTR)lParam);
		Fire_EndEditing(bsTmp.m_str, &bAllowChanges);
		if(bAllowChanges)
			put_CellText(m_lRow, m_lCol, bsTmp.m_str);
#else
		Fire_EndEditing((BSTR)lParam, &bAllowChanges);
		if(bAllowChanges)
			put_CellText(m_lRow, m_lCol, (BSTR)lParam);
#endif
	}
	m_nState = STATE_NORMAL;
	return 0;
}

LRESULT CLiteGrid::OnLButtonDblClk(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult)
{
	TryStartEditing();
	return 0;
}

// draws line when sizing row or column
// Arguments:
//		bHorz = in, true if need to draw horizontal sizing line

void CLiteGrid::DrawSizingLine(bool bHorz)
{
	HDC hDC = GetDC();
	int iOldROP2 = ::SetROP2(hDC, R2_NOT);
	RECT rcClient;

	GetClientRect(&rcClient);
	if(bHorz)
	{
		::MoveToEx(hDC, m_lCurSizingSize, rcClient.top, NULL);
		::LineTo(hDC, m_lCurSizingSize, rcClient.bottom);
	}
	else
	{
		::MoveToEx(hDC, rcClient.left, m_lCurSizingSize, NULL);
		::LineTo(hDC, rcClient.right, m_lCurSizingSize);
	}
	::SetROP2(hDC, iOldROP2);
	ReleaseDC(hDC);
}

STDMETHODIMP CLiteGrid::get_FixedFont(LPFONTDISP* pVal)
{
	return m_pFontFixed->QueryInterface(IID_IDispatch, (void**)pVal);
}

STDMETHODIMP CLiteGrid::putref_FixedFont(LPFONTDISP newVal)
{
	m_pFontFixed->Release();
	if(newVal->QueryInterface(IID_IFont, (void**)&m_pFontFixed) == S_OK)
	{
		FireViewChange();
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CLiteGrid::get_NormalFont(LPFONTDISP* pVal)
{
	return m_pFontNormal->QueryInterface(IID_IDispatch, (void**)pVal);
	return S_OK;
}

STDMETHODIMP CLiteGrid::putref_NormalFont(LPFONTDISP newVal)
{
	m_pFontNormal->Release();
	if(newVal->QueryInterface(IID_IFont, (void**)&m_pFontNormal) == S_OK)
	{
		FireViewChange();
		return S_OK;
	}
	return E_FAIL;
}

STDMETHODIMP CLiteGrid::get_FixedBkColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorFixedBk;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedBkColor(OLE_COLOR newVal)
{
	if(newVal != m_ColorFixedBk)
	{
		m_ColorFixedBk = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_NormalBkColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorNormalBk;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_NormalBkColor(OLE_COLOR newVal)
{
	if(newVal != m_ColorNormalBk)
	{
		m_ColorNormalBk = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FixedTextColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorFixedFont;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedTextColor(OLE_COLOR newVal)
{
	if(newVal != m_ColorFixedFont)
	{
		m_ColorFixedFont = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_NormalTextColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorNormalFont;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_NormalTextColor(OLE_COLOR newVal)
{
	if(m_ColorNormalFont != newVal)
	{
		m_ColorNormalFont = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FixedLightColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorFixedLight;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedLightColor(OLE_COLOR newVal)
{
	if(m_ColorFixedLight != newVal)
	{
		m_ColorFixedLight = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FixedShadowColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorFixedShadow;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FixedShadowColor(OLE_COLOR newVal)
{
	if(m_ColorFixedShadow != newVal)
	{
		m_ColorFixedShadow = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_NormalLightColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorNormalLight;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_NormalLightColor(OLE_COLOR newVal)
{
	if(m_ColorNormalLight != newVal)
	{
		m_ColorNormalLight = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_NormalShadowColor(OLE_COLOR * pVal)
{
	*pVal = m_ColorNormalShadow;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_NormalShadowColor(OLE_COLOR newVal)
{
	if(m_ColorNormalShadow != newVal)
	{
		m_ColorNormalShadow = newVal;
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_IsEnabled(VARIANT_BOOL* pVal)
{
	*pVal = m_bEnabled;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_IsEnabled(VARIANT_BOOL newVal)
{
	m_bEnabled = newVal;
	if(::IsWindow(m_hWnd))
		EnableWindow((BOOL)newVal);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Visible(VARIANT_BOOL * pVal)
{
	*pVal = m_bVisible;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Visible(VARIANT_BOOL newVal)
{
	m_bVisible = newVal;
	if(::IsWindow(m_hWnd))
		ShowWindow(newVal ? SW_SHOW : SW_HIDE);
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_Border(VARIANT_BOOL * pVal)
{
	*pVal = m_bBorder;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Border(VARIANT_BOOL newVal)
{
	m_bBorder = newVal;
	if(::IsWindow(m_hWnd))
	{
		if(newVal)
			ModifyStyleEx(0, WS_EX_CLIENTEDGE);
		else
			ModifyStyleEx(WS_EX_CLIENTEDGE, 0);
	}
	FireViewChange();
	return S_OK;
}


STDMETHODIMP CLiteGrid::get_CellTop(long * pVal)
{
	RECT rc;

	GetCellRect(m_lRow, m_lCol, rc);
	*pVal = rc.top;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_CellLeft(long * pVal)
{
	RECT rc;

	GetCellRect(m_lRow, m_lCol, rc);
	*pVal = rc.left;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_CellWidth(long * pVal)
{
	RECT rc;

	GetCellRect(m_lRow, m_lCol, rc);
	*pVal = (long)rc.right - rc.left;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_CellHeight(long * pVal)
{
	RECT rc;

	GetCellRect(m_lRow, m_lCol, rc);
	*pVal = (long)rc.bottom - rc.top;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_ResizeRows(VARIANT_BOOL * pVal)
{
	*pVal = (VARIANT_BOOL)m_bResizeRows;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_ResizeRows(VARIANT_BOOL newVal)
{
	m_bResizeRows = (bool)newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_ResizeCols(VARIANT_BOOL * pVal)
{
	*pVal = (VARIANT_BOOL)m_bResizeCols;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_ResizeCols(VARIANT_BOOL newVal)
{
	m_bResizeCols = (bool)newVal;
	return S_OK;
}

// starts inplace editing if it is possible
// Returns:
//		true if inplace editing successfully started

bool CLiteGrid::TryStartEditing()
{
	if(!m_bEditable)
		return false;
	VARIANT_BOOL bAllowChanges = TRUE;
	Fire_StartEditing(&bAllowChanges);
	if(!bAllowChanges)
		return false;
	RECT rc;
	GetCellRect(m_lRow, m_lCol, rc);
	rc.bottom--; rc.right--;
	HFONT hf;
	m_pFontNormal->get_hFont(&hf);
	CComBSTR* pbsTmp = m_vecCellText[m_lRow * m_lNumCols + m_lCol];
#ifndef UNICODE	// translate double-char characters in BSTRs to single-char
	if(m_wndInplaceEdit.StartEditing(&rc, BSTRtoLPSTR(pbsTmp), hf))
	{
#else
	if(m_wndInplaceEdit.StartEditing(&rc, (LPWSTR)pbsTmp->m_str, hf))
	{
#endif
		m_nState = STATE_INPLACEEDITING;	
		return true;
	}
	return false;
}

STDMETHODIMP CLiteGrid::get_Editable(VARIANT_BOOL * pVal)
{
	*pVal = (VARIANT_BOOL)m_bEditable;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_Editable(VARIANT_BOOL newVal)
{
	if(newVal == FALSE && m_nState == STATE_INPLACEEDITING)
		SetFocus();	// stop inplace editing with IDCANCEL result
	m_bEditable = (bool)newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_ScrollBars(SCROLL_BAR_TYPE * pVal)
{
	*pVal = m_nScrollType;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_ScrollBars(SCROLL_BAR_TYPE newVal)
{
	if(newVal != m_nScrollType)
	{
		m_nScrollType = newVal;
		if(::IsWindow(m_hWnd))
			ModifyStyle(WS_HSCROLL | WS_VSCROLL, newVal);
		FireViewChange();
	}
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_FastDraw(VARIANT_BOOL * pVal)
{
	*pVal = (VARIANT_BOOL)m_bFastDraw;
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_FastDraw(VARIANT_BOOL newVal)
{
	m_bFastDraw = (bool)newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_ColAlign(long lCol, lgColAlignType *pVal)
{
	if(lCol < 0 || lCol >= m_lNumCols)
		return E_INVALIDARG;
	*pVal = (lgColAlignType)m_vecColAligns[lCol];
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_ColAlign(long lCol, lgColAlignType newVal)
{
	if(lCol < 0 || lCol >= m_lNumCols)
		return E_INVALIDARG;
	m_vecColAligns[lCol] = newVal;
	FireViewChange();
	return S_OK;
}

STDMETHODIMP CLiteGrid::get_DefaultColAlign(lgColAlignType * pVal)
{
	*pVal = (lgColAlignType)m_lDefColAlign;	
	return S_OK;
}

STDMETHODIMP CLiteGrid::put_DefaultColAlign(lgColAlignType newVal)
{
	m_lDefColAlign = newVal;
	return S_OK;
}

STDMETHODIMP CLiteGrid::GetFixedTextWidth(BSTR bsText, LONG* pResult)
{
	if(::IsWindow(m_hWnd))
		*pResult = GetTextWidth(bsText, m_pFontFixed);
	else
		*pResult = 100;
	return S_OK;
}

STDMETHODIMP CLiteGrid::GetNormalTextWidth(BSTR bsText, LONG* pResult)
{
	if(::IsWindow(m_hWnd))
		*pResult = GetTextWidth(bsText, m_pFontNormal);
	else
		*pResult = 100;
	return S_OK;
}

// calculates test string width in pixels for the given font
// Arguments:
//		bsText = in, string which width to calculate
//		pFont = in, pointer to font for which calculate the width
// Returns:
//		width of the string drawn using the font in pixels

long CLiteGrid::GetTextWidth(BSTR bsText, IFont * pFont)
{
	HFONT hOldFont, hNewFont;
	HDC hDC;
	SIZE sizText;

	pFont->get_hFont(&hNewFont);
	hDC = GetDC();
	hOldFont = (HFONT)::SelectObject(hDC, hNewFont);
#ifndef UNICODE
	CComBSTR* pbsTmp = new CComBSTR(bsText);
	::GetTextExtentPoint32(hDC, BSTRtoLPSTR(pbsTmp), ::SysStringLen(bsText), &sizText);
	delete pbsTmp;
#else
	::GetTextExtentPoint32(hDC, bsText, ::SysStringLen(bsText), &sizText);
#endif
	::SelectObject(hDC, hOldFont);
	ReleaseDC(hDC);
	return sizText.cx + 2;
}