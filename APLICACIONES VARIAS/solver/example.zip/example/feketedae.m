function feketedae
% FEKETEDAE is an index 2 DAE from mechanics. The dimension is 8N, 
%   where N is a user supplied integer. The numerical tests shown here 
%   correspond to N = 20. The problem is of interest for the computation 
%   of the elliptic Fekete points from
%
%    P.M. Pardalos. An open global optimization problem on the unit sphere.
%    Journal of Global Optimization, 6:213, 1995.
%
%   See also ODEBIM, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameter, N is shared with the nested function.
N=20;

mas = sparse(160,160);
mas(1:6*N,1:6*N) = speye(6*N);

% use a consistent initial condition.
y0 = init();

tspan = [0 1000];

options = odeset('Jacobian',@pderv,'Mass',mas, 'stats','on','refine',4,'Daeindex',[120,40,0]);

[t,y] = odebim(@f_eval,tspan,y0,options);

figure;
subplot(2,3,1); plot(t,y(:,1));title('y_1');axis([0 20 -0.38 -0.26]);
subplot(2,3,2); plot(t,y(:,2));title('y_2');axis([0 20 0.25 0.45]);
subplot(2,3,3); plot(t,y(:,3));title('y_3');axis([0 20 0.82 0.94]);
subplot(2,3,4); plot(t,y(:,4));title('y_4');axis([0 20 -0.15 0.15]);
subplot(2,3,5); plot(t,y(:,5));title('y_5');axis([0 20 -0.5 -0.3]);
subplot(2,3,6); plot(t,y(:,6));title('y_6');axis([0 20 0.86 0.96]);
% -----------------------------------------------------------------------
% Nested function, N is provided by the outer function.
%
    function y0 = init()
        y0(1) = 0d0;
        y0(2) = 0d0;
        y0(3) = 0d0;

        for i=1:3
            alpha=2*pi*i/3+pi/13;
            beta=3*pi/8;
            y0(3*(i-1)+1)=cos(alpha)*cos(beta);
            y0(3*(i-1)+2)=sin(alpha)*cos(beta);
            y0(3*(i-1)+3)=sin(beta);
        end

        for i=4:10
            alpha=2*pi*(i-3)/7+pi/29;
            beta=pi/8;
            y0(3*(i-1)+1)=cos(alpha)*cos(beta);
            y0(3*(i-1)+2)=sin(alpha)*cos(beta);
            y0(3*(i-1)+3)=sin(beta);
        end

        for i=11:16
            alpha=2*pi*(i-10)/(6)+pi/(7);
            beta=-2*pi/(15);
            y0(3*(i-1)+1)=cos(alpha)*cos(beta);
            y0(3*(i-1)+2)=sin(alpha)*cos(beta);
            y0(3*(i-1)+3)=sin(beta);
        end

        for i=17:20
            alpha=2*pi*(i-17)/(4)+pi/(17);
            beta=-3*pi/(10);
            y0(3*(i-1)+1)=cos(alpha)*cos(beta);
            y0(3*(i-1)+2)=sin(alpha)*cos(beta);
            y0(3*(i-1)+3)=sin(beta);
        end

        for i=(3*N+1):(6*N)
            y0(i)=0d0;
        end

        for i=(6*N+1):(8*N)
            y0(i)=0d0;
        end

        yprime = f_eval(0,y0);

        for i=1:N
            for j=1:3
                y0(6*N+i)=y0(6*N+i)+y0(3*(i-1)+j)*...
                    yprime(3*N+3*(i-1)+j);
            end
            y0(6*N+i)=-y0(6*N+i)/2d0;
        end

    end
% -----------------------------------------------------------------------
% Nested function, N is provided by the outer function.
%
    function dy =f_eval(t,y)
    % Derivative function.
        dy = zeros(8*N,1);
        alpha=0.5;
        
        p = zeros(N,3);
        q = zeros(N,3);
        lam = zeros(N,1);
        mu = zeros(N,1);
        for i=1:N
            for k=1:3
                p(i,k)=y(3*(i-1)+k);
                q(i,k)=y(3*N+3*(i-1)+k);
            end
            lam(i)=y(6*N+i);
            mu(i)=y(7*N+i);
        end
        
        fa = zeros(N,N,3);
        for i=1:N
            for j=1:N
                if(i==j)
                    for k=1:3
                        fa(i,j,k)=0d0;
                    end

                else
                    rn=0d0;
                    for k=1:3
                        rn=rn+(p(i,k)-p(j,k))^2;
                    end

                    for k=1:3
                        fa(i,j,k)=(p(i,k)-p(j,k))/rn;
                    end

                end

            end
        end

        pp = zeros(N,3);
        qp = zeros(N,3);
        for i=1:N
            for k=1:3
                pp(i,k)=q(i,k)+2*mu(i)*p(i,k);
                qp(i,k)=-alpha*q(i,k)+2*lam(i)*p(i,k);

                for j=1:N
                    qp(i,k)=qp(i,k)+fa(i,j,k);
                end
            end
        end

        phi = -ones(N,1);
        gpq = zeros(N,1);
        for i=1:N
            for k=1:3
                phi(i)=phi(i)+p(i,k)^2;
                gpq(i)=gpq(i)+2*p(i,k)*q(i,k);
            end
        end

        for i=1:N
            for k=1:3
                dy(3*(i-1)+k)=pp(i,k);
                dy(3*N+3*(i-1)+k)=qp(i,k);
            end
            dy(6*N+i)=phi(i);
            dy(7*N+i)=gpq(i);
        end

    end
% -----------------------------------------------------------------------
% Nested function, N is provided by the outer function.
%
    function dfy = pderv(t,y)
    % Jacobian function. 
        dfy= sparse(8*N,8*N);
        alpha=.5d0;

        p = zeros(N,3);
        q = zeros(N,3);
        lam = zeros(N,1);
        mu = zeros(N,1);
        for i=1:N
            for k=1:3
                p(i,k)=y(3*(i-1)+k);
                q(i,k)=y(3*N+3*(i-1)+k);
            end
            lam(i)=y(6*N+i);
            mu(i)=y(7*N+i);
        end

        rn = zeros(N,N);
        for j=1:N
            for i=1:N
                for k=1:3
                    rn(i,j)=rn(i,j)+(p(i,k)-p(j,k))^2;
                end
            end
        end

        %j_pp
        for i=1:N
            for k=1:3
                dfy(3*(i-1)+k,3*(i-1)+k)=2d0*mu(i);
            end
        end

        %j_pq
        for i=1:N
            for k=1:3
                dfy(3*(i-1)+k,3*N+3*(i-1)+k)=1d0;
            end
        end

        %j_pm
        for i=1:N
            for k=1:3
                dfy(3*(i-1)+k,7*N+i)=2d0*p(i,k);
            end
        end

        %j_qp
        for i=1:N
            for k=1:3
                dfy(3*N+3*(i-1)+k,3*(i-1)+k)=2d0*lam(i);
                for j=1:N
                    if(j~=i)
                        dfy(3*N+3*(i-1)+k,3*(i-1)+k)=...
                            dfy(3*N+3*(i-1)+k,3*(i-1)+k)+...
                            (rn(i,j)-2d0*(p(i,k)-p(j,k))^2)/rn(i,j)^2;
                    end
                end
            end
        end

        %j_qp
        for i=1:N
            for k=1:3
                for m=1:3
                    if(m~=k)
                        for j=1:N
                            if(j~=i)
                                dfy(3*N+3*(i-1)+k,3*(i-1)+m)=...
                                    dfy(3*N+3*(i-1)+k,3*(i-1)+m)-...
                                    2d0*(p(i,k)-p(j,k))*(p(i,m)-p(j,m))/...
                                    rn(i,j)^2;
                            end
                        end
                    end
                end
            end
        end

        %j_qp
        for i=1:N
            for l=1:N
                if(l~=i)
                    for k=1:3
                        dfy(3*N+3*(i-1)+k,3*(l-1)+k)=...
                            (-rn(i,l)+2d0*(p(i,k)-p(l,k))^2)/rn(i,l)^2;
                    end
                end
            end
        end

        %j_qp

        for i=1:N
            for l=1:N
                if(l~=i)
                    for k=1:3
                        for m=1:3
                            if(m~=k)
                                dfy(3*N+3*(i-1)+k,3*(l-1)+m)=...
                                    2d0*(p(i,k)-p(l,k))*(p(i,m)-p(l,m))/...
                                    rn(i,l)^2;
                            end
                        end
                    end
                end
            end
        end


        %j_qq
        for i=1:N
            for k=1:3
                dfy(3*N+3*(i-1)+k,3*N+3*(i-1)+k)=-alpha;
            end
        end

        %j_ql
        for i=1:N
            for k=1:3
                dfy(3*N+3*(i-1)+k,6*N+i)=2d0*p(i,k);
            end
        end


        %j_lp
        for i=1:N
            for k=1:3
                dfy(6*N+i,3*(i-1)+k)=2d0*p(i,k);
            end
        end


        %j_mp
        for i=1:N
            for k=1:3
                dfy(7*N+i,3*(i-1)+k)=2d0*q(i,k);
            end
        end

        %j_mq
        for i=1:N
            for k=1:3
                dfy(7*N+i,3*N+3*(i-1)+k)=2d0*p(i,k);
            end
        end
        
    end

end

