// InplaceEdit.cpp: implementation of the CInplaceEdit class.
// Copyright (C) 1999 Andrew Ivannikov. None rights reserved.
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InplaceEdit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInplaceEdit::CInplaceEdit(CWindow* pParent)
: m_pParent(pParent){}

// starts editing. Creates EDIT control, sets coordinates, initial text and font
// Parameters:
//		rcCoords =	in, coordinates of EDIT control
//		szInitialText	=	in, initial text which will appear in EDIT after it has been created
//		hFont	=	in, HANDLE of font of the EDIT
// Return value:
//		true - the corresponding EDIT control has successfully created and ready for user input
//		false - some error occured during preparation of the EDIT control

bool CInplaceEdit::StartEditing(LPRECT rcCoords, LPCTSTR szInitialText, HFONT hFont)
{
	if(!::IsWindow(m_pParent->m_hWnd) || ::IsWindow(m_hWnd))
		return false;
	HWND hTmp = ::CreateWindow(
		TEXT("EDIT"),
		NULL,
		WS_CHILD | ES_AUTOHSCROLL,
		rcCoords->left, rcCoords->top,
		rcCoords->right - rcCoords->left, rcCoords->bottom - rcCoords->top,
		m_pParent->m_hWnd,
		NULL,
		_Module.GetModuleInstance(),
		NULL);
	if(hTmp == NULL)
		return false;
	SubclassWindow(hTmp);
	if(hFont)
		SetFont(hFont);
	SetWindowText(szInitialText);
	ShowWindow(SW_SHOW);
	SetFocus();
	return true;
}

LRESULT CInplaceEdit::OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if((int)wParam == VK_RETURN)
		StopEditing(IDOK);
	else if((int)wParam == VK_ESCAPE)
		StopEditing(IDCANCEL);
	else
		bHandled = FALSE;
	return 0;
}

LRESULT CInplaceEdit::OnDoubleClick(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	StopEditing(IDOK);
	return 0;
}

LRESULT CInplaceEdit::OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	// stops editing assuming that a user do not want
	// to save changes
	StopEditing(IDCANCEL);
	return 0;
}

// terminates EDIT control and sends WM_ENDEDIT (see header file) message
//	to the parent window.
// Parameters:
//		uCode	= code which tells how a user has ended editing (see EM_ENDEDIT's WPARAM)

void CInplaceEdit::StopEditing(WPARAM uCode)
{
	if(::IsWindow(m_pParent->m_hWnd))
	{
		TCHAR tchBuf[1024];
		GetWindowText(tchBuf, 1023);
		m_pParent->SendMessage(WM_ENDEDIT, uCode, (LPARAM)tchBuf);
		DestroyWindow();
	}
}