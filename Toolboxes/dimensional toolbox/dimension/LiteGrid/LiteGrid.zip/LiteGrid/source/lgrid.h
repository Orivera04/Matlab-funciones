/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Sat Oct 02 16:36:44 1999
 */
/* Compiler settings for lgrid.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"

#ifndef __lgrid_h__
#define __lgrid_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ILiteGrid_FWD_DEFINED__
#define __ILiteGrid_FWD_DEFINED__
typedef interface ILiteGrid ILiteGrid;
#endif 	/* __ILiteGrid_FWD_DEFINED__ */


#ifndef ___LiteGridEvents_FWD_DEFINED__
#define ___LiteGridEvents_FWD_DEFINED__
typedef interface _LiteGridEvents _LiteGridEvents;
#endif 	/* ___LiteGridEvents_FWD_DEFINED__ */


#ifndef __LiteGrid_FWD_DEFINED__
#define __LiteGrid_FWD_DEFINED__

#ifdef __cplusplus
typedef class LiteGrid LiteGrid;
#else
typedef struct LiteGrid LiteGrid;
#endif /* __cplusplus */

#endif 	/* __LiteGrid_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/****************************************
 * Generated header for interface: __MIDL_itf_lgrid_0000
 * at Sat Oct 02 16:36:44 1999
 * using MIDL 3.01.75
 ****************************************/
/* [local] */ 


typedef /* [public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_lgrid_0000_0001
    {	lgBothScrollBars	= 0x300000,
	lgHorzScrollBar	= 0x100000,
	lgVertScrollBar	= 0x200000,
	lgNonScrollBars	= 0
    }	SCROLL_BAR_TYPE;

typedef /* [public][public][public][public][public][uuid] */ 
enum __MIDL___MIDL_itf_lgrid_0000_0002
    {	lgAlignLeft	= 0,
	lgAlignCenter	= 1,
	lgAlignRight	= 2
    }	lgColAlignType;



extern RPC_IF_HANDLE __MIDL_itf_lgrid_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_lgrid_0000_v0_0_s_ifspec;


#ifndef __LGRIDLib_LIBRARY_DEFINED__
#define __LGRIDLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: LGRIDLib
 * at Sat Oct 02 16:36:44 1999
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_LGRIDLib;

#ifndef __ILiteGrid_INTERFACE_DEFINED__
#define __ILiteGrid_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: ILiteGrid
 * at Sat Oct 02 16:36:44 1999
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_ILiteGrid;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("68523E4F-56EB-11D3-B739-CAA1986A452F")
    ILiteGrid : public IDispatch
    {
    public:
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Window( 
            /* [retval][out] */ long __RPC_FAR *phwnd) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedRows( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedRows( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedCols( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedCols( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Rows( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Rows( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Cols( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Cols( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CellText( 
            long lRow,
            long lCol,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_CellText( 
            long lRow,
            long lCol,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColWidth( 
            long lCol,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColWidth( 
            long lCol,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RowHeight( 
            long lRow,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RowHeight( 
            long lRow,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DefaultColWidth( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DefaultColWidth( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DefaultRowHeight( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DefaultRowHeight( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Row( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Row( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Col( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Col( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedFont( 
            /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propputref] */ HRESULT STDMETHODCALLTYPE putref_FixedFont( 
            /* [in] */ LPFONTDISP newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NormalFont( 
            /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propputref] */ HRESULT STDMETHODCALLTYPE putref_NormalFont( 
            /* [in] */ LPFONTDISP pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedBkColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedBkColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NormalBkColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_NormalBkColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedTextColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedTextColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NormalTextColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_NormalTextColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedLightColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedLightColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FixedShadowColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FixedShadowColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NormalLightColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_NormalLightColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NormalShadowColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_NormalShadowColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_IsEnabled( 
            /* [in] */ VARIANT_BOOL vbool) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_IsEnabled( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Visible( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_Visible( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Border( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_Border( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CellTop( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CellLeft( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CellWidth( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CellHeight( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ResizeRows( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ResizeRows( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ResizeCols( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ResizeCols( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Editable( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Editable( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ScrollBars( 
            /* [retval][out] */ SCROLL_BAR_TYPE __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ScrollBars( 
            /* [in] */ SCROLL_BAR_TYPE newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FastDraw( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FastDraw( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColAlign( 
            long lCol,
            /* [retval][out] */ lgColAlignType __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColAlign( 
            long lCol,
            /* [in] */ lgColAlignType newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DefaultColAlign( 
            /* [retval][out] */ lgColAlignType __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DefaultColAlign( 
            /* [in] */ lgColAlignType newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetFixedTextWidth( 
            /* [in] */ BSTR bsText,
            /* [retval][out] */ LONG __RPC_FAR *pResult) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetNormalTextWidth( 
            /* [in] */ BSTR bsText,
            /* [retval][out] */ LONG __RPC_FAR *pResult) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILiteGridVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILiteGrid __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILiteGrid __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ILiteGrid __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Window )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *phwnd);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedRows )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedRows )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedCols )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedCols )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Rows )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Rows )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Cols )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Cols )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CellText )( 
            ILiteGrid __RPC_FAR * This,
            long lRow,
            long lCol,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CellText )( 
            ILiteGrid __RPC_FAR * This,
            long lRow,
            long lCol,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColWidth )( 
            ILiteGrid __RPC_FAR * This,
            long lCol,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColWidth )( 
            ILiteGrid __RPC_FAR * This,
            long lCol,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RowHeight )( 
            ILiteGrid __RPC_FAR * This,
            long lRow,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RowHeight )( 
            ILiteGrid __RPC_FAR * This,
            long lRow,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultColWidth )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultColWidth )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultRowHeight )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultRowHeight )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Row )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Row )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Col )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Col )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedFont )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal);
        
        /* [helpstring][id][propputref] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_FixedFont )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ LPFONTDISP newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NormalFont )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal);
        
        /* [helpstring][id][propputref] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_NormalFont )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ LPFONTDISP pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedBkColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedBkColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NormalBkColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_NormalBkColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedTextColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedTextColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NormalTextColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_NormalTextColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedLightColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedLightColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FixedShadowColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FixedShadowColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NormalLightColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_NormalLightColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NormalShadowColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_NormalShadowColor )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_IsEnabled )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL vbool);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsEnabled )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Visible )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Visible )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Border )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Border )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CellTop )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CellLeft )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CellWidth )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CellHeight )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ResizeRows )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ResizeRows )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ResizeCols )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ResizeCols )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Editable )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Editable )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ScrollBars )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ SCROLL_BAR_TYPE __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ScrollBars )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ SCROLL_BAR_TYPE newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FastDraw )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FastDraw )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColAlign )( 
            ILiteGrid __RPC_FAR * This,
            long lCol,
            /* [retval][out] */ lgColAlignType __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColAlign )( 
            ILiteGrid __RPC_FAR * This,
            long lCol,
            /* [in] */ lgColAlignType newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DefaultColAlign )( 
            ILiteGrid __RPC_FAR * This,
            /* [retval][out] */ lgColAlignType __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DefaultColAlign )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ lgColAlignType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFixedTextWidth )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ BSTR bsText,
            /* [retval][out] */ LONG __RPC_FAR *pResult);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNormalTextWidth )( 
            ILiteGrid __RPC_FAR * This,
            /* [in] */ BSTR bsText,
            /* [retval][out] */ LONG __RPC_FAR *pResult);
        
        END_INTERFACE
    } ILiteGridVtbl;

    interface ILiteGrid
    {
        CONST_VTBL struct ILiteGridVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILiteGrid_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILiteGrid_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILiteGrid_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILiteGrid_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ILiteGrid_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ILiteGrid_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ILiteGrid_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ILiteGrid_get_Window(This,phwnd)	\
    (This)->lpVtbl -> get_Window(This,phwnd)

#define ILiteGrid_get_FixedRows(This,pVal)	\
    (This)->lpVtbl -> get_FixedRows(This,pVal)

#define ILiteGrid_put_FixedRows(This,newVal)	\
    (This)->lpVtbl -> put_FixedRows(This,newVal)

#define ILiteGrid_get_FixedCols(This,pVal)	\
    (This)->lpVtbl -> get_FixedCols(This,pVal)

#define ILiteGrid_put_FixedCols(This,newVal)	\
    (This)->lpVtbl -> put_FixedCols(This,newVal)

#define ILiteGrid_get_Rows(This,pVal)	\
    (This)->lpVtbl -> get_Rows(This,pVal)

#define ILiteGrid_put_Rows(This,newVal)	\
    (This)->lpVtbl -> put_Rows(This,newVal)

#define ILiteGrid_get_Cols(This,pVal)	\
    (This)->lpVtbl -> get_Cols(This,pVal)

#define ILiteGrid_put_Cols(This,newVal)	\
    (This)->lpVtbl -> put_Cols(This,newVal)

#define ILiteGrid_get_CellText(This,lRow,lCol,pVal)	\
    (This)->lpVtbl -> get_CellText(This,lRow,lCol,pVal)

#define ILiteGrid_put_CellText(This,lRow,lCol,newVal)	\
    (This)->lpVtbl -> put_CellText(This,lRow,lCol,newVal)

#define ILiteGrid_get_ColWidth(This,lCol,pVal)	\
    (This)->lpVtbl -> get_ColWidth(This,lCol,pVal)

#define ILiteGrid_put_ColWidth(This,lCol,newVal)	\
    (This)->lpVtbl -> put_ColWidth(This,lCol,newVal)

#define ILiteGrid_get_RowHeight(This,lRow,pVal)	\
    (This)->lpVtbl -> get_RowHeight(This,lRow,pVal)

#define ILiteGrid_put_RowHeight(This,lRow,newVal)	\
    (This)->lpVtbl -> put_RowHeight(This,lRow,newVal)

#define ILiteGrid_get_DefaultColWidth(This,pVal)	\
    (This)->lpVtbl -> get_DefaultColWidth(This,pVal)

#define ILiteGrid_put_DefaultColWidth(This,newVal)	\
    (This)->lpVtbl -> put_DefaultColWidth(This,newVal)

#define ILiteGrid_get_DefaultRowHeight(This,pVal)	\
    (This)->lpVtbl -> get_DefaultRowHeight(This,pVal)

#define ILiteGrid_put_DefaultRowHeight(This,newVal)	\
    (This)->lpVtbl -> put_DefaultRowHeight(This,newVal)

#define ILiteGrid_get_Row(This,pVal)	\
    (This)->lpVtbl -> get_Row(This,pVal)

#define ILiteGrid_put_Row(This,newVal)	\
    (This)->lpVtbl -> put_Row(This,newVal)

#define ILiteGrid_get_Col(This,pVal)	\
    (This)->lpVtbl -> get_Col(This,pVal)

#define ILiteGrid_put_Col(This,newVal)	\
    (This)->lpVtbl -> put_Col(This,newVal)

#define ILiteGrid_get_FixedFont(This,pVal)	\
    (This)->lpVtbl -> get_FixedFont(This,pVal)

#define ILiteGrid_putref_FixedFont(This,newVal)	\
    (This)->lpVtbl -> putref_FixedFont(This,newVal)

#define ILiteGrid_get_NormalFont(This,pVal)	\
    (This)->lpVtbl -> get_NormalFont(This,pVal)

#define ILiteGrid_putref_NormalFont(This,pVal)	\
    (This)->lpVtbl -> putref_NormalFont(This,pVal)

#define ILiteGrid_get_FixedBkColor(This,pVal)	\
    (This)->lpVtbl -> get_FixedBkColor(This,pVal)

#define ILiteGrid_put_FixedBkColor(This,newVal)	\
    (This)->lpVtbl -> put_FixedBkColor(This,newVal)

#define ILiteGrid_get_NormalBkColor(This,pVal)	\
    (This)->lpVtbl -> get_NormalBkColor(This,pVal)

#define ILiteGrid_put_NormalBkColor(This,newVal)	\
    (This)->lpVtbl -> put_NormalBkColor(This,newVal)

#define ILiteGrid_get_FixedTextColor(This,pVal)	\
    (This)->lpVtbl -> get_FixedTextColor(This,pVal)

#define ILiteGrid_put_FixedTextColor(This,newVal)	\
    (This)->lpVtbl -> put_FixedTextColor(This,newVal)

#define ILiteGrid_get_NormalTextColor(This,pVal)	\
    (This)->lpVtbl -> get_NormalTextColor(This,pVal)

#define ILiteGrid_put_NormalTextColor(This,newVal)	\
    (This)->lpVtbl -> put_NormalTextColor(This,newVal)

#define ILiteGrid_get_FixedLightColor(This,pVal)	\
    (This)->lpVtbl -> get_FixedLightColor(This,pVal)

#define ILiteGrid_put_FixedLightColor(This,newVal)	\
    (This)->lpVtbl -> put_FixedLightColor(This,newVal)

#define ILiteGrid_get_FixedShadowColor(This,pVal)	\
    (This)->lpVtbl -> get_FixedShadowColor(This,pVal)

#define ILiteGrid_put_FixedShadowColor(This,newVal)	\
    (This)->lpVtbl -> put_FixedShadowColor(This,newVal)

#define ILiteGrid_get_NormalLightColor(This,pVal)	\
    (This)->lpVtbl -> get_NormalLightColor(This,pVal)

#define ILiteGrid_put_NormalLightColor(This,newVal)	\
    (This)->lpVtbl -> put_NormalLightColor(This,newVal)

#define ILiteGrid_get_NormalShadowColor(This,pVal)	\
    (This)->lpVtbl -> get_NormalShadowColor(This,pVal)

#define ILiteGrid_put_NormalShadowColor(This,newVal)	\
    (This)->lpVtbl -> put_NormalShadowColor(This,newVal)

#define ILiteGrid_put_IsEnabled(This,vbool)	\
    (This)->lpVtbl -> put_IsEnabled(This,vbool)

#define ILiteGrid_get_IsEnabled(This,pbool)	\
    (This)->lpVtbl -> get_IsEnabled(This,pbool)

#define ILiteGrid_get_Visible(This,pVal)	\
    (This)->lpVtbl -> get_Visible(This,pVal)

#define ILiteGrid_put_Visible(This,newVal)	\
    (This)->lpVtbl -> put_Visible(This,newVal)

#define ILiteGrid_get_Border(This,pVal)	\
    (This)->lpVtbl -> get_Border(This,pVal)

#define ILiteGrid_put_Border(This,newVal)	\
    (This)->lpVtbl -> put_Border(This,newVal)

#define ILiteGrid_get_CellTop(This,pVal)	\
    (This)->lpVtbl -> get_CellTop(This,pVal)

#define ILiteGrid_get_CellLeft(This,pVal)	\
    (This)->lpVtbl -> get_CellLeft(This,pVal)

#define ILiteGrid_get_CellWidth(This,pVal)	\
    (This)->lpVtbl -> get_CellWidth(This,pVal)

#define ILiteGrid_get_CellHeight(This,pVal)	\
    (This)->lpVtbl -> get_CellHeight(This,pVal)

#define ILiteGrid_get_ResizeRows(This,pVal)	\
    (This)->lpVtbl -> get_ResizeRows(This,pVal)

#define ILiteGrid_put_ResizeRows(This,newVal)	\
    (This)->lpVtbl -> put_ResizeRows(This,newVal)

#define ILiteGrid_get_ResizeCols(This,pVal)	\
    (This)->lpVtbl -> get_ResizeCols(This,pVal)

#define ILiteGrid_put_ResizeCols(This,newVal)	\
    (This)->lpVtbl -> put_ResizeCols(This,newVal)

#define ILiteGrid_get_Editable(This,pVal)	\
    (This)->lpVtbl -> get_Editable(This,pVal)

#define ILiteGrid_put_Editable(This,newVal)	\
    (This)->lpVtbl -> put_Editable(This,newVal)

#define ILiteGrid_get_ScrollBars(This,pVal)	\
    (This)->lpVtbl -> get_ScrollBars(This,pVal)

#define ILiteGrid_put_ScrollBars(This,newVal)	\
    (This)->lpVtbl -> put_ScrollBars(This,newVal)

#define ILiteGrid_get_FastDraw(This,pVal)	\
    (This)->lpVtbl -> get_FastDraw(This,pVal)

#define ILiteGrid_put_FastDraw(This,newVal)	\
    (This)->lpVtbl -> put_FastDraw(This,newVal)

#define ILiteGrid_get_ColAlign(This,lCol,pVal)	\
    (This)->lpVtbl -> get_ColAlign(This,lCol,pVal)

#define ILiteGrid_put_ColAlign(This,lCol,newVal)	\
    (This)->lpVtbl -> put_ColAlign(This,lCol,newVal)

#define ILiteGrid_get_DefaultColAlign(This,pVal)	\
    (This)->lpVtbl -> get_DefaultColAlign(This,pVal)

#define ILiteGrid_put_DefaultColAlign(This,newVal)	\
    (This)->lpVtbl -> put_DefaultColAlign(This,newVal)

#define ILiteGrid_GetFixedTextWidth(This,bsText,pResult)	\
    (This)->lpVtbl -> GetFixedTextWidth(This,bsText,pResult)

#define ILiteGrid_GetNormalTextWidth(This,bsText,pResult)	\
    (This)->lpVtbl -> GetNormalTextWidth(This,bsText,pResult)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Window_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *phwnd);


void __RPC_STUB ILiteGrid_get_Window_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedRows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedRows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedRows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_FixedRows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedCols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedCols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedCols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_FixedCols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Rows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Rows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Rows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_Rows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Cols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Cols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Cols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_Cols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_CellText_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lRow,
    long lCol,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_CellText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_CellText_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lRow,
    long lCol,
    /* [in] */ BSTR newVal);


void __RPC_STUB ILiteGrid_put_CellText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_ColWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lCol,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_ColWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_ColWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lCol,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_ColWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_RowHeight_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lRow,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_RowHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_RowHeight_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lRow,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_RowHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_DefaultColWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_DefaultColWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_DefaultColWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_DefaultColWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_DefaultRowHeight_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_DefaultRowHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_DefaultRowHeight_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_DefaultRowHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Row_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Row_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Row_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_Row_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Col_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Col_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Col_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ILiteGrid_put_Col_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedFont_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propputref] */ HRESULT STDMETHODCALLTYPE ILiteGrid_putref_FixedFont_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ LPFONTDISP newVal);


void __RPC_STUB ILiteGrid_putref_FixedFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_NormalFont_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ LPFONTDISP __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_NormalFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propputref] */ HRESULT STDMETHODCALLTYPE ILiteGrid_putref_NormalFont_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ LPFONTDISP pVal);


void __RPC_STUB ILiteGrid_putref_NormalFont_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedBkColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedBkColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedBkColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_FixedBkColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_NormalBkColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_NormalBkColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_NormalBkColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_NormalBkColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedTextColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedTextColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_FixedTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_NormalTextColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_NormalTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_NormalTextColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_NormalTextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedLightColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedLightColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedLightColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_FixedLightColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FixedShadowColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FixedShadowColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FixedShadowColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_FixedShadowColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_NormalLightColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_NormalLightColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_NormalLightColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_NormalLightColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_NormalShadowColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_NormalShadowColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_NormalShadowColor_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB ILiteGrid_put_NormalShadowColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_IsEnabled_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL vbool);


void __RPC_STUB ILiteGrid_put_IsEnabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_IsEnabled_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbool);


void __RPC_STUB ILiteGrid_get_IsEnabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Visible_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Visible_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_Visible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Border_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Border_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_CellTop_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_CellTop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_CellLeft_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_CellLeft_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_CellWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_CellWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_CellHeight_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_CellHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_ResizeRows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_ResizeRows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_ResizeRows_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_ResizeRows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_ResizeCols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_ResizeCols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_ResizeCols_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_ResizeCols_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_Editable_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_Editable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_Editable_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_Editable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_ScrollBars_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ SCROLL_BAR_TYPE __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_ScrollBars_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_ScrollBars_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ SCROLL_BAR_TYPE newVal);


void __RPC_STUB ILiteGrid_put_ScrollBars_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_FastDraw_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_FastDraw_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_FastDraw_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB ILiteGrid_put_FastDraw_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_ColAlign_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lCol,
    /* [retval][out] */ lgColAlignType __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_ColAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_ColAlign_Proxy( 
    ILiteGrid __RPC_FAR * This,
    long lCol,
    /* [in] */ lgColAlignType newVal);


void __RPC_STUB ILiteGrid_put_ColAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ILiteGrid_get_DefaultColAlign_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [retval][out] */ lgColAlignType __RPC_FAR *pVal);


void __RPC_STUB ILiteGrid_get_DefaultColAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ILiteGrid_put_DefaultColAlign_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ lgColAlignType newVal);


void __RPC_STUB ILiteGrid_put_DefaultColAlign_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILiteGrid_GetFixedTextWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ BSTR bsText,
    /* [retval][out] */ LONG __RPC_FAR *pResult);


void __RPC_STUB ILiteGrid_GetFixedTextWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ILiteGrid_GetNormalTextWidth_Proxy( 
    ILiteGrid __RPC_FAR * This,
    /* [in] */ BSTR bsText,
    /* [retval][out] */ LONG __RPC_FAR *pResult);


void __RPC_STUB ILiteGrid_GetNormalTextWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILiteGrid_INTERFACE_DEFINED__ */


#ifndef ___LiteGridEvents_DISPINTERFACE_DEFINED__
#define ___LiteGridEvents_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: _LiteGridEvents
 * at Sat Oct 02 16:36:44 1999
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][uuid] */ 



EXTERN_C const IID DIID__LiteGridEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("D8343E40-5FB8-11d3-B739-DE9B89A07120")
    _LiteGridEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _LiteGridEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _LiteGridEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _LiteGridEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _LiteGridEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _LiteGridEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _LiteGridEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _LiteGridEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _LiteGridEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _LiteGridEventsVtbl;

    interface _LiteGridEvents
    {
        CONST_VTBL struct _LiteGridEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _LiteGridEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _LiteGridEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _LiteGridEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _LiteGridEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _LiteGridEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _LiteGridEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _LiteGridEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___LiteGridEvents_DISPINTERFACE_DEFINED__ */


#ifdef __cplusplus
EXTERN_C const CLSID CLSID_LiteGrid;

class DECLSPEC_UUID("68523E50-56EB-11D3-B739-CAA1986A452F")
LiteGrid;
#endif
#endif /* __LGRIDLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
