function quit_all() 

global Next_process

Next_process = 'quit' ;