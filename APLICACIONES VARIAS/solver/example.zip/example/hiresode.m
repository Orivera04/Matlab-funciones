function hiresode
%HIRESODE is a stiff system of 8 non-linear Ordinary Differential Equations.
%
%   The name HIRES was given by Hairer & Wanner. 
% 
%    E. Hairer and G. Wanner. Solving Ordinary Differential Equations II: 
%    Stiff and Differential algebraic Problems. Springer-Verlag, 
%    second revised edition, 1996.
%
%    It refers to 'High IrradianceRESponse', which is described by this ODE.
%   
%   The problem originates from plant physiology and describes how light 
%   is involved in morphogenesis. To be precise, it explains the 'High 
%   Irradiance Responses' (HIRES) of photomorphogenesis on the basis
%   of phytochrome, by means of a chemical reaction involving eight 
%   reactants. It has been promoted as a test problem by Gottwald in
% 
%    B.A. Gottwald. MISS - ein einfaches Simulations-System fur 
%    biologische und chemische Prozesse. EDV in Medizin und Biologie,
%    3:85-90, 1977.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $


options = odeset('Jacobian',@jac,'Stats','on');
y0 =  [1; 0; 0; 0; 0; 0; 0; 0.0057];

[t,y] = odebim(@hires,[0 321.8122],y0,options);

figure(1);
subplot(2,2,1); plot(t,y(:,1));title('y_1 on [0,5]');axis([0 5 0 1]);
subplot(2,2,2); plot(t,y(:,2));title('y_2 on [0,5]');axis([0 5 0 0.14]);
subplot(2,2,3); plot(t,y(:,3));title('y_3 on [0,5]');axis([0 5 0 0.02]);
subplot(2,2,4); plot(t,y(:,4));title('y_4 on [0,5]');axis([0 5 0 0.5]);

figure(2);
subplot(2,2,1); plot(t,y(:,5));title('y_5');axis([0 400 0 0.2]);
subplot(2,2,2); plot(t,y(:,6));title('y_6');axis([0 400 0 0.8]);
subplot(2,2,3); plot(t,y(:,7));title('y_7 on [0,5]');axis([0 5 0 6e-3]);
subplot(2,2,4); plot(t,y(:,8));title('y_8 on [0,5]');axis([0 5 0 6e-3]);
% -----------------------------------------------------------------------
% Nested function
%
    function f = hires(t,y)
        f = zeros(8,1);
        f(1) = -1.71*y(1)+0.43*y(2)+8.32*y(3)+0.0007;
        f(2) = 1.71*y(1)-8.75*y(2);
        f(3) = -10.03*y(3)+0.43*y(4)+0.035*y(5);
        f(4) = 8.32*y(2)+1.71*y(3)-1.12*y(4);
        f(5) = -1.745*y(5)+0.43*(y(6)+y(7));
        f(6) = -280*y(6)*y(8)+0.69*y(4)+1.71*y(5)-0.43*y(6)+0.69*y(7);
        f(7) = 280*y(6)*y(8)-1.81*y(7);
        f(8) = -f(7);
      end
% -----------------------------------------------------------------------
% Nested function
%
    function dfdy = jac(t,y)
        dfdy = zeros(8,8);
        dfdy(1,1) = -1.71;
        dfdy(1,2) = 0.43;
        dfdy(1,3) = 8.32;
        dfdy(2,1) = 1.71;
        dfdy(2,2) = -8.75;
        dfdy(3,3) = -10.03;
        dfdy(3,4) = 0.43;
        dfdy(3,5) = 0.035;
        dfdy(4,2) = 8.32;
        dfdy(4,3) = 1.71;
        dfdy(4,4) = -1.12;
        dfdy(5,5) = -1.745;
        dfdy(5,6) = 0.43;
        dfdy(5,7) = 0.43;
        dfdy(6,4) = 0.69;
        dfdy(6,5) = 1.71;
        dfdy(6,6) = -280*y(8)-0.43;
        dfdy(6,7) = 0.69;
        dfdy(6,8) = -280*y(6);
        dfdy(7,6) = 280*y(8);
        dfdy(7,7) = -1.81;
        dfdy(7,8) = 280*y(6);
        dfdy(8,6) = -280*y(8);
        dfdy(8,7) = 1.81;
        dfdy(8,8) = -280*y(6);
    end

end   

 
