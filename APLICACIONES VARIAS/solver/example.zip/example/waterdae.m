function waterdae
%WATERDAE is an index 2 system of 49 non-linear Differential-Algebraic
%  Equations and describes the water how through a tube system, taking
%  into account turbulence and the roughness of the tube walls.
%
%   See also ODEBIM, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $
% Problem parameter, shared with the nested function.
nnodes=13;
nu    = 1.31d-6;
g     = 9.8d0;
rho   = 1.0d3;
rcrit = 2.3d3;
length= 1.0d3;
k     = 2.0d-4;
d     = 1.0d0;
b     = 2.0d2;
a = pi*d^2/4d0;
mu = nu*rho;
a = pi*d^2/4d0;
c = b/(rho*g);
v = rho*length/a;


mas = sparse(49,49);
mas(1:18,1:18) = v*speye(18);
mas(37:38,37:38) = c*speye(2);

% Use a consistent initial condition.
y0 = zeros(49,1);
y0(19:36) = 0.47519404529185289807e-1;
y0(37:49) = 109800;

tspan = [0 17*3600];
atol = zeros(49,1);
rtol = 1e-7;
atol(1:36) = rtol;
atol(37:49)= rtol*1e6;

options = odeset('Mass',mas,'RelTol',rtol,'AbsTol',atol,'InitialStep',rtol,'stats','on','DaeIndex',[38,11,0]);

[t,y] = odebim(@water,tspan,y0,options);
plot(t,y(:,4));
set(gca,'YLim',[1.45e-4,1.85e-4]);
title('Behavior of \phi_{3,4} for 6878<t<17\times3600.');

% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function df = water(t,y)
        df= zeros(49,1);
        
        ein  = zeros(nnodes,1);
        eout = zeros(nnodes,1);
        that=t/3600d0;
        that2=that*that;

        ein(1) = (1d0-cos(exp(-that)-1d0))/200d0;
        ein(13) = (1d0-cos(exp(-that)-1d0))/80d0;
        eout(10) = that2*(3d0*that2-92d0*that+720d0)/1d6;

        phi= zeros(nnodes,nnodes);
        lambda= ones(nnodes,nnodes);

        phi( 1, 2) = y( 1);
        phi( 2, 3) = y( 2);
        phi( 2, 6) = y( 3);
        phi( 3, 4) = y( 4);
        phi( 3, 5) = y( 5);
        phi( 4, 5) = y( 6);
        phi( 5,10) = y( 7);
        phi( 6, 5) = y( 8);
        phi( 7, 4) = y( 9);
        phi( 7, 8) = y(10);
        phi( 8, 5) = y(11);
        phi( 8,10) = y(12);
        phi( 9, 8) = y(13);
        phi(11, 9) = y(14);
        phi(11,12) = y(15);
        phi(12, 7) = y(16);
        phi(12, 8) = y(17);
        phi(13,11) = y(18);

        lambda( 1, 2) = y(19);
        lambda( 2, 3) = y(20);
        lambda( 2, 6) = y(21);
        lambda( 3, 4) = y(22);
        lambda( 3, 5) = y(23);
        lambda( 4, 5) = y(24);
        lambda( 5,10) = y(25);
        lambda( 6, 5) = y(26);
        lambda( 7, 4) = y(27);
        lambda( 7, 8) = y(28);
        lambda( 8, 5) = y(29);
        lambda( 8,10) = y(30);
        lambda( 9, 8) = y(31);
        lambda(11, 9) = y(32);
        lambda(11,12) = y(33);
        lambda(12, 7) = y(34);
        lambda(12, 8) = y(35);
        lambda(13,11) = y(36);

        p( 5) = y(37);
        p( 8) = y(38);
        p( 1) = y(39);
        p( 2) = y(40);
        p( 3) = y(41);
        p( 4) = y(42);
        p( 6) = y(43);
        p( 7) = y(44);
        p( 9) = y(45);
        p(10) = y(46);
        p(11) = y(47);
        p(12) = y(48);
        p(13) = y(49);

        rghres = zeros(nnodes,nnodes);
        fdba   = zeros(nnodes,nnodes);
        for j=1:nnodes
            for i=1:nnodes
                if (lambda(i,j) < 0d0)
                    error('return');
                end

                rtla=sqrt(lambda(i,j));
                r = abs(phi(i,j)*d/(nu*a));

                if (r>rcrit)
                    rghres(i,j) = 1/rtla - 1.74d0 +2d0*log10(2d0*k/d + 18.7d0/(r*rtla));
                    fdba(i,j) = p(i) - p(j) -lambda(i,j)*rho*length*phi(i,j)^2/(a^2*d);
                else
                    rghres(i,j) = 1.d0/rtla - 1.74d0 +2d0*log10(2d0*k/d + 18.7d0/(rcrit*rtla));

                    fdba(i,j) = p(i) - p(j) -32d0*mu*length*phi(i,j)/(a*d^2);
                end

            end
        end
        
        netflo = zeros(nnodes,1);
        for nj=1:nnodes
            netflo(nj) = ein(nj)-eout(nj);
            for i=1:nnodes
                netflo(nj) = netflo(nj)+phi(i,nj);
            end
            for j=1:nnodes
                netflo(nj) = netflo(nj)-phi(nj,j);
            end
        end

        df( 1) = fdba( 1, 2);
        df( 2) = fdba( 2, 3);
        df( 3) = fdba( 2, 6);
        df( 4) = fdba( 3, 4);
        df( 5) = fdba( 3, 5);
        df( 6) = fdba( 4, 5);
        df( 7) = fdba( 5,10);
        df( 8) = fdba( 6, 5);
        df( 9) = fdba( 7, 4);
        df(10) = fdba( 7, 8);
        df(11) = fdba( 8, 5);
        df(12) = fdba( 8,10);
        df(13) = fdba( 9, 8);
        df(14) = fdba(11, 9);
        df(15) = fdba(11,12);
        df(16) = fdba(12, 7);
        df(17) = fdba(12, 8);
        df(18) = fdba(13,11);

        df(19) = rghres( 1, 2);
        df(20) = rghres( 2, 3);
        df(21) = rghres( 2, 6);
        df(22) = rghres( 3, 4);
        df(23) = rghres( 3, 5);
        df(24) = rghres( 4, 5);
        df(25) = rghres( 5,10);
        df(26) = rghres( 6, 5);
        df(27) = rghres( 7, 4);
        df(28) = rghres( 7, 8);
        df(29) = rghres( 8, 5);
        df(30) = rghres( 8,10);
        df(31) = rghres( 9, 8);
        df(32) = rghres(11, 9);
        df(33) = rghres(11,12);
        df(34) = rghres(12, 7);
        df(35) = rghres(12, 8);
        df(36) = rghres(13,11);

        df(37) = netflo( 5);
        df(38) = netflo( 8);
        df(39) = netflo( 1);
        df(40) = netflo( 2);
        df(41) = netflo( 3);
        df(42) = netflo( 4);
        df(43) = netflo( 6);
        df(44) = netflo( 7);
        df(45) = netflo( 9);
        df(46) = netflo(10);
        df(47) = netflo(11);
        df(48) = netflo(12);
        df(49) = netflo(13);
    end

end


