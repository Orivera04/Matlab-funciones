function rigidode
%RIGIDODE  Euler equations of a rigid body without external forces.
%   A standard test problem for non-stiff solvers proposed by Krogh.  The
%   analytical solutions are Jacobian elliptic functions, accessible in
%   MATLAB.  The interval here is about 1.5 periods; it is that for which
%   solutions are plotted on p. 243 of Shampine and Gordon.
%
%   L. F. Shampine and M. K. Gordon, Computer Solution of Ordinary
%   Differential Equations, W.H. Freeman & Co., 1975.
%
%   See also ODEBIM, ODE45, ODE23, ODE113, FUNCTION_HANDLE.

%   Mark W. Reichelt and Lawrence F. Shampine, 3-23-94, 4-19-94
%   Copyright 1984-2004 The MathWorks, Inc.
%   $Revision: 1.14.4.2 $  $Date: 2005/06/21 19:27:37 $

tspan = [0 12];
options = odeset('Jacobian',@jac,'OutputSel',[1 3],'Stats','on','refine',3);
y0 = [0; 1; 1];

% solve the problem using ODEBIM
figure;
tic
odebim(@f,tspan,y0,options);
toc
% -------------------------------------------------------------------------

    function dydt = f(t,y)
        dydt = [    y(2)*y(3)
                  -y(1)*y(3)
              -0.51*y(1)*y(2) ];
    end

   function dfdy = jac(t,y)
            dfdy = [0, y(3), y(2);
                -y(3),0, -y(1)
                -0.51*y(2), -0.51*y(1),0];
   end
end