function cardae
% CARDAE is a stiff DAE of index 3, consisting of 8 differential and 2 algebraic 
%  equations. It has been taken from 
% 
%     S. Schneider. Integration de systemes d'equations differentielles raides
%     et differentielles algebriques par des methodes de collocations et 
%     methodes generales lineaires. PhD thesis, University of Geneva, 1994.
% 
%  Since not all initial conditions were given, we have chosen a consistent set
%  of initial conditions.

%  The car axis problem is an example of a rather simple multibody system, 
%  in which the behavior of a car axis on a bumpy road is modeled by a set 
%  of differential-algebraic equations.
%
%   See also ODEBIM, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameter, shared with the nested function.
M   = 10d0;
epslon = 1e-2;
L   = 1e0;
L0  = 0.5e0;
r   = 0.1e0;
w   = 10e0;
g   = 1e0;

Mass = zeros(10,10);
Mass(1:4,1:4) = eye(4);
Mass(5:8,5:8) = M*epslon*epslon/2d0*eye(4);

% Use an consistent initial condition to test initialization.
y0 = init();
tspan = [0 3];
options = odeset('Mass',Mass,'Stats','on','DaeIndex',[4,4,2]);
tic
[t,y] = odebim(@F,tspan,y0,options);
toc
figure;
subplot(2,2,1); plot(t,y(:,1));title('x_L');axis([0 3 -0.05 0.05]);
subplot(2,2,2); plot(t,y(:,2));title('y_L');axis([0 3 0.496 0.5]);
subplot(2,2,3); plot(t,y(:,3));title('x_R');axis([0 3 0.94 1.06]);
subplot(2,2,4); plot(t,y(:,4));title('y_R');axis([0 3 0.35 0.65]);
    % -------------------------------------------------------------------------
    % Nested function --  parameter is provided by the outer function.
    %
    function y = init()
        xr   = L;
        xl   = 0;
        yr   = L0;
        yl   = yr;
        xra  = -L0/L;
        xla  = xra;
        yra  = 0d0;
        yla  = 0d0;
        lam1 = 0d0;
        lam2 = 0d0;

        y(1)  =  xl;
        y(2)  =  yl;
        y(3)  =  xr;
        y(4)  =  yr;
        y(5)  =  xla;
        y(6)  =  yla;
        y(7)  =  xra;
        y(8)  =  yra;
        y(9)  =  lam1;
        y(10) =  lam2;
    end
    % -------------------------------------------------------------------------
    % Nested function --  parameter is provided by the outer function.
    %
    function dy = F(t,y)
        yb  = r*sin(w*t);
        xb  = sqrt(L*L-yb*yb);
        dy = zeros(10,1);
        dy(1:4) = y(5:8);
        
        xl   = y(1);
        yl   = y(2);
        xr   = y(3);
        yr   = y(4);
        lam1 = y(9);
        lam2 = y(10);

        Ll = sqrt(xl^2+yl^2);
        Lr = sqrt((xr-xb)^2+(yr-yb)^2);

        dy(5) =(L0-Ll)*xl/Ll +lam1*xb+2d0*lam2*(xl-xr);
        dy(6) =(L0-Ll)*yl/Ll +lam1*yb+2d0*lam2*(yl-yr)-M*epslon*epslon*g/2d0;
        dy(7) =(L0-Lr)*(xr-xb)/Lr -2d0*lam2*(xl-xr);
        dy(8) =(L0-Lr)*(yr-yb)/Lr -2d0*lam2*(yl-yr)-M*epslon*epslon*g/2d0;

        dy(9) = xb*xl+yb*yl;
        dy(10)= (xl-xr)^2+(yl-yr)^2-L*L;
    end
end

