function P = ex5wea;

%P is the transition probability matrix of Example 5.5 (for Weather model).

P =[.5 .3 .2
.5 .2 .3
.4 .5 .1];

