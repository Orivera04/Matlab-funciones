function transampdae
%E5ode  a stiff DAE of index 1 consisting of 8 equations P. Rentrop has
%  received it from K. Glasho & H.J. Oberle and has documented it in
%
%    P. Rentrop, M. Roche, and G. Steinebach. The application of Rosenbrock-Wanner
%    type methods with stepsize control in differential-algebraic equations.
%    Numer. Math., 55:545-563, 1989.
%
%  The formulation presented here hasbeen taken from
%    E. Hairer, C. Lubich, and M. Roche. The Numerical Solution of
%    Differential-Algebraic Systems by Runge-Kutta Methods. Lecture Notes
%    in Mathematics 1409. Springer-Verlag, 1989.
%
%  The problem originates from electrical circuit analysis. It is a model for
%  the transistor amplifier.
%
%   see also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameters
ub=6d0;uf=0.026d0;alpha=0.99d0;beta=1d-6;
r0=1000d0;r1=9000d0;r2=9000d0;r3=9000d0;
r4=9000d0;r5=9000d0;r6=9000d0;r7=9000d0;
r8=9000d0;r9=9000d0;
c1=1d-6;c2=2d-6;c3=3d-6;c4=4d-6;c5=5d-6;

M = sparse(8,8);
M(1,1) = -c1;
M(1,2) = c1;
M(2,1) = c1;
M(2,2) = -c1;
M(3,3) = -c2;
M(4,4) = -c3;
M(4,5) = c3;
M(5,4) = c3;
M(5,5) = -c3;
M(6,6) = -c4;
M(7,7) = -c5;
M(7,8) = c5;
M(8,7) = c5;
M(8,8) = -c5;

y0 = zeros(8,1);
y0(1) = 0d0;
y0(2) = ub/(r2/r1+1d0);
y0(3) = y0(2);
y0(4) = ub;
y0(5) = ub/(r6/r5+1d0);
y0(6) = y0(5);
y0(7) = y0(4);
y0(8) = 0d0;

options = odeset('RelTol',1e-7,'AbsTol',1e-7,'InitialStep',1e-9,'Jacobian',@jac,'Stats','on','Mass',M);

[t,y] = ode15s(@fcn,[0 0.2],y0,options);
figure(1);
subplot(2,2,1); plot(t,y(:,1)); title('y_{1}');
subplot(2,2,2); plot(t,y(:,2));title('y_{2}');
subplot(2,2,3); plot(t,y(:,3));title('y_{3}');
subplot(2,2,4); plot(t,y(:,4));title('y_{4}');

figure(2);
subplot(2,2,1); plot(t,y(:,5)); title('y_{5}');
subplot(2,2,2); plot(t,y(:,6));title('y_{6}');
subplot(2,2,3); plot(t,y(:,7));title('y_{7}');
subplot(2,2,4); plot(t,y(:,8));title('y_{8}');


% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function f = fcn(t,y)
        % Derivative function. Problem parameters, including the anonymous
        % function Ue, are shared with the outer function.
        f = zeros(8,1);
        uet   = 0.1d0*sin(200d0*pi*t);
        %       if ( (y(2)-y(3))/uf > 300d0)
        %            error('MATLAB:transampdae',['(y(2)-y(3))/uf > 300d0']);
        %       end
        %       if ( (y(5)-y(6))/uf > 300d0)
        %          error('MATLAB:transampdae',['(y(5)-y(6))/uf > 300d0']);
        %       end

        fac1  = beta*(exp((y(2)-y(3))/uf)-1d0);
        fac2  = beta*(exp((y(5)-y(6))/uf)-1d0);

        f(1) = (y(1)-uet)/r0;
        f(2) = y(2)/r1+(y(2)-ub)/r2+(1d0-alpha)*fac1;
        f(3) = y(3)/r3-fac1;
        f(4) = (y(4)-ub)/r4+alpha*fac1;
        f(5) = y(5)/r5+(y(5)-ub)/r6+(1d0-alpha)*fac2;
        f(6) = y(6)/r7-fac2;
        f(7) = (y(7)-ub)/r8+alpha*fac2;
        f(8) = y(8)/r9;
    end

% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy = sparse(8,8);
        %       if ( (y(2)-y(3))/uf > 300d0)
        %            error('MATLAB:transampdae',['(y(2)-y(3))/uf > 300d0']);
        %       end
        %       if ( (y(5)-y(6))/uf > 300d0)
        %          error('MATLAB:transampdae',['(y(5)-y(6))/uf > 300d0']);
        %       end
        fac1p = beta*exp((y(2)-y(3))/uf)/uf;
        fac2p = beta*exp((y(5)-y(6))/uf)/uf;
        dfdy(1,1) = 1d0/r0;
        dfdy(2,2) = 1d0/r1+1d0/r2+(1d0-alpha)*fac1p;
        dfdy(2,3) = -(1d0-alpha)*fac1p;
        dfdy(3,3) = 1d0/r3+fac1p;
        dfdy(3,2) = -fac1p;
        dfdy(4,4) = 1d0/r4;
        dfdy(4,2) = alpha*fac1p;
        dfdy(4,3) = -alpha*fac1p;
        dfdy(5,5) = 1d0/r5+1d0/r6+(1d0-alpha)*fac2p;
        dfdy(5,6) = -(1d0-alpha)*fac2p;
        dfdy(6,6) = 1d0/r7+fac2p;
        dfdy(6,5) = -fac2p;
        dfdy(7,7) = 1d0/r8;
        dfdy(7,5) = alpha*fac2p;
        dfdy(7,6) = -alpha*fac2p;
        dfdy(8,8) = 1d0/r9;
    end

end


