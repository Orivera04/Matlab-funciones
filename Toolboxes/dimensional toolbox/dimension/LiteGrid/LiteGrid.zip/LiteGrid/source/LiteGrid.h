// LiteGrid.h : Declaration of the CLiteGrid
// Copyright (C) 1999 Andrew Ivannikov. None rights reserved.

#ifndef __LITEGRID_H_
#define __LITEGRID_H_

#include "resource.h"       // main symbols
#include "CPlgrid.h"
#include "InplaceEdit.h"

using namespace std;
typedef vector<CComBSTR*> VectorBstr;
typedef vector<long> VectorLong;

/////////////////////////////////////////////////////////////////////////////
// CLiteGrid
class ATL_NO_VTABLE CLiteGrid : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CLiteGrid, &CLSID_LiteGrid>,
	public CComControl<CLiteGrid>,
	public CStockPropImpl<CLiteGrid, ILiteGrid, &IID_ILiteGrid, &LIBID_LGRIDLib>,
	public IProvideClassInfo2Impl<&CLSID_LiteGrid, &DIID__LiteGridEvents, &LIBID_LGRIDLib>,
	public IPersistStreamInitImpl<CLiteGrid>,
	public IPersistStorageImpl<CLiteGrid>,
	public IQuickActivateImpl<CLiteGrid>,
	public IOleControlImpl<CLiteGrid>,
	public IOleObjectImpl<CLiteGrid>,
	public IOleInPlaceActiveObjectImpl<CLiteGrid>,
	public IViewObjectExImpl<CLiteGrid>,
	public IOleInPlaceObjectWindowlessImpl<CLiteGrid>,
	public IDataObjectImpl<CLiteGrid>,
	public CProxy_LiteGridEvents<CLiteGrid>,
	public IConnectionPointContainerImpl<CLiteGrid>
{
public:

DECLARE_REGISTRY_RESOURCEID(IDR_LITEGRID)

BEGIN_COM_MAP(CLiteGrid)
	COM_INTERFACE_ENTRY(ILiteGrid)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY_IMPL(IOleControl)
	COM_INTERFACE_ENTRY_IMPL(IOleObject)
	COM_INTERFACE_ENTRY_IMPL(IQuickActivate)
	COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
	COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
	COM_INTERFACE_ENTRY_IMPL(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_PROPERTY_MAP(CLiteGrid)
	PROP_ENTRY("FixedRows", 1, CLSID_NULL)
	PROP_ENTRY("FixedCols", 2, CLSID_NULL)
	PROP_ENTRY("Rows", 3, CLSID_NULL)
	PROP_ENTRY("Cols", 4, CLSID_NULL)
	PROP_ENTRY("DefaultColWidth", 8, CLSID_NULL)
	PROP_ENTRY("DefaultRowHeight", 9, CLSID_NULL)
	PROP_ENTRY("Row", 10, CLSID_NULL)
	PROP_ENTRY("Col", 11, CLSID_NULL)
	PROP_ENTRY("FixedFont", 12, CLSID_NULL)
	PROP_ENTRY("NormalFont", 13, CLSID_NULL)
	PROP_ENTRY("FixedBkColor", 14, CLSID_NULL)
	PROP_ENTRY("NormalBkColor", 15, CLSID_NULL)
	PROP_ENTRY("FixedTextColor", 16, CLSID_NULL)
	PROP_ENTRY("NormalTextColor", 17, CLSID_NULL)
	PROP_ENTRY("FixedLightColor", 18, CLSID_NULL)
	PROP_ENTRY("FixedShadowColor", 19, CLSID_NULL)
	PROP_ENTRY("NormalLightColor", 20, CLSID_NULL)
	PROP_ENTRY("NormalShadowColor", 21, CLSID_NULL)
	PROP_ENTRY("Enabled", 22, CLSID_NULL)
	PROP_ENTRY("Visible", 23, CLSID_NULL)
	PROP_ENTRY("Border", 24, CLSID_NULL)
	PROP_ENTRY("ResizeRows", 29, CLSID_NULL)
	PROP_ENTRY("ResizeCols", 30, CLSID_NULL)
	PROP_ENTRY("Editable", 31, CLSID_NULL)
	PROP_ENTRY("ScrollBars", 32, CLSID_NULL)
	PROP_ENTRY("FastDraw", 33, CLSID_NULL)
	PROP_ENTRY("DefaultColAlign", 35, CLSID_NULL)
END_PROPERTY_MAP()


BEGIN_MSG_MAP(CLiteGrid)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_HSCROLL, OnScroll)
	MESSAGE_HANDLER(WM_VSCROLL, OnScroll)
	MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseEvents)
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnMouseEvents)
	MESSAGE_HANDLER(WM_LBUTTONUP, OnMouseEvents)
	MESSAGE_HANDLER(WM_KEYDOWN, OnKeyDown)
	MESSAGE_HANDLER(WM_KEYUP, OnKeyUp)
	MESSAGE_HANDLER(WM_CHAR, OnChar)
	MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnLButtonDblClk)
	// custom message from inplace editor
	MESSAGE_HANDLER(WM_ENDEDIT, OnEndInplaceEdit)
END_MSG_MAP()

BEGIN_CONNECTION_POINT_MAP(CLiteGrid)
	CONNECTION_POINT_ENTRY(DIID__LiteGridEvents)
END_CONNECTION_POINT_MAP()

	CLiteGrid();
	~CLiteGrid();
// IViewObjectEx
	STDMETHOD(GetViewStatus)(DWORD* pdwStatus)
	{
		ATLTRACE(_T("IViewObjectExImpl::GetViewStatus\n"));
		*pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
		return S_OK;
	}

	// stock props
	VARIANT_BOOL m_bVisible;
	VARIANT_BOOL m_bEnabled;
	VARIANT_BOOL m_bBorder;
	long m_nBorderStyle;
	long m_nAppearance;

// ILiteGrid
public:
	STDMETHOD(GetNormalTextWidth)(/*[in]*/ BSTR bsText, /*[out, retval]*/ LONG* pResult);
	STDMETHOD(GetFixedTextWidth)(/*[in]*/ BSTR bsText, /*[out, retval]*/ LONG* pResult);
	STDMETHOD(get_DefaultColAlign)(/*[out, retval]*/ lgColAlignType *pVal);
	STDMETHOD(put_DefaultColAlign)(/*[in]*/ lgColAlignType newVal);
	STDMETHOD(get_ColAlign)(long lCol, /*[out, retval]*/ lgColAlignType *pVal);
	STDMETHOD(put_ColAlign)(long lCol, /*[in]*/ lgColAlignType newVal);
	STDMETHOD(get_FastDraw)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_FastDraw)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ScrollBars)(/*[out, retval]*/ SCROLL_BAR_TYPE *pVal);
	STDMETHOD(put_ScrollBars)(/*[in]*/ SCROLL_BAR_TYPE newVal);
	STDMETHOD(get_Editable)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Editable)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ResizeCols)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ResizeCols)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ResizeRows)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ResizeRows)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_CellHeight)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_CellWidth)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_CellLeft)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_CellTop)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Border)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Border)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_Visible)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Visible)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_IsEnabled)(/*[out, retval]*/ VARIANT_BOOL* pVal);
	STDMETHOD(put_IsEnabled)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_NormalShadowColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_NormalShadowColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_NormalLightColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_NormalLightColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_FixedShadowColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_FixedShadowColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_FixedLightColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_FixedLightColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_NormalTextColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_NormalTextColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_FixedTextColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_FixedTextColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_NormalBkColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_NormalBkColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_FixedBkColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_FixedBkColor)(/*[in]*/ OLE_COLOR newVal);
	STDMETHOD(get_NormalFont)(/*[out, retval]*/ LPFONTDISP* pVal);
	STDMETHOD(putref_NormalFont)(/*[in]*/ LPFONTDISP newVal);
	STDMETHOD(get_FixedFont)(/*[out, retval]*/ LPFONTDISP* pVal);
	STDMETHOD(putref_FixedFont)(/*[in]*/ LPFONTDISP newVal);
	STDMETHOD(get_Col)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Col)(/*[in]*/ long newVal);
	STDMETHOD(get_Row)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Row)(/*[in]*/ long newVal);
	STDMETHOD(get_DefaultRowHeight)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_DefaultRowHeight)(/*[in]*/ long newVal);
	STDMETHOD(get_DefaultColWidth)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_DefaultColWidth)(/*[in]*/ long newVal);
	STDMETHOD(get_RowHeight)(long lRow, /*[out, retval]*/ long *pVal);
	STDMETHOD(put_RowHeight)(long lRow, /*[in]*/ long newVal);
	STDMETHOD(get_ColWidth)(long lCol, /*[out, retval]*/ long *pVal);
	STDMETHOD(put_ColWidth)(long lCol, /*[in]*/ long newVal);
	STDMETHOD(get_CellText)(long lRow, long lCol, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_CellText)(long lRow, long lCol, /*[in]*/ BSTR newVal);
	STDMETHOD(get_FixedCols)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_FixedCols)(/*[in]*/ long newVal);
	STDMETHOD(get_FixedRows)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_FixedRows)(/*[in]*/ long newVal);
	STDMETHOD(get_Cols)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Cols)(/*[in]*/ long newVal);
	STDMETHOD(get_Rows)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Rows)(/*[in]*/ long newVal);

	LRESULT OnPaint(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult);
	LRESULT OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnScroll(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnMouseEvents(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnKeyUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnChar(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnEndInplaceEdit(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);
	LRESULT OnLButtonDblClk(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bResult);

private:
	long m_lNumRows;	// number of rows in the grid
	long m_lNumCols;	// number of columns in the grid
	long m_lNumFixedRows;	// number of fised rows. Must be < m_lNumRows!
	long m_lNumFixedCols;	// number of fixed columns. Must be < m_lNumCols!
	long m_lRow;	// currently selected row
	long m_lCol;	// currently selected column
	long m_lTopRow;	// first visible non-fixed row
	long m_lTopCol;	// first visible non-fixed column
	long m_lDefColWidth;		// default cell size
	long m_lDefRowHeight;
	long m_lDefColAlign;	// default text align in column
	enum { 
		STATE_NORMAL, 
		STATE_WESIZE_READY, STATE_NSSIZE_READY, 
		STATE_WESIZING, STATE_NSSIZING,
		STATE_INPLACEEDITING } m_nState;	// current state of the grid
	long m_lSizingCoord; // row or column of the cell currently sizing
	long m_lCurSizingSize;	// currently selected size
	LPFONT m_pFontFixed;	// font for fixed cells
	LPFONT m_pFontNormal;	// font for normal cells
	OLE_COLOR m_ColorFixedBk, m_ColorFixedFont; // colors for fixed background and font
	OLE_COLOR m_ColorFixedLight, m_ColorFixedShadow; // colors for borders around fixed cells
	OLE_COLOR m_ColorNormalBk, m_ColorNormalFont;
	OLE_COLOR m_ColorNormalLight, m_ColorNormalShadow;
	OLE_COLOR m_ColorBk;	// color of the window background
	bool m_bFastDraw;	// if FALSE suppresses WM_PAINT after scroll of the window

	VectorBstr m_vecCellText;	// contents of each cell (text)
	VectorLong m_vecRowHeights;	// heights for each row
	VectorLong m_vecColWidths;	// widths for each column
	VectorLong m_vecColAligns; // text align for each column

	CInplaceEdit m_wndInplaceEdit;	// inplace editor for editable grid
protected:
	long GetTextWidth(BSTR bsText, IFont* pFont);
	SCROLL_BAR_TYPE m_nScrollType;	// scroll bars: both, vertical, horizontal, none
	bool m_bResizeCols;	// allows cols resizing
	bool m_bResizeRows;	// allows rows resizing
	bool m_bEditable;	// allows inplace editing
	// helper functions
	bool TryStartEditing();
	void DrawSizingLine(bool bHorz);
	void PgRight();
	void PgLeft();
	void PgDn();
	void PgUp();
	void LineRight(int nLines = 1);
	void LineLeft(int nLines = 1);
	void LineDn(int nLines = 1);
	void LineUp(int nLines = 1);
	void FocusCell(HDC hDC, long lRow, long lCol, bool bRemove = false);
	bool ChangeActiveCell(long lRow, long lCol);
	void DrawCellRange(HDC hDC, RECT& rc, POINT ptStartCoords, RECT& rcCells, COLORREF clrBk, COLORREF clrFg, COLORREF clrLightLine, COLORREF clrShadowLine);
	void CellFromPoint(POINT pt, POINT* pptCellCoords, RECT* prcCell);
	void GetCellRect(long lRow, long lCol, RECT& rc);
};

#endif //__LITEGRID_H_