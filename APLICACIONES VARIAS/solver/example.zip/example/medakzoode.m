function  medakzoode
%MEDAKZOODE is a stiff system of 400 non-linear Ordinary Differential Equations.
%   Originally the problem consists of 2 partial differential equations.
%   Semi-discretization of this system yields a stiff ODE. 
%   The parallel-IVP-algorithm group of CWI contributed this problem to 
%   the test set in collaboration with R. van der Hout from 
%   Akzo Nobel Central Research.
%   The Akzo Nobel research laboratories formulated this problem in their 
%   study of the penetration of radio-labeled antibodies into a tissue.
%   This study was carried out for diagnostic as well as therapeutic purposes.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameter, shared with the nested function.
k=100;   c=4;
N      = 400/2;
dzeta  = 1/N;
dzeta2 = dzeta*dzeta;

y0 =  zeros(2*N,1);
for j=1:N
    y0(2*j)   = 1;
end

options = odeset('Jacobian',@jac,'Stats','on');

[t,y] = ode15s(@medakzo,[0 20],y0,options);

figure(1);
subplot(2,2,1); plot(t,y(:,79)); title('y_{79}( = u(1,t))'); axis([0 20 0 1.5]);
subplot(2,2,2); plot(t,y(:,133));title('y_{133}( = u(2,t))');axis([0 20 0 0.8]);
subplot(2,2,3); plot(t,y(:,171));title('y_{171}( = u(3,t))');axis([0 20 0 0.3]);
subplot(2,2,4); plot(t,y(:,199));title('y_{199}( = u(4,t))');axis([0 20 0 0.03]);

figure(2);
subplot(2,2,1); plot(t,y(:,80)); title('y_{80}( = v(1,t))'); axis([0 20 0 1]);
subplot(2,2,2); plot(t,y(:,134));title('y_{134}( = v(2,t))');axis([0 20 0 1]);
subplot(2,2,3); plot(t,y(:,172));title('y_{172}( = v(3,t))');axis([0 20 0 1]);
subplot(2,2,4); plot(t,y(:,200));title('y_{200}( = v(4,t))');axis([0 20 0 1]);




% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function f = medakzo(t,y)
        f = zeros(400,1);
        dum    = (dzeta-1)*(dzeta-1)/c;
        alpha  = 2*(dzeta-1)*dum/c;
        beta   = dum*dum;
        if (t <= 5)
            phi = 2;
        else
            phi = 0;
        end
        %
        f(1) = (phi-2*y(1)+y(3))*beta/dzeta2+alpha*(y(3)-phi)/(2*dzeta)-k*y(1)*y(2);
        f(2) = -k*y(1)*y(2);
        %
        for j=2:N-1
            i     = 2*j-1;
            zeta  = j*dzeta;
            dum   = (zeta-1)*(zeta-1)/c;
            alpha = 2*(zeta-1)*dum/c;
            beta  = dum*dum;
            f(i) = (y(i-2)-2*y(i)+y(i+2))*beta/dzeta2+alpha*(y(i+2)-y(i-2))/(2*dzeta)-k*y(i)*y(i+1);
            i     = 2*j;
            f(i) = -k*y(i)*y(i-1);
        end
        %
        f(2*N-1) = -k*y(2*N-1)*y(2*N);
        f(2*N)   = -k*y(2*N-1)*y(2*N);
    end
% -----------------------------------------------------------------------
% Nested function  -- parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy = sparse(400,400);
        dum    = (dzeta-1)*(dzeta-1)/c;
        alpha  = 2*(dzeta-1)*dum/c;
        beta   = dum*dum;
        dfdy(1,1) = -beta*2/dzeta2-k*y(2);
        dfdy(1,2) = -k*y(1);
        dfdy(1,3) = beta/dzeta2+alpha/(2*dzeta);
        dfdy(2,1) = -k*y(2);
        dfdy(2,2) = -k*y(1);

        for  j=2:N-1
            i          = 2*j-1;
            zeta       = j*dzeta;
            dum        = (zeta-1)*(zeta-1)/c;
            alpha      = 2*(zeta-1)*dum/c;
            beta       = dum*dum;
            bz         = beta/dzeta2;
            dfdy(i,i-2)   = bz-alpha/(2*dzeta);
            dfdy(i,i)     = -2*bz-k*y(i+1);
            dfdy(i,i+2)   = bz+alpha/(2*dzeta);
            dfdy(i,i+1)   = -k*y(i);
            i          = 2*j;
            dfdy(i,i-1) = -k*y(i);
            dfdy(i,i)   = -k*y(i-1);
        end
        %
        dfdy(2*N-1,2*N-1) = -k*y(2*N);
        dfdy(2*N-1,2*N)   = -k*y(2*N-1);
        dfdy(2*N,2*N-1) = -k*y(2*N);
        dfdy(2*N,2*N)   = -k*y(2*N-1);

    end

end


