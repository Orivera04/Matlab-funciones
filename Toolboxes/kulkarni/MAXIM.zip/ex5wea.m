function P = ex5wea;
%P is the tr pr matrix of Example 5.5.
P =[.5 .3 .2
.5 .2 .3
.4 .5 .1];

