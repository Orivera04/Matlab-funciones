// vctestDoc.cpp : implementation of the CVctestDoc class
//

#include "stdafx.h"
#include "vctest.h"

#include "vctestDoc.h"
#include "vctestView.h"
#include "childFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVctestDoc

IMPLEMENT_DYNCREATE(CVctestDoc, CDocument)

BEGIN_MESSAGE_MAP(CVctestDoc, CDocument)
	//{{AFX_MSG_MAP(CVctestDoc)
	ON_COMMAND(IDC_BTN_SET, OnSetProps)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVctestDoc construction/destruction

CVctestDoc::CVctestDoc()
{
	// TODO: add one-time construction code here

}

CVctestDoc::~CVctestDoc()
{
}

BOOL CVctestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	m_lNumRows = 5;
	m_lNumCols = 7;
	m_lNumFixedRows = 1;
	m_lNumFixedCols = 2;
	m_vecGridStrings.SetSize(35);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CVctestDoc serialization

void CVctestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_lNumRows << m_lNumCols << m_lNumFixedRows << m_lNumFixedCols;
		ar << m_vecGridStrings.GetSize();
		for(int i = 0; i < m_vecGridStrings.GetSize(); i++)
			ar << m_vecGridStrings[i];
	}
	else
	{
		ar >> m_lNumRows >> m_lNumCols >> m_lNumFixedRows >> m_lNumFixedCols;
		int iVecSize;
		ar >> iVecSize;
		m_vecGridStrings.SetSize(iVecSize);
		for(int i = 0; i < iVecSize; i++)
			ar >> m_vecGridStrings[i];
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVctestDoc diagnostics

#ifdef _DEBUG
void CVctestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVctestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVctestDoc commands

void CVctestDoc::OnSetProps() 
{
	// try to set data entered in the dialog bar for currently active document
	long l[4];
	CString sTmp;
	CDialogBar* pdlgb;

	// get dialogbar control from the only view
	POSITION pos = GetFirstViewPosition();
	CVctestView* pView = static_cast<CVctestView*>(GetNextView(pos));
	pdlgb = &(static_cast<CChildFrame*>(pView->GetParent())->m_wndGridOpts);

	for(int i = IDC_EDT_NUMROWS; i <= IDC_EDT_NUMFIXEDCOLS; i++)
	{
		pdlgb->GetDlgItem(i)->GetWindowText(sTmp);
		l[i - IDC_EDT_NUMROWS] = atol((LPCSTR)sTmp);
	}
	// check for compatibility of this values
	if(l[0] <= 0 || l[2] < 0 || l[2] >= l[0] ||
		l[1] <= 0 || l[3] < 0 || l[3] >= l[1])
	{
		AfxMessageBox(_T("Incompatible data"));
		pView->SetDialogBarVals();
		return;
	}
	m_lNumFixedRows = l[2];
	m_lNumFixedCols = l[3];
	// set rows
	if(m_lNumRows != l[0])
	{
		m_vecGridStrings.SetSize(l[0] * m_lNumCols);
		pView->m_ctlLiteGrid.SetRows(l[0]);
		m_lNumRows = l[0];
	}
	// set columns
	if(m_lNumCols != l[1])
	{
		m_vecGridStrings.SetSize(l[1] * m_lNumRows);
		pView->m_ctlLiteGrid.SetCols(l[1]);
		m_lNumCols = l[1];
	}
	// move data from the LiteGrid
	for(i = 0; i < m_lNumRows * m_lNumCols; i++)
		m_vecGridStrings[i] = pView->m_ctlLiteGrid.GetCellText(i / m_lNumCols, i % m_lNumCols);
	SetModifiedFlag();
	UpdateAllViews(NULL);
}