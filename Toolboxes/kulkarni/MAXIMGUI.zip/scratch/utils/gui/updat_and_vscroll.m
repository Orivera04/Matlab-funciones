function updat_and_vscroll(num_disp)

update_add_nonsq_matrix_values(num_disp);
amvscroll_nonsq(num_disp);
