// InplaceEdit.h: interface for the CInplaceEdit class.
// Copyright (C) 1999 Andrew Ivannikov. None rights reserved.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPLACEEDIT_H__E2748A03_62B4_11D3_B739_EFA02435A302__INCLUDED_)
#define AFX_INPLACEEDIT_H__E2748A03_62B4_11D3_B739_EFA02435A302__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// sent to parent when editing has terminated
// WPARAM  = code: IDOK - when the user has pressed VK_RETURN or doubleclicked on the EDIT control
//						 IDCANCEL - when ESC was pressed or when the edit lost input focus
// LPARAM = pointer to LPTSTR of the edit
#define WM_ENDEDIT WM_USER + 9

// represents inplace editor which can be used as a child window
class CInplaceEdit : public CWindowImpl<CInplaceEdit>
{
public:
	bool StartEditing(LPRECT rcCoords, LPCTSTR szInitialText = NULL, HFONT hFont = NULL);
	CInplaceEdit(CWindow* pParent);
protected:
	CWindow* m_pParent;

	BEGIN_MSG_MAP(CInplaceEdit)
		MESSAGE_HANDLER(WM_KEYDOWN, OnKeyDown)
		MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnDoubleClick)
		MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
	END_MSG_MAP()

	LRESULT OnKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDoubleClick(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnKillFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	void StopEditing(WPARAM wCode);
};

#endif // !defined(AFX_INPLACEEDIT_H__E2748A03_62B4_11D3_B739_EFA02435A302__INCLUDED_)
