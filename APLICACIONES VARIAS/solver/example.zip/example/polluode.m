function polluode
%POLLUODE is a stiff system of 20 non-linear Ordinary Differential Equations.
%   It is the chemical reaction part of the air pollution model developed
%   at The Dutch National Institute of Public Health and Environmental
%   Protection (RIVM) and it is described by Verwer in
%   J.G. Verwer. Gauss-Seidel iteration for stiff ODEs from chemical
%   kinetics. SIAM J. Sci. Comput., 15(5):1243-1259, 1994.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $
%
% Problem parameter, shared with the nested function.
k1  = 0.35;      k2  = 0.266e2;
k3  = 0.123e5;   k4  = 0.86e-3;
k5  = 0.82e-3;   k6  = 0.15e5;
k7  = 0.13e-3;   k8  = 0.24e5;
k9  = 0.165e5;   k10 = 0.9e4;
k11 = 0.22e-1;   k12 = 0.12e5;
k13 = 0.188e1;   k14 = 0.163e5;
k15 = 0.48e7;    k16 = 0.35e-3;
k17 = 0.175e-1;  k18 = 0.1e9;
k19 = 0.444e12;  k20 = 0.124e4;
k21 = 0.21e1;    k22 = 0.578e1;
k23 = 0.474e-1;  k24 = 0.178e4;
k25 = 0.312e1;

options = odeset('Jacobian',@jac);
y0 =  zeros(20,1);
y0(2)  = 0.2;
y0(4)  = 0.04;
y0(7)  = 0.1;
y0(8)  = 0.3;
y0(9)  = 0.01;
y0(17) = 0.007;

[t,y] = odebim(@pollu,[0 60],y0,options);

figure(1);
subplot(2,2,1); plot(t,y(:,1)); title('y_{1}');
subplot(2,2,2); plot(t,y(:,2));title('y_{2}');
subplot(2,2,3); plot(t,y(:,3));title('y_{3}');
subplot(2,2,4); plot(t,y(:,4));title('y_{4}');

figure(2);
subplot(2,2,1); plot(t,y(:,5)); title('y_{5}');
subplot(2,2,2); plot(t,y(:,6));title('y_{6}');
subplot(2,2,3); plot(t,y(:,7));title('y_{7}');
subplot(2,2,4); plot(t,y(:,8));title('y_{8}');

figure(3);
subplot(2,2,1); plot(t,y(:,9)); title('y_{9}');
subplot(2,2,2); plot(t,y(:,10));title('y_{10}');
subplot(2,2,3); plot(t,y(:,11));title('y_{11}');
subplot(2,2,4); plot(t,y(:,12));title('y_{12}');

figure(4);
subplot(2,2,1); plot(t,y(:,13)); title('y_{13}');
subplot(2,2,2); plot(t,y(:,14));title('y_{14}');
subplot(2,2,3); plot(t,y(:,15));title('y_{15}');
subplot(2,2,4); plot(t,y(:,16));title('y_{16}');

figure(5);
subplot(2,2,1); plot(t,y(:,17)); title('y_{17}');
subplot(2,2,2); plot(t,y(:,18));title('y_{18}');
subplot(2,2,3); plot(t,y(:,19));title('y_{19}');
subplot(2,2,4); plot(t,y(:,20));title('y_{20}');

% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function f = pollu(t,y)
        f = zeros(20,1);
        r( 1) = k1 *y( 1);
        r( 2) = k2 *y( 2)*y(4);
        r( 3) = k3 *y( 5)*y(2);
        r( 4) = k4 *y( 7);
        r( 5) = k5 *y( 7);
        r( 6) = k6 *y( 7)*y(6);
        r( 7) = k7 *y( 9);
        r( 8) = k8 *y( 9)*y(6);
        r( 9) = k9 *y(11)*y(2);
        r(10) = k10*y(11)*y(1);
        r(11) = k11*y(13);
        r(12) = k12*y(10)*y(2);
        r(13) = k13*y(14);
        r(14) = k14*y( 1)*y(6);
        r(15) = k15*y( 3);
        r(16) = k16*y( 4);
        r(17) = k17*y( 4);
        r(18) = k18*y(16);
        r(19) = k19*y(16);
        r(20) = k20*y(17)*y(6);
        r(21) = k21*y(19);
        r(22) = k22*y(19);
        r(23) = k23*y( 1)*y(4);
        r(24) = k24*y(19)*y(1);
        r(25) = k25*y(20);

        f(1)  = -r(1)-r(10)-r(14)-r(23)-r(24)+r(2)+r(3)+r(9)+r(11)+r(12)+r(22)+r(25);
        f(2)  = -r(2)-r(3)-r(9)-r(12)+r(1)+r(21);
        f(3)  = -r(15)+r(1)+r(17)+r(19)+r(22);
        f(4)  = -r(2)-r(16)-r(17)-r(23)+r(15);
        f(5)  = -r(3)+r(4)+r(4)+r(6)+r(7)+r(13)+r(20);
        f(6)  = -r(6)-r(8)-r(14)-r(20)+r(3)+r(18)+r(18);
        f(7)  = -r(4)-r(5)-r(6)+r(13);
        f(8)  = r(4)+r(5)+r(6)+r(7);
        f(9)  = -r(7)-r(8);
        f(10) = -r(12)+r(7)+r(9);
        f(11) = -r(9)-r(10)+r(8)+r(11);
        f(12) = r(9);
        f(13) = -r(11)+r(10);
        f(14) = -r(13)+r(12);
        f(15) = r(14);
        f(16) = -r(18)-r(19)+r(16);
        f(17) = -r(20);
        f(18) = r(20);
        f(19) = -r(21)-r(22)-r(24)+r(23)+r(25);
        f(20) = -r(25)+r(24);
    end
% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy = zeros(20,20);
        dfdy(1,1)   = -k1-k10*y(11)-k14*y(6)-k23*y(4)-k24*y(19);
        dfdy(1,11)  = -k10*y(1)+k9*y(2);
        dfdy(1,6)   = -k14*y(1);
        dfdy(1,4)   = -k23*y(1)+k2*y(2);
        dfdy(1,19)  = -k24*y(1)+k22;
        dfdy(1,2)   = k2*y(4)+k9*y(11)+k3*y(5)+k12*y(10);
        dfdy(1,13)  = k11;
        dfdy(1,20)  = k25;
        dfdy(1,5)   = k3*y(2);
        dfdy(1,10)  = k12*y(2);

        dfdy(2,4)   = -k2*y(2);
        dfdy(2,5)   = -k3*y(2);
        dfdy(2,11)  = -k9*y(2);
        dfdy(2,10)  = -k12*y(2);
        dfdy(2,19)  = k21;
        dfdy(2,1)   = k1;
        dfdy(2,2)   = -k2*y(4)-k3*y(5)-k9*y(11)-k12*y(10);

        dfdy(3,1)   = k1;
        dfdy(3,4)   = k17;
        dfdy(3,16)  = k19;
        dfdy(3,19)  = k22;
        dfdy(3,3)   = -k15;

        dfdy(4,4)   = -k2*y(2)-k16-k17-k23*y(1);
        dfdy(4,2)   = -k2*y(4);
        dfdy(4,1)   = -k23*y(4);
        dfdy(4,3)   = k15;

        dfdy(5,5)   = -k3*y(2);
        dfdy(5,2)   = -k3*y(5);
        dfdy(5,7)   = 2d0*k4+k6*y(6);
        dfdy(5,6)   = k6*y(7)+k20*y(17);
        dfdy(5,9)   = k7;
        dfdy(5,14)  = k13;
        dfdy(5,17)  = k20*y(6);

        dfdy(6,6)   = -k6*y(7)-k8*y(9)-k14*y(1)-k20*y(17);
        dfdy(6,7)   = -k6*y(6);
        dfdy(6,9)   = -k8*y(6);
        dfdy(6,1)   = -k14*y(6);
        dfdy(6,17)  = -k20*y(6);
        dfdy(6,2)   = k3*y(5);
        dfdy(6,5)   = k3*y(2);
        dfdy(6,16)  = 2d0*k18;

        dfdy(7,7)   = -k4-k5-k6*y(6);
        dfdy(7,6)   = -k6*y(7);
        dfdy(7,14)  = k13;

        dfdy(8,7)   = k4+k5+k6*y(6);
        dfdy(8,6)   = k6*y(7);
        dfdy(8,9)   = k7;

        dfdy(9,9)   = -k7-k8*y(6);
        dfdy(9,6)   = -k8*y(9);

        dfdy(10,10) = -k12*y(2);
        dfdy(10,2)  = -k12*y(10)+k9*y(11);
        dfdy(10,9)  = k7;
        dfdy(10,11) = k9*y(2);

        dfdy(11,11) = -k9*y(2)-k10*y(1);
        dfdy(11,2)  = -k9*y(11);
        dfdy(11,1)  = -k10*y(11);
        dfdy(11,9)  = k8*y(6);
        dfdy(11,6)  = k8*y(9);
        dfdy(11,13) = k11;

        dfdy(12,11) = k9*y(2);
        dfdy(12,2)  = k9*y(11);

        dfdy(13,13) = -k11;
        dfdy(13,11) = k10*y(1);
        dfdy(13,1)  = k10*y(11);

        dfdy(14,14) = -k13;
        dfdy(14,10) = k12*y(2);
        dfdy(14,2)  = k12*y(10);

        dfdy(15,1)  = k14*y(6);
        dfdy(15,6)  = k14*y(1);

        dfdy(16,16) = -k18-k19;
        dfdy(16,4)  = k16;

        dfdy(17,17) = -k20*y(6);
        dfdy(17,6)  = -k20*y(17);

        dfdy(18,17) = k20*y(6);
        dfdy(18,6)  = k20*y(17);

        dfdy(19,19) = -k21-k22-k24*y(1);
        dfdy(19,1)  = -k24*y(19)+k23*y(4);
        dfdy(19,4)  = k23*y(1);
        dfdy(19,20) = k25;

        dfdy(20,20) = -k25;
        dfdy(20,1)  = k24*y(19);
        dfdy(20,19) = k24*y(1);
    end

end