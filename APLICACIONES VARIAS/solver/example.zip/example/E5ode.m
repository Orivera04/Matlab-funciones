function E5ode
%E5ode consists of a stiff system of 4 non-linear ordinary differential
%   equations. It was proposed by Datta in 1967. The name E5 was given
%   by Enright, Hull and Lindberg (1975).

%     W.H. Enright, T.E. Hull, and B. Lindberg. Comparing numerical
%     methods for stiff systemsof ODEs. BIT, 15:10-48, 1975.
%
%   The formulation and data have been taken from.
%
%     E. Hairer and G. Wanner, Solving Ordinary Differential Equations II,
%     Stiff and Differential-Algebraic Problems, Springer-Verlag,
%     second revised edition, 1996.
%
%   The E5 problem is a model for chemical pyrolysis studied by Datta in
%   1967 and describes a reaction involving six reactants.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $


% Problem parameters, shared with the nested function.
A=7.89e-10;
B=1.1e7;
CM=1.13e9;
C=1.13e3;

options = odeset('RelTol',1e-4,'AbsTol',1.1e-24,'InitialStep',1e-12,'Jacobian',@jac,'Stats','on');
y0(1)=1.76e-3;
y0(2)=0;
y0(3)=0;
y0(4)=0;
[t,u] = odebim(@fcn,[0 1e13],y0,options);
t(end)

figure;
plot(t,u(:,1),t,u(:,2),t,u(:,3),t,u(:,4))
legend('y_1','y_2','y_3','y_4',1)
ylim([1e-25 1])
xlim([1e-5 1e12])
set(gca,'XScale','log')
set(gca,'YScale','log')
% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function f = fcn(t,y)
        f = zeros(4,1);
        prod1=A*y(1);
        prod2=B*y(1)*y(3);
        prod3=CM*y(2)*y(3);
        prod4=C*y(4);
        f(1)=-prod1-prod2;
        f(2)=prod1-prod3;
        f(4)=prod2-prod4;
        f(3)=f(2)-f(4);
    end
% -----------------------------------------------------------------------
% Nested function, parameter is provided by the outer function.
%
    function dfdy = jac(t,y)
        dfdy(1,1)=-A-B*y(3);
        dfdy(1,2)=0.0;
        dfdy(1,3)=-B*y(1);
        dfdy(1,4)=0.0;
        dfdy(2,1)=A;
        dfdy(2,2)=-CM*y(3);
        dfdy(2,3)=-CM*y(2);
        dfdy(2,4)=0.0;
        dfdy(3,1)=A-B*y(3);
        dfdy(3,2)=-CM*y(3);
        dfdy(3,3)=-B*y(1)-CM*y(2);
        dfdy(3,4)=C;
        dfdy(4,1)=B*y(3);
        dfdy(4,2)=0.0;
        dfdy(4,3)=B*y(1);
        dfdy(4,4)=-C;
    end

end