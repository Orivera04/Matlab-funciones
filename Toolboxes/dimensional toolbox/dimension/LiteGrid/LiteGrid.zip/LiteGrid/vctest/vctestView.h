// vctestView.h : interface of the CVctestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VCTESTVIEW_H__7EA84451_7659_11D3_B739_DB84A0842A28__INCLUDED_)
#define AFX_VCTESTVIEW_H__7EA84451_7659_11D3_B739_DB84A0842A28__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "LiteGrid.h"

class CVctestView : public CView
{
protected: // create from serialization only
	CVctestView();
	DECLARE_DYNCREATE(CVctestView)

// Attributes
public:
	CVctestDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVctestView)
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetDialogBarVals();
	virtual ~CVctestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CLiteGrid m_ctlLiteGrid;
protected:
	// fired by LiteGrid control
	void OnLgEndEditing(BSTR bsCellText, VARIANT_BOOL* pbAllowChanges);
// Generated message map functions
protected:
	//{{AFX_MSG(CVctestView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	DECLARE_EVENTSINK_MAP()
};

#ifndef _DEBUG  // debug version in vctestView.cpp
inline CVctestDoc* CVctestView::GetDocument()
   { return (CVctestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VCTESTVIEW_H__7EA84451_7659_11D3_B739_DB84A0842A28__INCLUDED_)
