Here are the LiteGrid source and demo/test projects.

Directories and files:

.\SOURCE\ - contains LiteGrid control source files

.\VCTEST\ - contains an example of LiteGrid usage from a
  MFC application. MDI application, each MDI child has a single LiteGrid
  instance and a toolbar which allows to change number of grid's rows,
  columns, fixed rows, fixed columns. Also the grid supports inplace
  editing, so you can enter some text in cell and then save document.
  Changes will take effect after Set button pressed. The project
  demonstrates also handling of events fired by LiteGrid. So, you can
  enter in the grid's cells only vowels.
  Also you can load previously saved documents (*.tab)

.\VBTEST\ - contains an example of LiteGrid usage from a VB project.
  This is a simple viewer for MDB tables. Open an Access database,
  then choose a table from combo box - column names and contents will
  appear in LiteGrid control. You also can try to find a string in
  a particular column using VB's Like operator syntax.

.\HTMLTest.html - HTML source file which has embedded LiteGrid control
  with custom color scheme.

.\lgrid.ocx - compiled LiteGrid control. You should register it
  before using (regsvr32 lgrid.ocx)