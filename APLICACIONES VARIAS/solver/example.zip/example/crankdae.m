function crankdae
% CRANKDAE 
%   This problem was contributed by Bernd Simeon, March 1998. The slider 
%   crank shows some typical properties of simulation problems in 
%   flexible multibody systems, i.e., constrained mechanical systems
%   which include both rigid and elastic bodies. It is also an example 
%   of a stiff mechanical system since it features large stiffness terms in
%   the right hand side. Accordingly, there are some fast variables with
%   high frequency oscillations.
%   This problem is originally described by a second order system of 
%   differential-algebraic equations (DAEs), but transformed to first order 
%   and semi-explicit system of dimension 24. The index of the problem is 
%   originally 3, but an index 1 and index 2 formulation are supplied as well.
%   By default, thefunction provide the index 2 formulation.
%
%   See also ODEBIM, ODE15S, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

% Problem parameter, shared with the nested function.
%        ipar(1)  0: only linear stiffness term k*q
%                 1: nonlinear stiffness term included
% 
%        ipar(2)  0: no physical damping - purely imaginary ev
%                 1: damping matrix (0.5 %) included
ipar(1)=0;
ipar(2)=0;

%        ityp    this flag determines in which formulation the equations
%                of motion have to be evaluated:
%                ityp = 0: index 3 system;     ityp = 3: index 1 system;
%                     = 1: index 2 system;
ityp  = 0;

%     iequa    this integer flag determines whether the complete residual
%              or only parts of it have to be evaluated.
%              iequa = 0: evaluate complete residual;
%                    = 2: evaluate only position+velocity constraints
%                         in delta(1:6)
iequa = 0;

m1 = 0.36e0;         m2 = 0.151104e0;
m3 = 0.075552;       
l1 = 0.15e0;        l2 = 0.30e0;
j1 = 0.002727e0;    j2 = 0.0045339259e0;
ee = 0.20e12;       bb = 0.0080e0;
hh = 0.0080e0;
rho= 7870.0e0;
grav= 0.0e0;        omega = 150.e0;

nq    = 4;
np    = 7;
nl    = 3;
nx    = 3*np + nl;
ku    = 4;
kv    = 0;

facm = rho*bb*hh*l2;
fack = ee*bb*hh/l2;
facb = bb*hh*l2;

mq = zeros(nq);
mq(1,1) = facm*0.5;
mq(2,2) = facm*0.5;
mq(3,3) = facm*8;
mq(3,4) = facm*1;
mq(4,3) = facm*1;
mq(4,4) = facm*2;

kq = zeros(nq);
kq(1,1) = fack*pi^4/24*(hh/l2)^2;
kq(2,2) = fack*pi^4*2/3*(hh/l2)^2;
kq(3,3) = fack*16/3;
kq(3,4) = -fack*8/3;
kq(4,3) = -fack*8/3;
kq(4,4) = fack*7/3;

bq = zeros(nq);
bq(1,3) = -facb*16/pi^3;
bq(1,4) = facb*(8/pi^3-1/pi);
bq(2,4) = facb*0.5/pi;
bq(3,1) = facb*16/pi^3;
bq(4,1) = -facb*(8/pi^3-1/pi);
bq(4,2) = -facb*0.5/pi;

c1  = [              0;                  0;     facb*2.d0/3.d0;     facb*1.d0/6.d0];
c2  = [   facb*2.d0/pi;                  0;                  0;                  0];
c12 = [              0;                  0;  l2*facb*1.d0/3.d0;  l2*facb*1.d0/6.d0];
c21 = [l2*facb*1.d0/pi;  -l2*facb*0.5d0/pi;                  0;                  0];

dq = zeros(nq);
if (ipar(2)==1)
    %       0.5 per cent damping
    dq(1,1) = 5;
    dq(2,2) = 25;
    dq(3,3) = 0.5*2.308375455264791e+02;
    dq(3,4) = -0.5*2.62688487992052e+02;
    dq(4,3) = -0.5*2.626884879920526e+02;
    dq(4,4) = 0.5*4.217421837156818e+02;
end

% Mass matrix
mas = sparse(24,24);
mas(1:14,1:14)  = speye(14);

% use a consistent initial condition to test.
y0 = zeros(24,1);
%     Position variables
%     phi_1, phi_2, x_3, q_1, q_2, q_3, q_4
y0(1) = 0;
y0(2) = 0;
y0(3) = .450016933;
y0(4) = 0;
y0(5) = 0;
y0(6) = .103339863e-04;
y0(7) = .169327969e-04;
%     initial values velocity variables
y0(8) =  .150000000e+03;
y0(9) = -.749957670e+02;
y0(10)= -.268938672e-05;
y0(11)=  .444896105e+00;
y0(12)=  .463434311e-02;
y0(13)= -.178591076e-05;
y0(14)= -.268938672e-05;
%     initial values acceleration variables
y0(15)= 0;
y0(16)= -1.344541576008661e-03;
y0(17)= -5.062194923138079e+03;
y0(18)= -6.833142732779555e-05;
y0(19)=  1.449382650173157e-08;
y0(20)= -4.268463211410861e+00;
y0(21)=  2.098334687947376e-01;
%c     lagrange multipliers
y0(22)= -6.397251492537153e-08;
y0(23)=  3.824589508329281e+02;
y0(24)= -4.376060460948886e-09;

tspan = [0 0.1];
if  ityp  == 0
    options = odeset('mass',mas,'refine',3,'stats','on','daeindex',[7,7,10]);
elseif ityp  == 1
    options = odeset('mass',mas,'stats','on','daeindex',[14,10,0]);
else
    options = odeset('mass',mas,'stats','on','RelTol',1e-3,'AbsTol',1e-6,'InitialStep',1e-4);
end

[t,y] = odebim(@f,tspan,y0,options);

figure(1) ,clf
plot(t,y(:,2),'-')
hold;
plot(t,y(:,3),'--')
xlim([0 0.1])
legend('\phi_2','x_3','Location','Best');
legend('boxoff')
xlabel('$$t(s)$$','Interpreter','latex')
ylabel('$$\phi_2$$,$$x_3$$','Interpreter','latex')

figure(2) ,clf
plot(t,y(:,4),'-')
hold;
plot(t,y(:,5),'--')
xlim([0 0.1])
legend('q_1','q_2','Location','Best');
legend('boxoff')
xlabel('$$t(s)$$','Interpreter','latex')
ylabel('$$q_1$$,$$q_2$$','Interpreter','latex')

figure(3) ,clf
plot(t,y(:,6),'-')
hold;
plot(t,y(:,7),'--')
xlim([0 0.1])
legend('q_3','q_4','Location','Best');
legend('boxoff')
xlabel('$$t(s)$$','Interpreter','latex')
ylabel('$$q_3$$,$$q_4$$','Interpreter','latex')

figure(4) ,clf
plot(t,y(:,22),'-')
hold;
plot(t,y(:,23),'--')
plot(t,y(:,24),':')
xlim([0 0.1])
legend('\lambda_1','\lambda_2','\lambda_3','Location','Best');
legend('boxoff')
xlabel('$$t(s)$$','Interpreter','latex')
ylabel('$$\lambda_1$$,$$\lambda_2$$,$$\lambda_3$$','Interpreter','latex')

  % -----------------------------------------------------------------------
  % Nested functions -- parameter is provided by the outer function.
  %
    function delta = resmbs(t,x,xd)
        delta =zeros(24,1);

        cosp1  = cos(x(1));
        cosp2  = cos(x(2));
        sinp1  = sin(x(1));
        sinp2  = sin(x(2));
        cosp12 = cos(x(1)-x(2));
        sinp12 = sin(x(1)-x(2));
        v(1)   = x(np+1);
        v(2)   = x(np+2);
        
        q(1:nq,1)  = x(4:3+nq);
        qd(1:nq,1) = x(np+4:np+3+nq);
        
        c1tq  = c1'*q;
        c1tqd = c1'*qd;
        c2tq  = c2'*q;
        c2tqd = c2'*qd;
        c12tq = c12'*q;
        c12tqd= c12'*qd;
        mqq = mq*q;
        kqq = kq*q;
        dqqd= dq*qd;
        qtbq = q'*bq;
        bqqd = bq*qd;
        qtmqq = q'*mq*q;
        qdtmqq = qd'*mq*q;
        qdtbqqd =qd'*bq*qd;

        % c     kinematic and dynamic equations.
        for i=1:np
            delta(i)    = xd(i)    - x(np+i);
            delta(np+i) = xd(np+i) - x(2*np+i);
        end

        % c     compute mass matrix.
        am = zeros(7);
        am(1,1) = j1 + m2*l1*l1;
        am(1,2) = .5*l1*l2*m2*cosp12;
        am(2,2) = j2;
        am(1,3) = 0;
        am(2,3) = 0;
        am(3,1) = 0;
        am(3,2) = 0;
        am(3,3) = m3;
        am(1,2) = am(1,2) + rho*l1*(sinp12*c2tq+cosp12*c1tq);
        am(2,2) = am(2,2) + qtmqq + 2*rho*c12tq;

        for i=1:nq
            am(1,3+i) = rho*l1*(-sinp12*c1(i) + cosp12*c2(i));
            am(2,3+i) = rho*c21(i) + rho*qtbq(i);
            am(3,3+i) = 0;
        end

        for i=1:nq
            for j=1:i
                am(3+j,3+i) = mq(j,i);
            end
        end

        for i=1:np
            for j=(i+1):np
                am(j,i) = am(i,j);
            end
        end

        % c     compute constraint matrix.
        if (ku==0)
            qku = 0;
        else
            qku = q(ku);
        end

        if (kv==0)
            qkv = 0;
        else
            qkv = q(kv);
        end

        gp(1,1) = l1*cosp1;
        gp(1,2) = l2*cosp2 + qku*cosp2 - qkv*sinp2;
        gp(1,3) = 0;
        gp(2,1) = l1*sinp1;
        gp(2,2) = l2*sinp2 + qku*sinp2 + qkv*cosp2;
        gp(2,3) = 1;
        gp(3,1) = 1;
        gp(3,2) = 0;
        gp(3,3) = 0;

        for i=1:nq
            gp(1,3+i) = 0;
            gp(2,3+i) = 0;
            gp(3,3+i) = 0;
        end

        if (ku~=0)
            gp(1,3+ku) = sinp2;
            gp(2,3+ku) = -cosp2;
        end

        if (kv~=0)
            gp(1,3+kv) = cosp2;
            gp(2,3+kv) = sinp2;
        end

        %      forces - rigid motion entries.
        f(1) = -.5*l1*grav*(m1+2*m2)*cosp1-.5*l1*l2*m2*v(2)*v(2)*sinp12;
        f(2) = -.5*l2*grav*m2*cosp2+.5*l1*l2*m2*v(1)*v(1)*sinp12;
        f(3) = 0;

        %      superposition of flexible motion (term f^e).
        f(1) = f(1)+ rho*l1*v(2)*v(2)*(-sinp12*c1tq+cosp12*c2tq)-...
            2*rho*l1*v(2)*(cosp12*c1tqd+sinp12*c2tqd);
        f(2) = f(2)+ rho*l1*v(1)*v(1)*(sinp12*c1tq-cosp12*c2tq)-...
            2*rho*v(2)*c12tqd - 2*v(2)*qdtmqq-...
            rho*qdtbqqd - rho*grav*(cosp2*c1tq-sinp2*c2tq);

        %      coriolis and gravity terms flexible motion (gamma).
        for i=1:nq
            f(3+i) = v(2)*v(2)*mqq(i)+ rho*(v(2)*v(2)*c12(i)+...
                l1*v(1)*v(1)*(cosp12*c1(i)+sinp12*c2(i))+...
                2*v(2)*bqqd(i) )- rho*grav*(sinp2*c1(i)+cosp2*c2(i));
        end

        % c         stiffness + damping terms - k q - d q'.
        for i=1:nq
            f(3+i) = f(3+i) - kqq(i) - dqqd(i);
        end

        if (ipar(1)==1)
            % c            nonlinear stiffness term
            fack = 0.5*ee*bb*hh/l2^2*pi^2;
            facb = 80.d0/(pi^2*9);
            f(4) = f(4) -fack*(q(1)*q(4)-facb*q(2)*(-4*q(3)+2*q(4)));
            f(5) = f(5) -fack*(4*q(2)*q(4)-facb*q(1)*(-4*q(3)+2*q(4)));
            f(6) = f(6) -fack*4*facb*q(1)*q(2);
            f(7) = f(7) -fack*(0.5*q(1)^2+2*q(2)^2-2*facb*q(1)*q(2));
        end
        
        % c     dynamics part ii ( m*w - f + g(t)*lambda ).
        for i=1:np
            delta(2*np+i) = dot(am(:,i),x(2*np+1:3*np,1))- f(i) + gp(1,i)*x(nx-2)+gp(2,i)*x(nx-1)+gp(3,i)*x(nx);
        end
        
        % c     acceleration level constraints.
        if (ku==0)
            qdku = 0;
        else
            qdku = qd(ku);
        end

        if (kv==0)
            qdkv = 0;
        else
            qdkv = qd(kv);
        end

        alc(1) = -l1*sinp1*v(1)*v(1) - (l2+qku)*sinp2*v(2)*v(2)...
            +2*v(2)*(cosp2*qdku-sinp2*qdkv) - cosp2*v(2)*v(2)*qkv;
        alc(2) =  l1*cosp1*v(1)*v(1) + (l2+qku)*cosp2*v(2)*v(2)...
            +2*v(2)*(sinp2*qdku+cosp2*qdkv) - sinp2*v(2)*v(2)*qkv;
        alc(3) = 0;

        for i=1:np
            alc(1) = alc(1) + gp(1,i)*x(2*np+i);
            alc(2) = alc(2) + gp(2,i)*x(2*np+i);
            alc(3) = alc(3) + gp(3,i)*x(2*np+i);
        end

        % c     position level constraints.
        plc(1) = l1*sinp1 + l2*sinp2 + qku*sinp2 + qkv*cosp2;
        plc(2) = x(3) - l1*cosp1 - l2*cosp2-qku*cosp2 + qkv*sinp2;
        plc(3) = x(1) - omega*t;

        % c     velocity level constraints.
        vlc(1) = 0;
        vlc(2) = 0;
        vlc(3) = -omega;
        
        for i=1:np
            vlc(1) = vlc(1) + gp(1,i)*x(np+i);
            vlc(2) = vlc(2) + gp(2,i)*x(np+i);
            vlc(3) = vlc(3) + gp(3,i)*x(np+i);
        end
        
        if (iequa==2)
            % c         evaluate only the constraints.
            delta(1) = plc(1);
            delta(2) = plc(2);
            delta(3) = plc(3);
            delta(4) = vlc(1);
            delta(5) = vlc(2);
            delta(6) = vlc(3);
        else
            % c         select constraints defined by ityp.
            if (ityp==0)
                % c             index 3 system.
                delta(nx-2) = plc(1);
                delta(nx-1) = plc(2);
                delta(nx)   = plc(3);
            elseif (ityp==1)
                % c             index 2 system.
                delta(nx-2) = vlc(1);
                delta(nx-1) = vlc(2);
                delta(nx)   = vlc(3);
            elseif (ityp==3)
                % c             index 1 system.
                delta(nx-2) = alc(1);
                delta(nx-1) = alc(2);
                delta(nx)   = alc(3);
            end
        end
    end

    function dy = f(t,y)
        dy = zeros(24,1);
        dy = resmbs(t,y,dy);
        dy(1:14) = -dy(1:14);
    end
end
