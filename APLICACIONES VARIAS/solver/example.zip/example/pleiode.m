function pleiode
%PLEIODE consists of a nonstiff system of 14 special second order 
%  differential equations rewritten to first order form, thus providing 
%  a nonstiff system of ordinary differential equations of dimension 28.
%  The formulation and data have been taken from
%    E. Hairer, S.P. Norsett, and G. Wanner. Solving Ordinary Differential 
%    Equations I: Nonstiff Problems. Springer-Verlag, second revised edition, 1993.
%
%  The Pleiades problem is a celestial mechanics problem of seven stars in
%  the plane of coordinates x_i,y_i and masses m_i = i (i = 1,...,7). 
%  We obtain the formulation of the problem by means of some mechanical considerations.
%
%   See also ODEBIM, ODE45, ODESET, FUNCTION_HANDLE.
%
%   Wu Zhiqiao     03-05-07
%   $Revision: 1.0.0.1 $  $Date: 2007/03/13 11:30:13 $

options = odeset('Jacobian',@jac);
y0 =  zeros(28,1);
y0(1)  =  3;
y0(2)  =  3;
y0(3)  = -1;
y0(4)  = -3;
y0(5)  =  2;
y0(6)  = -2;
y0(7)  =  2;
y0(8)  =  3;
y0(9)  = -3;
y0(10) =  2;
y0(11) =  0;
y0(12) =  0;
y0(13) = -4;
y0(14) =  4;
y0(15) =  0;
y0(16) =  0;
y0(17) =  0;
y0(18) =  0;
y0(19) =  0;
y0(20) =  1.75;
y0(21) = -1.5;
y0(22) =  0;
y0(23) =  0;
y0(24) =  0;
y0(25) = -1.25;
y0(26) =  1;
y0(27) =  0;
y0(28) =  0;
tic
[t,y] = odebim(@plei,[0 3],y0,options);
toc
figure(1);
subplot(1,2,1); plot(t,y(:,1)); title('x_{1}');
subplot(1,2,2); plot(t,y(:,8)); title('y_{1}');



% -----------------------------------------------------------------------
% Nested function
%
    function f = plei(t,y)
        f = zeros(28,1);
        for i=1:7
            sumx = 0;
            sumy = 0;
            for j=1:7
                mj = j;
                rij = (y(i)-y(j))^2+(y(i+7)-y(j+7))^2;
                rij32 = rij^(3/2);
                if (j~=i)
                    sumx = sumx+mj*(y(j)-y(i))/rij32;
                    sumy = sumy+mj*(y(j+7)-y(i+7))/rij32;
                end
            end
            f(i+14) = sumx;
            f(i+21) = sumy;
        end
        for i=1:14
            f(i) = y(i+14);
        end
    end
% -----------------------------------------------------------------------
% Nested function
%
    function dfdy = jac(t,y)
        dfdy = zeros(28,28);
        for i=1:14
            dfdy(i,14+i)=1;
        end
        for i=2:7
            mi=i;
            for j=1:i-1
                mj=j;
                rij=(y(i)-y(j))^2+(y(i+7)-y(j+7))^2;
                rij32=rij^1.5;
                rij52=rij^2.5;
                fjh=(1-3*(y(j)-y(i))^2/rij)/rij32;
                dfdy(i+14,j)=mj*fjh;
                dfdy(j+14,i)=mi*fjh;
                fjh=(1-3*(y(j+7)-y(i+7))^2/rij)/rij32;
                dfdy(i+21,j+7)=mj*fjh;
                dfdy(j+21,i+7)=mi*fjh;
                fjh=-3*(y(j)-y(i))*(y(j+7)-y(i+7))/rij52;
                dfdy(i+14,j+7)=mj*fjh;
                dfdy(j+14,i+7)=mi*fjh;
                dfdy(i+21,j)=mj*fjh;
                dfdy(j+21,i)=mi*fjh;
            end
        end
        for i=1:7
            sumxx=0;
            sumxy=0;
            sumyy=0;
            for j=1:7
                if (j~=i)
                    sumxx=sumxx+dfdy(i+14,j);
                    sumxy=sumxy+dfdy(i+14,j+7);
                    sumyy=sumyy+dfdy(i+21,j+7);
                end
            end
            dfdy(i+14,i)=-sumxx;
            dfdy(i+14,i+7)=-sumxy;
            dfdy(i+21,i)=-sumxy;
            dfdy(i+21,i+7)=-sumyy;
        end
    end

end