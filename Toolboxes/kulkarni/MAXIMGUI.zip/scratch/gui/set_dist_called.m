function set_dist_called(k); 
global dist_called Primary_state
dist_called = k;
