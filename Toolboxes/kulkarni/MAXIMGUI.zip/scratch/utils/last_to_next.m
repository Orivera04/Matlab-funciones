function last_to_next()

global Next_process Last_process

Next_process = Last_process ;

