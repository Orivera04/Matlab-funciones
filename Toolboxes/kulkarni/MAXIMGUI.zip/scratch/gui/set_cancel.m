function set_cancel();
global cancel_win
cancel_win = 1;