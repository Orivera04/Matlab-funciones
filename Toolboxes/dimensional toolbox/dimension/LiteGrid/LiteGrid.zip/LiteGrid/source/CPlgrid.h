
//////////////////////////////////////////////////////////////////////////////
// CProxy_LiteGridEvents
template <class T>
class CProxy_LiteGridEvents : public IConnectionPointImpl<T, &DIID__LiteGridEvents, CComDynamicUnkArray>
{
public:
//methods:
//_LiteGridEvents : IDispatch
public:
	// fired by LiteGrid when WM_MOUSEMOVE occurs
	// Arguments:
	//		See VB documentation for MouseMove event
	//		Coordinates are given in pixels.
	void Fire_MouseMove(
		short Button,
		short Shift,
		long x,
		long y)
	{
		VARIANTARG* pvars = new VARIANTARG[4];
		for (int i = 0; i < 4; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[3].vt = VT_I2;
				pvars[3].iVal= Button;
				pvars[2].vt = VT_I2;
				pvars[2].iVal= Shift;
				pvars[1].vt = VT_I4;
				pvars[1].lVal= x;
				pvars[0].vt = VT_I4;
				pvars[0].lVal= y;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}

	// fired by LiteGrid when WM_MOUSEDOWN occurs
	// Arguments:
	//		See VB documentation for MouseDown event
	//		Coordinates are given in pixels.
	void Fire_MouseDown(
		short Button,
		short Shift,
		long x,
		long y)
	{
		VARIANTARG* pvars = new VARIANTARG[4];
		for (int i = 0; i < 4; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[3].vt = VT_I2;
				pvars[3].iVal= Button;
				pvars[2].vt = VT_I2;
				pvars[2].iVal= Shift;
				pvars[1].vt = VT_I4;
				pvars[1].lVal= x;
				pvars[0].vt = VT_I4;
				pvars[0].lVal= y;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x2, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
	// fired by LiteGrid when WM_MOUSEUP occurs
	// Arguments:
	//		See VB documentation for MouseUp event
	//		Coordinates are given in pixels.
	void Fire_MouseUp(
		short Button,
		short Shift,
		long x,
		long y)
	{
		VARIANTARG* pvars = new VARIANTARG[4];
		for (int i = 0; i < 4; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[3].vt = VT_I2;
				pvars[3].iVal= Button;
				pvars[2].vt = VT_I2;
				pvars[2].iVal= Shift;
				pvars[1].vt = VT_I4;
				pvars[1].lVal= x;
				pvars[0].vt = VT_I4;
				pvars[0].lVal= y;
				DISPPARAMS disp = { pvars, NULL, 4, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x3, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
	// fired by LiteGrid when mouse left button has clicked
	void Fire_Click()
	{
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				DISPPARAMS disp = { NULL, NULL, 0, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x4, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
	}
	// fired by LiteGrid when WM_KEYDOWN occurs
	// Arguments:
	//		See VB documentation for KeyDown event
	void Fire_KeyDown(
		short KeyCode,
		short Shift)
	{
		VARIANTARG* pvars = new VARIANTARG[2];
		for (int i = 0; i < 2; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[1].vt = VT_I2;
				pvars[1].iVal= KeyCode;
				pvars[0].vt = VT_I2;
				pvars[0].iVal= Shift;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x5, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
	// fired by LiteGrid when WM_KEYUP occurs
	// Arguments:
	//		See VB documentation for KeyUp event
	void Fire_KeyUp(
		short KeyCode,
		short Shift)
	{
		VARIANTARG* pvars = new VARIANTARG[2];
		for (int i = 0; i < 2; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[1].vt = VT_I2;
				pvars[1].iVal= KeyCode;
				pvars[0].vt = VT_I2;
				pvars[0].iVal= Shift;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x6, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
	// fired by LiteGrid when WM_CHAR occurs
	// Arguments:
	//		See VB documentation for KeyPress event
	void Fire_KeyPress(
		short KeyAscii)
	{
		VARIANTARG* pvars = new VARIANTARG[1];
		for (int i = 0; i < 1; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[0].vt = VT_I2;
				pvars[0].iVal= KeyAscii;
				DISPPARAMS disp = { pvars, NULL, 1, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x7, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
	// fired by LiteGrid when active cell is going to change
	// Arguments:
	//		lRow, lCol = new row and column of selected cell
	void Fire_CellChanging(
		long lRow,
		long lCol)
	{
		VARIANTARG* pvars = new VARIANTARG[2];
		for (int i = 0; i < 2; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[1].vt = VT_I4;
				pvars[1].lVal= lRow;
				pvars[0].vt = VT_I4;
				pvars[0].lVal= lCol;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x9, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}

	// fired by LiteGrid after active cell's coordinates have changed
	void Fire_CellChanged()
	{
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				DISPPARAMS disp = { NULL, NULL, 0, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0xa, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
	}

	// fired by LiteGrid before inplace editing
	// Arguments:
	//		bAllowEdit = out, if user sets FALSE then inplace editing will not occur. Default: TRUE
	void Fire_StartEditing(
		VARIANT_BOOL* bAllowEdit)
	{
		VARIANTARG var;
		VariantInit(&var);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				var.vt = VT_BOOL | VT_BYREF;
				var.pboolVal = bAllowEdit;
				DISPPARAMS disp = { &var, NULL, 1, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x0b, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
	}
	// fired by LiteGrid after inplace editing
	// Arguments:
	//		bsNewValue = in, string a user has typed into inplace editor
	//		bAllowChange = out, if user sets FALSE then changes of a cell's text will not occur. Default: TRUE
	void Fire_EndEditing(
		BSTR bsNewValue,
		VARIANT_BOOL* pbAllowChange)
	{
		VARIANTARG* pvars = new VARIANTARG[2];
		for (int i = 0; i < 2; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[1].vt = VT_BSTR;
				pvars[1].bstrVal = bsNewValue;
				pvars[0].vt = VT_BOOL | VT_BYREF;
				pvars[0].pboolVal = pbAllowChange;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x0c, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}
};