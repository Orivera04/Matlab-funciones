// vctestView.cpp : implementation of the CVctestView class
//

#include "stdafx.h"
#include "vctest.h"

#include "vctestDoc.h"
#include "vctestView.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVctestView

#define IDC_GRIDCTRL 40000

IMPLEMENT_DYNCREATE(CVctestView, CView)

BEGIN_MESSAGE_MAP(CVctestView, CView)
	//{{AFX_MSG_MAP(CVctestView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

BEGIN_EVENTSINK_MAP(CVctestView, CView)
	ON_EVENT(CVctestView, IDC_GRIDCTRL, 12 /*EndEditing*/, OnLgEndEditing, VTS_WBSTR VTS_PBOOL)
END_EVENTSINK_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVctestView construction/destruction

CVctestView::CVctestView()
{
	// TODO: add construction code here

}

CVctestView::~CVctestView()
{
}



/////////////////////////////////////////////////////////////////////////////
// CVctestView printing

BOOL CVctestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CVctestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CVctestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CVctestView diagnostics

#ifdef _DEBUG
void CVctestView::AssertValid() const
{
	CView::AssertValid();
}

void CVctestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVctestDoc* CVctestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVctestDoc)));
	return (CVctestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVctestView message handlers

int CVctestView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// create the LiteGrid control
	CRect rcClient;
	GetClientRect(&rcClient);
	if(!m_ctlLiteGrid.Create(NULL, WS_VISIBLE | WS_CHILD, rcClient, this, 40000))
	{
		AfxMessageBox(_T("Could not create LiteGrid control.\nExiting..."));
		exit(0);
	}
	m_ctlLiteGrid.ShowWindow(SW_SHOW);
	CVctestDoc* pDoc = GetDocument();
	m_ctlLiteGrid.SetFocus();
	return 0;
}

void CVctestView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	// warning 4100
	pHint = pHint;
	lHint = lHint;
	pSender = pSender;
	// fill the LiteGrid control with document's data
	CVctestDoc* pDoc = (CVctestDoc*)GetDocument();

	// Set the grid sizes
	m_ctlLiteGrid.SetRows(pDoc->m_lNumRows);
	m_ctlLiteGrid.SetCols(pDoc->m_lNumCols);
	m_ctlLiteGrid.SetFixedRows(pDoc->m_lNumFixedRows);
	m_ctlLiteGrid.SetFixedCols(pDoc->m_lNumFixedCols);
	// Set the grid contents
	for(int i = 0; i < pDoc->m_lNumRows * pDoc->m_lNumCols; i++)
		m_ctlLiteGrid.SetCellText(i / pDoc->m_lNumCols, i % pDoc->m_lNumCols, (LPCTSTR)pDoc->m_vecGridStrings[i]);
	SetDialogBarVals();
}

void CVctestView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if(nType == SIZE_MINIMIZED)
		return;
	// make the grid to cover all client area
	m_ctlLiteGrid.MoveWindow(0, 0, cx, cy, FALSE);
}

void CVctestView::OnLgEndEditing(BSTR bsCellText, VARIANT_BOOL* pbAllowChanges)
{
	CVctestDoc* pDoc = static_cast<CVctestDoc*>(GetDocument());
	CString sTmp = bsCellText;

	// do not alow a user to enter wovels
	if(sTmp.FindOneOf(_T("aAeEiIoOuUyY")))
	{
		*pbAllowChanges = FALSE;
		return;
	}
	// reflect changes
	pDoc->m_vecGridStrings[pDoc->m_lNumCols * m_ctlLiteGrid.GetRow() + m_ctlLiteGrid.GetCol()] = sTmp;
	pDoc->SetModifiedFlag();
}

// sets values in the dialog bar adjusted to current
// state of m_ctlLiteGrid
void CVctestView::SetDialogBarVals()
{
	CDialogBar* pBar = &static_cast<CChildFrame*>(GetParent())->m_wndGridOpts;
	CString sTmp;

	sTmp.Format(_T("%d"), m_ctlLiteGrid.GetRows());
	pBar->SetDlgItemText(IDC_EDT_NUMROWS, sTmp);
	sTmp.Format(_T("%d"), m_ctlLiteGrid.GetCols());
	pBar->SetDlgItemText(IDC_EDT_NUMCOLS, sTmp);
	sTmp.Format(_T("%d"), m_ctlLiteGrid.GetFixedRows());
	pBar->SetDlgItemText(IDC_EDT_NUMFIXEDROWS, sTmp);
	sTmp.Format(_T("%d"), m_ctlLiteGrid.GetFixedRows());
	pBar->SetDlgItemText(IDC_EDT_NUMFIXEDCOLS, sTmp);
}

void CVctestView::OnDraw(CDC* pDC) 
{
	// warning
	pDC = pDC;	
}
