function updat_and_hscroll(num_disp)

update_add_nonsq_matrix_values(num_disp);
amhscroll_nonsq(num_disp);
