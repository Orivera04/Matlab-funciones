// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// ILiteGrid wrapper class

class ILiteGrid : public COleDispatchDriver
{
public:
	ILiteGrid() {}		// Calls COleDispatchDriver default constructor
	ILiteGrid(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ILiteGrid(const ILiteGrid& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetWindow();
	long GetFixedRows();
	void SetFixedRows(long nNewValue);
	long GetFixedCols();
	void SetFixedCols(long nNewValue);
	long GetRows();
	void SetRows(long nNewValue);
	long GetCols();
	void SetCols(long nNewValue);
	CString GetCellText(long lRow, long lCol);
	void SetCellText(long lRow, long lCol, LPCTSTR lpszNewValue);
	long GetColWidth(long lCol);
	void SetColWidth(long lCol, long nNewValue);
	long GetRowHeight(long lRow);
	void SetRowHeight(long lRow, long nNewValue);
	long GetDefaultColWidth();
	void SetDefaultColWidth(long nNewValue);
	long GetDefaultRowHeight();
	void SetDefaultRowHeight(long nNewValue);
	long GetRow();
	void SetRow(long nNewValue);
	long GetCol();
	void SetCol(long nNewValue);
	LPDISPATCH GetFixedFont();
	void SetRefFixedFont(LPDISPATCH newValue);
	LPDISPATCH GetNormalFont();
	void SetRefNormalFont(LPDISPATCH newValue);
	unsigned long GetFixedBkColor();
	void SetFixedBkColor(unsigned long newValue);
	unsigned long GetNormalBkColor();
	void SetNormalBkColor(unsigned long newValue);
	unsigned long GetFixedTextColor();
	void SetFixedTextColor(unsigned long newValue);
	unsigned long GetNormalTextColor();
	void SetNormalTextColor(unsigned long newValue);
	unsigned long GetFixedLightColor();
	void SetFixedLightColor(unsigned long newValue);
	unsigned long GetFixedShadowColor();
	void SetFixedShadowColor(unsigned long newValue);
	unsigned long GetNormalLightColor();
	void SetNormalLightColor(unsigned long newValue);
	unsigned long GetNormalShadowColor();
	void SetNormalShadowColor(unsigned long newValue);
	void SetIsEnabled(BOOL bNewValue);
	BOOL GetIsEnabled();
	BOOL GetVisible();
	void SetVisible(BOOL bNewValue);
	BOOL GetBorder();
	void SetBorder(BOOL bNewValue);
	long GetCellTop();
	long GetCellLeft();
	long GetCellWidth();
	long GetCellHeight();
	BOOL GetResizeRows();
	void SetResizeRows(BOOL bNewValue);
	BOOL GetResizeCols();
	void SetResizeCols(BOOL bNewValue);
	BOOL GetEditable();
	void SetEditable(BOOL bNewValue);
	long GetScrollBars();
	void SetScrollBars(long nNewValue);
	BOOL GetFastDraw();
	void SetFastDraw(BOOL bNewValue);
	long GetColAlign(long lCol);
	void SetColAlign(long lCol, long nNewValue);
	long GetDefaultColAlign();
	void SetDefaultColAlign(long nNewValue);
	long GetFixedTextWidth(LPCTSTR bsText);
	long GetNormalTextWidth(LPCTSTR bsText);
};
/////////////////////////////////////////////////////////////////////////////
// _LiteGridEvents wrapper class

class _LiteGridEvents : public COleDispatchDriver
{
public:
	_LiteGridEvents() {}		// Calls COleDispatchDriver default constructor
	_LiteGridEvents(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	_LiteGridEvents(const _LiteGridEvents& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	void MouseMove(short Button, short Shift, long x, long y);
	void MouseDown(short Button, short Shift, long x, long y);
	void MouseUp(short Button, short Shift, long x, long y);
	void Click();
	void KeyDown(short KeyCode, short Shift);
	void KeyUp(short KeyCode, short Shift);
	void KeyPress(short KeyAscii);
	void CellChanging(long lRow, long lCol);
	void CellChanged();
	void StartEditing(BOOL* bAllowEdit);
	void EndEditing(LPCTSTR sNewVal, BOOL* bAllowChanges);
};
